-- "lua\\autorun\\artemius_zombie_dclass.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP Zombie D - Class", "models/artemius/scp/zombie_dclass/zombie_dclass.mdl" )
list.Set( "PlayerOptionsModel",  "SCP Zombie D - Class", "models/artemius/scp/zombie_dclass/zombie_dclass.mdl" )