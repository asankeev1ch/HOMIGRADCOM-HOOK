-- "lua\\autorun\\gfl2_mosin_nagant.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Girls Frontline 2 Mosin-Nagant (M1891)", "models/player/gfl2_mosin_nagant.mdl" )
player_manager.AddValidHands( "Girls Frontline 2 Mosin-Nagant (M1891)", "models/arms/gfl2_mosin_nagant_arms.mdl", 0, "00000000" )

local Category = "Girls Frontline 2"

local NPC =
{
	Name = "Mosin-Nagant (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/gfl2_mosin_nagant_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_mosin_nagant_friendly", NPC )

local NPC =
{
	Name = "Mosin-Nagant (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/gfl2_mosin_nagant_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_mosin_nagant_enemy", NPC )
