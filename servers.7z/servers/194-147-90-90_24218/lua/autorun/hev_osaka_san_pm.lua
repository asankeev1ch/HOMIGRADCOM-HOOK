-- "lua\\autorun\\hev_osaka_san_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "HEV Osaka", "models/nirny/vroid/hev_osaka_san.mdl" )
list.Set( "PlayerOptionsModel", "HEV Osaka", "models/nirny/vroid/hev_osaka_san.mdl" )
player_manager.AddValidHands( "HEV Osaka", "models/nirny/vroid/hev_osaka_arms.mdl", 0, "00000000" )