-- "lua\\autorun\\squid_game_palyer.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
---- KERRY.inc --

list.Set( "PlayerOptionsModel", "a_citizen_01", "models/kerry/green_cit/male_02.mdl" )
player_manager.AddValidModel( "a_citizen_01", "models/kerry/green_cit/male_02.mdl" )

list.Set( "PlayerOptionsModel", "a_citizen_02", "models/kerry/green_cit/male_04.mdl" )
player_manager.AddValidModel( "a_citizen_02", "models/kerry/green_cit/male_04.mdl" )

list.Set( "PlayerOptionsModel", "a_citizen_03", "models/kerry/green_cit/male_05.mdl" )
player_manager.AddValidModel( "a_citizen_03", "models/kerry/green_cit/male_05.mdl" )

list.Set( "PlayerOptionsModel", "a_citizen_04", "models/kerry/green_cit/male_06.mdl" )
player_manager.AddValidModel( "a_citizen_04", "models/kerry/green_cit/male_06.mdl" )

list.Set( "PlayerOptionsModel", "a_citizen_05", "models/kerry/green_cit/male_07.mdl" )
player_manager.AddValidModel( "a_citizen_05", "models/kerry/green_cit/male_07.mdl" )

list.Set( "PlayerOptionsModel", "a_citizen_06", "models/kerry/green_cit/male_08.mdl" )
player_manager.AddValidModel( "a_citizen_06", "models/kerry/green_cit/male_08.mdl" )

list.Set( "PlayerOptionsModel", "a_citizen_07", "models/kerry/green_cit/male_09.mdl" )
player_manager.AddValidModel( "a_citizen_07", "models/kerry/green_cit/male_09.mdl" )


list.Set( "PlayerOptionsModel", "s_citizen_01", "models/kerry/suit_cit/male_02.mdl" )
player_manager.AddValidModel( "s_citizen_01", "models/kerry/suit_cit/male_02.mdl" )

list.Set( "PlayerOptionsModel", "s_citizen_02", "models/kerry/suit_cit/male_04.mdl" )
player_manager.AddValidModel( "s_citizen_02", "models/kerry/suit_cit/male_04.mdl" )

list.Set( "PlayerOptionsModel", "s_citizen_03", "models/kerry/suit_cit/male_05.mdl" )
player_manager.AddValidModel( "s_citizen_03", "models/kerry/suit_cit/male_05.mdl" )

list.Set( "PlayerOptionsModel", "s_citizen_04", "models/kerry/suit_cit/male_06.mdl" )
player_manager.AddValidModel( "s_citizen_04", "models/kerry/suit_cit/male_06.mdl" )

list.Set( "PlayerOptionsModel", "s_citizen_05", "models/kerry/suit_cit/male_07.mdl" )
player_manager.AddValidModel( "s_citizen_05", "models/kerry/suit_cit/male_07.mdl" )

list.Set( "PlayerOptionsModel", "s_citizen_06", "models/kerry/suit_cit/male_08.mdl" )
player_manager.AddValidModel( "s_citizen_06", "models/kerry/suit_cit/male_08.mdl" )

list.Set( "PlayerOptionsModel", "s_citizen_07", "models/kerry/suit_cit/male_09.mdl" )
player_manager.AddValidModel( "s_citizen_07", "models/kerry/suit_cit/male_09.mdl" )


list.Set( "PlayerOptionsModel", "persone", "models/kerry/red_cit/male_02.mdl" )
player_manager.AddValidModel( "persone", "models/kerry/red_cit/male_02.mdl" )

list.Set( "PlayerOptionsModel", "doll", "models/kerry/doll/doll.mdl" )
player_manager.AddValidModel( "doll", "models/kerry/doll/doll.mdl" )