-- "lua\\autorun\\bigboss.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
/*
	Addon by Voikanaa	
*/

player_manager.AddValidModel( "Big Boss", 		"models/player/big_boss.mdl" );
player_manager.AddValidHands( "Big Boss", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss", 	"models/player/big_boss.mdl" );

player_manager.AddValidModel( "Big Boss 2", 		"models/player/big_boss2.mdl" );
player_manager.AddValidHands( "Big Boss 2", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss 2", 	"models/player/big_boss2.mdl" );

player_manager.AddValidModel( "Big Boss 3", 		"models/player/big_boss3.mdl" );
player_manager.AddValidHands( "Big Boss 3", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss 3", 	"models/player/big_boss3.mdl" );

player_manager.AddValidModel( "Big Boss 4", 		"models/player/big_boss4.mdl" );
player_manager.AddValidHands( "Big Boss 4", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss 4", 	"models/player/big_boss4.mdl" );

player_manager.AddValidModel( "Big Boss 5", 		"models/player/big_boss5.mdl" );
player_manager.AddValidHands( "Big Boss 5", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss 5", 	"models/player/big_boss5.mdl" );

player_manager.AddValidModel( "Big Boss 6", 		"models/player/big_boss6.mdl" );
player_manager.AddValidHands( "Big Boss 6", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss 6", 	"models/player/big_boss6.mdl" );

player_manager.AddValidModel( "Big Boss 7", 		"models/player/big_boss7.mdl" );
player_manager.AddValidHands( "Big Boss 7", 	"models/player/big_boss_hands.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Big Boss 7", 	"models/player/big_boss7.mdl" );