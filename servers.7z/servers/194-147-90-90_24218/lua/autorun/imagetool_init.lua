-- "lua\\autorun\\imagetool_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[
        © AsterionStaff 2022.
        This script was created from the developers of the AsterionTeam.
        You can get more information from one of the links below:
            Site - https://asterion.games
            Discord - https://discord.gg/CtfS8r5W3M
        
        developer(s):
            Selenter - https://steamcommunity.com/id/selenter

        ——— Chop your own wood and it will warm you twice.
]]--


-- Инклаидаем основной файл
include("imagetool/sh_batch.lua")
AddCSLuaFile("imagetool/sh_batch.lua")