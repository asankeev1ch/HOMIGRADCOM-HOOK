-- "lua\\somehandysents\\vsmg_core.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if VSMG_Quit then VSMG_Quit:Remove() end vsmg = {}
if SERVER then
	util.AddNetworkString( "NET_VSMG_Withdraw" ) util.AddNetworkString( "NET_VSMG_HUDNotify" ) util.AddNetworkString( "NET_VSMG_WinNotice" )
	vsmg.core = nil --场地中心实体
	vsmg.entity = nil --sent_she_vsmg实体本身
	vsmg.fstage = nil --场地强制关卡,指令'vsmg_forcestage'设置
	vsmg.stages = {} --场地存储
	vsmg.tstage = 0 --场地总数
	vsmg.nstage = 0 --场地随机选择
	vsmg.pstage = nil --场地随机选择
	vsmg.filter = {
		[ "crossbow_bolt" ] = true, [ "grenade_ar2" ] = true, [ "rpg_missile" ] = true, [ "npc_satchel" ] = true,
		[ "npc_grenade_frag" ] = true, [ "prop_combine_ball" ] = true, [ "npc_tripmine" ] = true,
	}
	function vsmg.RegisterStage( ClassName, DataTable ) --场地录入
		if !isstring( ClassName ) or !istable( DataTable ) or ClassName == "" or ClassName == "_" then return end
		local InputTable = {}
		InputTable.Name 		= "" --场地名称,开局显示在中间
		InputTable.HelperA 		= "" --场地备注,开局显示在玩家A中间
		InputTable.HelperB 		= "" --场地备注,开局显示在玩家B中间
		InputTable.SpawnA		= { Pos = Vector( 0, 0, 0 ), Ang = Angle( 0, 0, 0 ) } --玩家A出生点
		InputTable.SpawnB		= { Pos = Vector( 0, 0, 0 ), Ang = Angle( 0, 0, 0 ) } --玩家B出生点
		InputTable.Timers		= {} --计时器,格式{ { "名称", 数字 }, { "名称", 数字 } },最后一个计时耗尽后按血量结束回合
		InputTable.DamageModify = {} --调整武器/弹射物伤害
		InputTable.Func_Init	= function( _, Core ) end --场地起始计时未开始
		InputTable.Func_Start	= function( _, Core ) end --场地起始计时开始
		InputTable.Func_Think	= function( _, Core ) end --场地每0.1秒运行一次
		InputTable.Func_Timer 	= function( _, Core, TimerID ) end --场地触发第X个计时器
		InputTable.Func_Trigger = function( _, Core, Name, Ent, Start ) end --场地触碰触发盒
		InputTable.Func_End = function( Core ) end --场地结束
		InputTable.Prop_Statics = {} --静态物品
		InputTable.Prop_Triggers = {} --触发盒
		InputTable.Prop_Entities = {} --动态物品

		for VarName, VarValue in pairs( InputTable ) do
			if DataTable[ VarName ] and type( DataTable[ VarName ] ) == type( VarValue ) then
				InputTable[ VarName ] = DataTable[ VarName ]
			end
		end
		for TimerID, Timer in pairs( InputTable.Timers ) do
			if !istable( Timer ) or !isstring( Timer[ 1 ] ) or !isnumber( Timer[ 2 ] ) then
				table.remove( InputTable.Timers, TimerID )
			else
				InputTable.Timers[ TimerID ][ 2 ] = math.Clamp( Timer[ 2 ], 1, 3600 )
			end
		end
		vsmg.tstage = vsmg.tstage +1
		vsmg.stages[ ClassName ] = InputTable
	end
	function vsmg.PickStage() --场地选择,不重复随机
		if vsmg.nstage > vsmg.tstage or vsmg.pstage == nil then
			vsmg.pstage = {}
			for k, v in RandomPairs( vsmg.stages ) do
				table.insert( vsmg.pstage, k )
			end
			vsmg.nstage = 1
		end
		if isstring( vsmg.fstage ) and istable( vsmg.stages[ vsmg.fstage ] ) then
			return vsmg.fstage
		else
			local stg = vsmg.pstage[ vsmg.nstage ]
			vsmg.nstage = vsmg.nstage +1
			return stg
		end
	end
	function vsmg.GetStage( ClassName ) --得到场地信息
		if !isstring( ClassName ) or !istable( vsmg.stages[ ClassName ] ) then return nil end
		return vsmg.stages[ ClassName ]
	end
	function vsmg.LoadFiles() --载入场地
		vsmg.stages = {}  vsmg.fstage = nil  vsmg.nstage = 0  vsmg.tstage = 0  vsmg.pstage = nil
		local fil, dir = file.Find( "somehandysents/vsmg_*.lua", "LUA" )
		if !fil or !dir then return end
		for _, out in pairs( fil ) do if out == "vsmg_core.lua" then continue end include( "somehandysents/"..out ) end
	end
	function vsmg.SpawnEntity( DataTable ) --互动物品
		local Core = vsmg.core
		if !IsValid( Core ) or !istable( DataTable ) then return end local DT = DataTable.data
		if !isstring( DataTable.name ) then DataTable.name = "Untitled" end
		if !isfunction( DT.OnSpawn ) then
			DT.OnSpawn = function( _, self )
				self:SetModel( "models/props_lab/huladoll.mdl" )
				self:SetSolid( SOLID_VPHYSICS )
			end
		end
		local prop = ents.Create( "base_anim" )
		Core:DeleteOnRemove( prop )
		DT:OnSpawn( prop )
		prop:SetPos( Core:GetPos() +DataTable.pos -prop:WorldSpaceCenter() +prop:GetPos() ) --大败笔
		prop:SetAngles( Core:GetAngles() +DataTable.ang )
		prop:DrawShadow( false )
		prop:SetOwner( Core )
		prop.VSMG_Name = DataTable.name
		prop.VSMG_Core = Core
		if isfunction( DT.OnRemove ) then
			function prop:OnRemove() if IsValid( vsmg.core ) then DT:OnRemove( prop ) end end
		end
		if isfunction( DT.OnDamaged ) then
			function prop:OnTakeDamage_VSMG( dmg )
				local atk = dmg:GetAttacker()
				if IsValid( atk ) and atk:IsPlayer() and atk:GetNWBool( "VSMG" ) and IsValid( atk:GetActiveWeapon() ) and dmg:GetInflictor() == atk then
					dmg:SetInflictor( atk:GetActiveWeapon() )
				end
				if IsValid( vsmg.core ) and !vsmg.core:GetNWBool( "VSMG_End" ) and IsValid( dmg:GetInflictor() ) and IsValid( dmg:GetAttacker() ) then
					DT:OnDamaged( prop, dmg:GetAttacker(), dmg:GetInflictor(), dmg:GetDamage(), dmg:GetDamageForce() )
				end
			end
		end
		if isfunction( DT.OnUse ) then
			function prop:Use( ent, _, typ )
				if IsValid( vsmg.core ) and !vsmg.core:GetNWBool( "VSMG_End" ) and IsValid( ent ) and ent:GetNWBool( "VSMG" ) and isnumber( typ ) then
					DT:OnUse( prop, ent, typ )
				end
			end
		else prop:SetUseType( SIMPLE_USE ) end
		if isfunction( DT.OnTouch ) then
			function prop:StartTouch( ent )
				if IsValid( vsmg.core ) and !vsmg.core:GetNWBool( "VSMG_End" ) and ent:GetNWInt( "VSMG" ) == 2 or ent:GetNWBool( "VSMG" ) then
					DT:OnTouch( prop, ent, true )
				end
			end
			function prop:EndTouch( ent )
				if  IsValid( vsmg.core ) and !vsmg.core:GetNWBool( "VSMG_End" ) and ent:GetNWInt( "VSMG" ) == 2 or ent:GetNWBool( "VSMG" ) then
					DT:OnTouch( prop, ent, false )
				end
			end
		end
		function prop:HandleAnimEvent() return true end
		if isfunction( DT.Think ) then
			local timername = "["..prop:EntIndex().."]vsmg_tick"
			timer.Create( timername, 0.1, 0, function()
				if !IsValid( prop ) or !IsValid( vsmg.core ) or vsmg.core:GetNWBool( "VSMG_End" ) then timer.Remove( timername ) return end
				local tk = DT:Think( prop )
				if tk == true then timer.Remove( timername ) end
			end )
		end
		prop:Spawn()
		prop:Activate()
		prop:SetNWInt( "VSMG", 2 ) --1静态,2实体,3触发
		vsmg.NoTool( prop )
		table.insert( Core.VSMG_Entities, prop )
	end
	function vsmg.SpawnTrigger( DataTable ) --触发盒,摸到互动物品或参与的玩家触发信号
		local Core = vsmg.core
		if !IsValid( Core ) or !istable( DataTable ) then return end
		if !isstring( DataTable.name ) then DataTable.name = "Untitled" end
		local prop = ents.Create( "base_anim" )
		Core:DeleteOnRemove( prop )
		prop:SetModel( "models/hunter/blocks/cube025x025x025.mdl" )
		prop:SetOwner( Core )
		prop:SetNoDraw( true )
		prop:SetPos( Core:GetPos() +DataTable.pos +prop:GetPos() -prop:WorldSpaceCenter() )
		prop:SetTrigger( true )
		prop:UseTriggerBounds( true, 0 )
		prop:SetNWVector( "VSMG_TMin", DataTable.mins )
		prop:SetNWVector( "VSMG_TMax", DataTable.maxs )
		prop.VSMG_Name = DataTable.name
		prop.VSMG_IsOn = true
		prop.VSMG_Core = Core
		function prop:VSMG_Toggle( bool )
			prop.VSMG_IsOn = bool
		end
		function prop:StartTouch( ent )
			if IsValid( prop ) and IsValid( Core ) and IsValid( ent ) and !Core:GetNWBool( "VSMG_End" ) and prop.VSMG_IsOn and ( ent:GetNWInt( "VSMG" ) == 2 or ent:GetNWBool( "VSMG" ) ) or vsmg.filter[ ent:GetClass() ] then
				Core:Func_Trigger( prop.VSMG_Name, ent, true )
			end
		end
		function prop:EndTouch( ent )
			if IsValid( prop ) and IsValid( Core ) and IsValid( ent ) and !Core:GetNWBool( "VSMG_End" ) and prop.VSMG_IsOn and ( ent:GetNWInt( "VSMG" ) == 2 or ent:GetNWBool( "VSMG" ) ) or vsmg.filter[ ent:GetClass() ] then
				Core:Func_Trigger( prop.VSMG_Name, ent, false )
			end
		end
		prop:Spawn()
		prop:Activate()
		prop:SetCollisionBounds( DataTable.mins, DataTable.maxs )
		prop:SetColor( Color( 192, 192, 192 ) )
		prop:SetNWInt( "VSMG", 3 )
		xdeshe_NoTool( prop )
		table.insert( Core.VSMG_Triggers, prop )
	end
	function vsmg.SpawnStatic( DataTable ) --静态物品
		local Core = vsmg.core
		if !IsValid( Core ) or !istable( DataTable ) then return end local DT = DataTable
		if !isstring( DT.name ) then DT.name = "Untitled" end
		local prop = ents.Create( "prop_dynamic" )
		Core:DeleteOnRemove( prop )
		prop:SetModel( DT.mdl )
		prop:SetPos( Core:GetPos() +DT.pos +prop:GetPos() -prop:WorldSpaceCenter() )
		prop:SetAngles( Core:GetAngles() +DataTable.ang )
		prop:SetOwner( Core )
		prop:SetSolid( SOLID_VPHYSICS )
		prop:SetRenderMode( RENDERMODE_TRANSCOLOR )
		prop:SetCollisionGroup( COLLISION_GROUP_NONE )
		local col = Color( 255, 255, 255 )
		if isnumber( DT.pcolor ) and DT.pcolor > 0 and IsValid( Core.VSMG_PA ) and IsValid( Core.VSMG_PB ) and IsValid( vsmg.entity ) then
			if DT.pcolor == 1 then col = Core.VSMG_CA
			elseif DT.pcolor == 2 then col = Core.VSMG_CB end
			prop:SetMaterial( "phoenix_storms/wood_dome" )
		else
			prop:SetMaterial( math.random( 1, 2 ) == 1 and "phoenix_storms/wood_dome" or "phoenix_storms/wood_side" )
		end
		prop:SetColor( col )
		prop:DrawShadow( false )
		prop:Spawn()
		prop:Activate()
		prop:SetNWInt( "VSMG", 1 )
		xdeshe_NoTool( prop )
		prop.VSMG_Core = Core
		table.insert( Core.VSMG_Statics, prop )
	end
	function vsmg.CreateStage( ClassName ) --创建场地
		local Core = vsmg.core
		if !IsValid( Core ) or !isstring( ClassName ) or !istable( vsmg.stages[ ClassName ] ) then return end
		local STG = vsmg.GetStage( ClassName )
		Core.VSMG_Statics = {}  Core.VSMG_Triggers = {}  Core.VSMG_Entities = {}
		Core.VSMG_CA = vsmg.GetTeamColor( 1, 1 )
		Core.VSMG_CB = vsmg.GetTeamColor( 2, 1 )
		for K, V in pairs( STG.Prop_Statics ) do vsmg.SpawnStatic( V ) end
		for K, V in pairs( STG.Prop_Entities ) do vsmg.SpawnEntity( V ) end
		for K, V in pairs( STG.Prop_Triggers ) do vsmg.SpawnTrigger( V ) end
		Core.SpawnA = STG.SpawnA  Core.SpawnB = STG.SpawnB  Core.Timers = STG.Timers
		Core.DamageModify = STG.DamageModify  Core.Func_Init = STG.Func_Init  Core.Func_End = STG.Func_End
		Core.Func_Start = STG.Func_Start  Core.Func_Think = STG.Func_Think  Core.Func_Timer = STG.Func_Timer  Core.Func_Trigger = STG.Func_Trigger
		if GetConVar( "developer" ):GetInt() > 0 then
			vsmg.SpawnStatic( { mdl = "models/editor/playerstart.mdl", pos = STG.SpawnA.Pos, ang = STG.SpawnA.Ang, pcolor = 1 } )
			vsmg.SpawnStatic( { mdl = "models/editor/playerstart.mdl", pos = STG.SpawnB.Pos, ang = STG.SpawnB.Ang, pcolor = 2 } )
		end
	end
	function vsmg.GetEntities( Name ) --查找实体
		local Core = vsmg.core
		if !IsValid( Core ) then return {} end
		if !istable( Core.VSMG_Entities ) then return {} end
		if !isstring( Name ) or #Core.VSMG_Entities <= 0 then return Core.VSMG_Entities end
		local out = {}
		for k, v in pairs( Core.VSMG_Entities ) do
			if !IsValid( v ) then table.remove( out, k ) continue end
			if isstring( v.VSMG_Name ) and v.VSMG_Name == Name then
				table.insert( out, v )
			end
		end
		return out
	end
	function vsmg.GetTeamSide( Side ) --从1,2得到玩家阵营
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Core ) or !isnumber( Side ) or !IsValid( Ent ) or Ent:GetXDE_State() != 2 then return 0 end
		if Side == 1 then
			if Ent:GetXDE_PA() == Core.VSMG_PA then return 1
			elseif Ent:GetXDE_PB() == Core.VSMG_PA then return 2 end
		elseif Side == 2 then
			if Ent:GetXDE_PA() == Core.VSMG_PB then return 1
			elseif Ent:GetXDE_PB() == Core.VSMG_PB then return 2 end
		end
		return 0
	end
	function vsmg.GetTeamColor( Side, Bright ) --从1,2得到玩家AB的阵营颜色
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Core ) or ( Side != 1 and Side != 2 ) or !IsValid( Ent ) then return Color( 192, 192, 192 ) end
		if !isnumber( Bright ) then Bright = 1 end
		local PA, PB = Core.VSMG_PA, Core.VSMG_PB
		if !IsValid( PA ) or !IsValid( PB ) then return Color( 192, 192, 192 ) end
		local Co1 = Color( 192*Bright, 192*Bright, 192*Bright )
		local Co2 = Color( 0*Bright, 192*Bright, 192*Bright )
		local Co3 = Color( 192*Bright, 0*Bright, 0*Bright )
		if Side == 1 then
			if Ent:GetXDE_PA() == Core.VSMG_PA then return Co3
			elseif Ent:GetXDE_PB() == Core.VSMG_PA then return Co2 end
		elseif Side == 2 then
			if Ent:GetXDE_PA() == Core.VSMG_PB then return Co3
			elseif Ent:GetXDE_PB() == Core.VSMG_PB then return Co2 end
		end
		return Co1
	end
	function vsmg.GetTeamPlayer( Player ) --从玩家实体得到玩家阵营
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Core ) or !Player:IsPlayer() or !Player:GetNWBool( "VSMG" ) or !IsValid( Ent ) then return 0 end
		if Player == Core.VSMG_PA then return 1 elseif Player == Core.VSMG_PB then return 2 end
		return 0
	end
	function vsmg.WinFigure( Side ) --获胜检测,通常为血多获胜
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Core ) or !IsValid( Ent ) or !isnumber( Side ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( Core.VSMG_PA ) or !IsValid( Core.VSMG_PB ) or Core:GetNWBool( "VSMG_End" ) then return end
		local PA, PB = Core.VSMG_PA, Core.VSMG_PB
		if Side == 1 then
			Ent:VSMG_Result( vsmg.GetTeamSide( 1 ) )
		elseif Side == 2 then
			Ent:VSMG_Result( vsmg.GetTeamSide( 2 ) )
		elseif Side == 0 then
			local PA2, PB2 = Ent:GetXDE_PA(), Ent:GetXDE_PB()
			if PA2:Health() > PB2:Health() then Ent:VSMG_Result( 1 )
			elseif PA2:Health() < PB2:Health() then Ent:VSMG_Result( 2 )
			else Ent:VSMG_Result( 0 ) end
		end
		Core:SetNWBool( "VSMG_End", true )
	end
	function vsmg.MakeRagdoll( who, force ) --创建布娃娃
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Core ) or !IsValid( Ent ) or !IsValid( who ) or !who:IsPlayer() or !isstring( who:GetModel() )
		or !who:GetNWBool( "VSMG" ) or !IsValid( vsmg.entity ) or who.VSMG_Dead then return end
		if !isvector( force ) then force = Vector( 0, 0, 1 ) end
		who.VSMG_Dead = true  who:SetVelocity( Vector( 0, 0, 0 ) )
		local body = xdeshe_BecomeRagdoll( who )
		body:SetName( "["..body:EntIndex().."]vsmg_body" )
		body:GetPhysicsObject():SetVelocity( force )
		body.VSMG_Dissolve = ents.Create( "env_entity_dissolver" )
		body.VSMG_Dissolve:SetOwner( body )
		body:DeleteOnRemove( body.VSMG_Dissolve )
		body.VSMG_Dissolve:SetKeyValue( "target", body:GetName() )
		body.VSMG_Dissolve:SetKeyValue( "dissolvetype", 0 )
		body.VSMG_Dissolve:SetOwner( Entity( 0 ) ) body.VSMG_Dissolve:Spawn()
		body.VSMG_Dissolve:Fire( "Dissolve", body:GetName(), 0 )
		SafeRemoveEntityDelayed( body, 3 )
		if !Core:GetNWBool( "VSMG_End" ) then
			if Core.VSMG_PA == who then vsmg.WinFigure( 2 )
			elseif Core.VSMG_PB == who then vsmg.WinFigure( 1 ) end
		end
	end
	function vsmg.SetInfiniteAmmo( ply, ammo, num ) --玩家无限子弹(玩家,子弹类型,子弹数量)
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Ent ) or !IsValid( Core ) or Core:GetNWBool( "VSMG_End" ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( ply ) or !ply:IsPlayer() or !ply:GetNWBool( "VSMG" ) or !isstring( ammo ) or !isnumber( num ) then return end
		if num > 0 then
			if !istable( ply.VSMG_InfAmmo ) then ply.VSMG_InfAmmo = { [ ammo ] = num } else ply.VSMG_InfAmmo[ ammo ] = num end
		else
			if istable( ply.VSMG_InfAmmo ) and isnumber( ply.VSMG_InfAmmo[ ammo ] ) then table.remove( ply.VSMG_InfAmmo, ammo ) end
		end
	end
	function vsmg.SetGodMode( ply, yes ) --玩家无敌模式
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Ent ) or !IsValid( Core ) or Core:GetNWBool( "VSMG_End" ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( ply ) or !ply:IsPlayer() or !ply:GetNWBool( "VSMG" ) or !isbool( yes ) then return end ply.VSMG_GodMode = yes
	end
	function vsmg.TakeDamage( who, dmg, force ) --玩家受伤
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Ent ) or !IsValid( Core ) or Core:GetNWBool( "VSMG_End" ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( who ) or !who:IsPlayer() or !isstring( who:GetModel() ) or !who:GetNWBool( "VSMG" ) or who.VSMG_Dead then return end
		if !isnumber( dmg ) then return end  if !isvector( force ) then force = Vector( 0, 0, 1 ) end
		local arm = vsmg.GetArmor( who )
		if arm > 0 then
			if arm >= dmg then
				vsmg.SetArmor( who, arm -dmg )
				dmg = math.ceil( dmg*0.5 )
			else
				local dmg2 = ( dmg -arm )
				dmg = ( ( dmg-dmg2 ) +dmg2*0.5 )
				vsmg.SetArmor( who, 0 )
			end
		end
		if vsmg.GetHealth( who ) -dmg < 1 then
			vsmg.MakeRagdoll( who, force )
		else
			vsmg.SetHealth( who, vsmg.GetHealth( who ) -dmg )
			who:SetVelocity( force )
		end
	end
	function vsmg.GiveWeapon( who, cls, typ ) --给予武器,可指定无限子弹
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Ent ) or !IsValid( Core ) or Core:GetNWBool( "VSMG_End" ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( who ) or !who:IsPlayer() or !who:GetNWBool( "VSMG" ) or who.VSMG_Dead then return end
		if !isstring( cls ) or who:HasWeapon( cls ) then return end who:Give( cls, true )  local wep = who:GetWeapon( cls )
		if IsValid( wep ) and wep:GetMaxClip1() > 0 then
			if !isnumber( typ ) then wep:SetClip1( 0 ) else
				if typ == 0 then wep:SetClip1( 0 )
				elseif typ == 1 then wep:SetClip1( wep:GetMaxClip1() )
				elseif typ == 2 then wep.VSMG_InfAmmo = true  wep:SetClip1( wep:GetMaxClip1() ) end
			end
		end
	end
	function vsmg.SetHealth( who, hp ) --设置血量
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Ent ) or !IsValid( Core ) or Core:GetNWBool( "VSMG_End" ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( who ) or !who:IsPlayer() or !who:GetNWBool( "VSMG" ) or who.VSMG_Dead then return 0 end
		hp = math.Clamp( hp, 0, 2147483647 )
		who:SetNWInt( "VSMG_Health", hp )
		who:SetHealth( math.max( 1, hp ) )
	end
	function vsmg.SetArmor( who, ap ) --设置护甲
		local Core, Ent = vsmg.core, vsmg.entity
		if !IsValid( Ent ) or !IsValid( Core ) or Core:GetNWBool( "VSMG_End" ) or Ent:GetXDE_State() != 2 then return end
		if !IsValid( who ) or !who:IsPlayer() or !who:GetNWBool( "VSMG" ) or who.VSMG_Dead then return 0 end
		ap = math.Clamp( ap, 0, 2147483647 )
		who:SetNWInt( "VSMG_Armor", ap )
		who:SetArmor( math.max( 0, ap ) )
	end
	function vsmg.GetHealth( who ) --得到血量
		return IsValid( who ) and who:GetNWInt( "VSMG_Health" ) or 0
	end
	function vsmg.GetArmor( who ) --得到护甲
		return IsValid( who ) and who:GetNWInt( "VSMG_Armor" ) or 0
	end
	function vsmg.NoTool( ent, inv )
		if !IsValid( ent ) then return end
		if isbool( inv ) and inv == true then
			ent.vsmg_NoTool = false
		else
			ent.vsmg_NoTool = true
		end
	end
	vsmg.LoadFiles()

	hook.Add( "EntityTakeDamage", "vsmg_etd", function( tar, dmg )
		if IsValid( vsmg.core ) and IsValid( vsmg.entity ) and IsValid( tar ) then
			local Core, Ent, PA, PB = vsmg.core, vsmg.entity, vsmg.entity:GetXDE_PA(), vsmg.entity:GetXDE_PB()
			local inf, atk = dmg:GetInflictor(), dmg:GetAttacker()
			if tar.VSMG_Immune and ( !IsValid( atk ) or !atk:GetNWBool( "VSMG" ) )then
				dmg:ScaleDamage( 0 ) dmg:SetAttacker( Entity( 0 ) )
				dmg:SetInflictor( Entity( 0 ) ) dmg:SetDamageType( DMG_GENERIC )
				return true
			end
			if tar:GetNWBool( "VSMG" ) or ( IsValid( atk ) and atk:GetNWBool( "VSMG" ) ) then
				if ( !IsValid( inf ) or inf == atk ) and atk:IsPlayer() and IsValid( atk:GetActiveWeapon() ) then inf = atk:GetActiveWeapon() end
				if Ent:GetXDE_State() == 2 and Ent:GetXDE_Delay() <= 0 and IsValid( inf ) and !Core:GetNWBool( "VSMG_End" )
				and ( ( istable( Core.DamageModify ) and istable( Core.DamageModify[ inf:GetClass() ] ) ) or tar.VSMG_Immune ) then
					local Dmg, Fce = 0, 0
					if inf != Entity( 0 ) and istable( Core.DamageModify[ inf:GetClass() ] ) then
						local Wat = Core.DamageModify[ inf:GetClass() ]
						if math.floor( dmg:GetDamage() ) > 0 then
							Dmg = Wat[ 1 ] == -1 and dmg:GetDamage() or math.Clamp( Wat[ 1 ], 0, 2147483647 )
							Fce = Wat[ 1 ] == -1 and dmg:GetDamage() or math.Clamp( Wat[ 2 ], 0, 16384 )
						end
					end
					if Fce > 0 then
						local tof = dmg:GetDamageForce():GetNormal()*Fce
						tar:SetVelocity( tof )
						if IsValid( tar:GetPhysicsObject() ) then
							tar:TakePhysicsDamage( dmg )
						end
					end
					if tar:GetClass() == "base_anim" and tar:GetNWInt( "VSMG" ) == 2 and isfunction( tar.OnTakeDamage_VSMG ) then
						dmg:SetDamage( Dmg ) tar:OnTakeDamage_VSMG( dmg )
					end
					if Dmg > 0 and !tar.VSMG_GodMode then
						if tar:IsPlayer() then local lt = tar:LastHitGroup()
							if lt <= 0 then lt = 1 end
							local Dmgs = { 1, 2, 1, 1, 0.25, 0.25, 0.25, 0.25, 0.25, 0.01 }
							if isnumber( Dmgs[ lt ] ) then Dmg = Dmg*Dmgs[ lt ] end
							vsmg.TakeDamage( tar, Dmg, dmg:GetDamageForce():GetNormal()*Fce )
						end
					end
				end
				if tar:IsPlayer() then
					dmg:ScaleDamage( 0 ) dmg:SetAttacker( Entity( 0 ) )
					dmg:SetInflictor( Entity( 0 ) ) dmg:SetDamageType( DMG_GENERIC )
					return true
				end
			end
		end
	end )
	hook.Add( "StartCommand", "vsmg_sc", function( ply, cmd )
		if SERVER and ply:Alive() and ply:GetNWBool( "VSMG" ) then
			if !IsValid( vsmg.entity ) then ply:SetNWBool( "VSMG", false )
			elseif IsValid( ply:GetActiveWeapon() ) then local wep = ply:GetActiveWeapon()
				if wep.VSMG_InfAmmo and wep:GetMaxClip1() > 0 then
					if wep:Clip1() < wep:GetMaxClip1() then wep:SetClip1( wep:GetMaxClip1() ) end
				end
				if istable( ply.VSMG_InfAmmo ) then
					local amo1 = wep:GetPrimaryAmmoType()  local amo2 = wep:GetSecondaryAmmoType()
					if amo1 != -1 or amo2 != -1 then local typ1 = game.GetAmmoName( amo1 )  local typ2 = game.GetAmmoName( amo2 )
						local inf1 = ply.VSMG_InfAmmo[ typ1 ]  local inf2 = ply.VSMG_InfAmmo[ typ2 ]
						if isstring( typ1 ) then  local inf1 = ply.VSMG_InfAmmo[ typ1 ]
							if isnumber( inf1 ) and inf1 > 0 and ply:GetAmmoCount( typ1 ) < inf1 then ply:SetAmmo( inf1, typ1 ) end
						end
						if isstring( typ2 ) then  local inf2 = ply.VSMG_InfAmmo[ typ2 ]
							if isnumber( inf2 ) and inf2 > 0 and ply:GetAmmoCount( typ2 ) < inf2 then ply:SetAmmo( inf2, typ2 ) end
						end
					end
				end
			end
		end
	end )
	hook.Add( "PlayerDeathThink", "vsmg_pdt", function( ply )
		if ply:GetNWBool( "VSMG" ) then
			if ply.VSMG_Dead then return false end
			if !ply.VSMG_Pos then
				ply.VSMG_Pos = ply:GetPos()
				local ang = ply:EyeAngles()
				ply:Spawn()
				timer.Simple( 0, function()
					if IsValid( ply ) and !ply:Alive() and ply:GetNWBool( "VSMG" ) and !ply.VSMG_Dead then
						ply:SetPos( ply.VSMG_Pos )
						ply:SetEyeAngles( ply:EyeAngles() )
						ply.VSMG_Pos = nil
					end
				end )
			end
		end
	end )
	hook.Add( "PlayerDeath", "vsmg_pd", function( ply )
		if IsValid( ply ) and ply:GetNWBool( "VSMG" ) and !ply.VSMG_Dead then
			vsmg.MakeRagdoll( ply, Vector( 0, 0, 1 ) )
			return false
		end
	end )

	net.Receive( "NET_VSMG_Withdraw", function( len, ply )
		if !IsValid( ply ) or !ply:Alive() or len > 0 or !ply:GetNWBool( "VSMG" ) then return end
		if !IsValid( vsmg.entity ) or !IsValid( vsmg.core ) then return end
		local Core, Ent, PA, PB = vsmg.core, vsmg.entity, vsmg.entity:GetXDE_PA(), vsmg.entity:GetXDE_PB()
		if !IsValid( PA ) or !IsValid( PB ) then return end
		if timer.Exists( "["..Ent:EntIndex().."]nextstage" ) then
			xdeshe_ChatMessage( ply, "You can't surrender for now!", "!V" )
			return
		end
		if ply == PA then Ent:SetXDE_WinB( 8 )
			xdeshe_ChatMessage( PA, "You surrendered to "..PB:Nick().."!", "!V" )
			xdeshe_ChatMessage( PB, PA:Nick().." surrendered to you!", "!V" )
		elseif ply == PB then Ent:SetXDE_WinA( 8 )
			xdeshe_ChatMessage( PB, "You surrendered to "..PA:Nick().."!", "!V" )
			xdeshe_ChatMessage( PA, PB:Nick().." surrendered to you!", "!V" )
		end Ent:VSMG_Result( 0, true )
	end )
else

	xdeshe_stars = CreateMaterial( "vsmgstars", "UnlitGeneric", { --这样就不需要写vmt了吧
		[ "$basetexture" ] 			= "skybox/starfield",
		[ "$nofog" ] 				= 1,
		[ "$no_fullbright" ] 		= 1,
		[ "Proxies" ] 		= {
			[ "TextureScroll" ] = {
				[ "texturescrollvar" ] 		= "$basetexturetransform",
				[ "texturescrollrate" ] 	= 0.002,
				[ "texturescrollangle" ] 	= -45
			}
		}
	} )
	hook.Add( "PostDrawTranslucentRenderables", "vsmg_pde", function() local ply = LocalPlayer()
		for _, self in ipairs( ents.FindByClass( "sent_she_vsmg" ) ) do
			if IsValid( self ) and !self:GetNoDraw() and self:GetXDE_SavePos() and xdeshe_stars then
				local siz, pos, stt = 2500, self:GetXDE_SavePos(), self:GetXDE_State()
				if stt > 0 and !ply:GetNWBool( "VSMG" ) then
					render.SetColorMaterial()
					cam.Start3D()
					render.DrawBox( pos, Angle( 0, 0, 0 ), Vector( -siz, -siz, siz ), Vector( siz, siz, -siz ), Color( 255, 0, 0, 128 ) )
					render.DrawBox( pos, Angle( 0, 0, 0 ), Vector( -siz, -siz, -siz ), Vector( siz, siz, siz ), Color( 255, 0, 0, 128 ) )
					render.DrawWireframeBox( pos, Angle( 0, 0, 0 ), Vector( -siz, -siz, -siz ), Vector( siz, siz, siz ), Color( 0, 0, 0, 128 ) )
					cam.End3D()
				elseif stt >= 2 then
					render.SetMaterial( xdeshe_stars )
					render.SuppressEngineLighting( true )
					cam.Start3D()
					render.DrawSphere( pos, -siz*2, 64, 64, Color( 255, 255, 255 ) )
					cam.End3D()
					render.SuppressEngineLighting( false )
				end
			end
		end
		if GetConVar( "developer" ):GetInt() > 2 then
			cam.Start3D()
			render.SetColorMaterial()
			for k, v in ipairs( ents.FindByClass( "base_anim" ) ) do
				if v:GetNWInt( "VSMG" ) > 0 then
					local vsd = v:GetNWInt( "VSMG" )  local mii, maa = v:GetCollisionBounds()
					local col = ( vsd == 1 and Color( 255, 255, 255 ) or ( vsd == 2 and Color( 0, 255, 255 ) or Color( 255, 0, 0 ) ) )
					render.DrawWireframeBox( v:GetPos(), v:GetAngles(), mii, maa, Color( col.r, col.g, col.b, 128 ) )
					if vsd == 3 then
						local mii, maa = v:GetNWVector( "VSMG_TMin" ), v:GetNWVector( "VSMG_TMax" )
						render.DrawWireframeBox( v:GetPos(), v:GetAngles(), mii, maa, Color( 255, 255, 0, 128 ) )
					end
				end
			end
			cam.End3D()
		end
	end )
	hook.Add( "ContextMenuOpen", "vsmg_cmo", function() local ply = LocalPlayer()
		if LocalPlayer():GetNWBool( "VSMG" ) then xdeshe_MenuOpen( ply, "vsmg_withdraw", nil, "_" )
			return false
		end
	end )
	hook.Add( "HUDDrawTargetID", "vsmg_huddtid", function() local ply = LocalPlayer()
		if ply:GetNWBool( "VSMG" ) then
			if !IsValid( vsmg.entity ) then
				for k, v in pairs( ents.FindByClass( "sent_she_vsmg" ) ) do
					if IsValid( v ) then vsmg.entity = v break end
				end
			else
				local tar = util.TraceLine( util.GetPlayerTrace( LocalPlayer() ) ).Entity
				if !IsValid( tar ) or !tar:IsPlayer() or !tar:GetNWBool( "VSMG" ) then return false end
				local text = tar:Nick()  local font = "TargetID"  local Col = nil
				if vsmg.entity:GetXDE_PB() == tar then Col = Color( 0, 255, 255 )
				elseif vsmg.entity:GetXDE_PA() == tar then Col = Color( 255, 0, 0 ) end
				if Col == nil then return false end
				surface.SetFont( font )  local w, h = surface.GetTextSize( text )  local MouseX, MouseY = gui.MousePos()
				if MouseX == 0 and MouseY == 0 then MouseX = ScrW() / 2 MouseY = ScrH() / 2 end  local x = MouseX  local y = MouseY
				x = x -w/2  y = y +30
				draw.SimpleText( text, font, x + 1, y + 1, Color( 0, 0, 0, 120 ) )
				draw.SimpleText( text, font, x + 2, y + 2, Color( 0, 0, 0, 50 ) )
				draw.SimpleText( text, font, x, y, Col )
				y = y + h + 5  local text = "HP:"..tar:Health().."%"  local font = "TargetIDSmall"
				surface.SetFont( font )  local w, h = surface.GetTextSize( text )  local x = MouseX - w / 2
				draw.SimpleText( text, font, x + 1, y + 1, Color( 0, 0, 0, 120 ) )
				draw.SimpleText( text, font, x + 2, y + 2, Color( 0, 0, 0, 50 ) )
				draw.SimpleText( text, font, x, y, Col )
				y = y + h + 5  local text = "AP:"..tar:Armor().."%"  local font = "TargetIDSmall"
				surface.SetFont( font )  local w, h = surface.GetTextSize( text )  local x = MouseX - w / 2
				draw.SimpleText( text, font, x + 1, y + 1, Color( 0, 0, 0, 120 ) )
				draw.SimpleText( text, font, x + 2, y + 2, Color( 0, 0, 0, 50 ) )
				draw.SimpleText( text, font, x, y, Col )
			end
			return false
		end
	end )

	net.Receive( "NET_VSMG_HUDNotify", function()
		local pan = xdeshe_vguis[ "vsmg" ]  if !IsValid( pan ) then return end
		pan:ReceiveNotify( util.JSONToTable( net.ReadString() ) )
	end )
	net.Receive( "NET_VSMG_WinNotice", function( len, ply )
		local PA, PB, CL = net.ReadString(), net.ReadString(), net.ReadBool()
		chat.AddText( CL and Color( 0, 196, 196 ) or Color( 196, 0, 0 ), PA.." "..language.GetPhrase( "xdeshe.Won" ).." "..PB.."!" )
	end )

	local Mat, Ma2, Ma3 = xdeshe_OnceMat( "vgui/gradient-r" ), xdeshe_OnceMat( "vgui/hud/survivaltimerclock" ), xdeshe_OnceMat( "vgui/hud/survivaltimerclockface" )
	xdeshe_MenuRegister( "vsmg", function( id, ent, dat )
		if !IsValid( ent ) or !IsValid( ent:GetXDE_PA() ) or !IsValid( ent:GetXDE_PB() ) then return end
		local pan = vgui.Create( "DFrame" )  local ply = LocalPlayer()
		pan:SetKeyboardInputEnabled( false ) pan:SetMouseInputEnabled( false )
		pan:SetTitle( "" )
		pan:SetDraggable( false )
		pan:ShowCloseButton( false )
		pan:SetSize( 800, 0 )
		pan:SizeTo( 800, 200, 1, 2 )
		pan:SetPos( ScrW()/2 -400, 8 )
		pan:SetAlpha( 1 )
		pan:AlphaTo( 255, 1, 2 )
		pan:SetDeleteOnClose( true )
		pan.N_Flush = CurTime() +3
		pan.E_Entity = ent
		pan.E_PA = ent:GetXDE_PA()  pan.E_PB = ent:GetXDE_PB()
		pan.N_Round = 0
		pan.N_WinA = 0
		pan.N_WinB = 0
		pan.S_Timer = ""
		pan.N_NTimer = 0
		pan.N_MTimer = 0
		pan.N_TTimer = 0
		timer.Simple( 0.4, function()
			if IsValid( pan ) then surface.PlaySound( "ambient/alarms/warningbell1.wav" ) end
		end )
		function pan:Paint( w, h )
			if !IsValid( pan.E_PA ) or !IsValid( pan.E_PB ) or !IsValid( pan.E_Entity ) then return end
			draw.RoundedBox( 0, 0, 0, 220 +75, 5, Color( 192, 0, 0 ) )
			draw.RoundedBox( 0, 504, 0, 220 +75, 5, Color( 0, 192, 192 ) )
			draw.RoundedBox( 0, 305, 0, 190, 5, Color( 192, 0, 0 ) )
			surface.SetMaterial( Mat ) surface.SetDrawColor( 0, 192, 192 ) surface.DrawTexturedRect( 305, 0, 190, 5 )
			draw.RoundedBoxEx( 32, 0, 5, 220 +75, 45, Color( 96, 64, 64 ), false, false, true, false )
			draw.RoundedBoxEx( 32, 504, 5, 220 +75, 45, Color( 64, 64, 96 ), false, false, false, true )
			draw.RoundedBoxEx( 32, 305, 5, 190, 90, Color( 64, 64, 64 ), false, false, true, true )
			draw.TextShadow( {
				text = language.GetPhrase( "xdeshe.BR29" ),
				pos = { w/2, 30 },
				font = "xdeshe_Font3",
				xalign = TEXT_ALIGN_CENTER,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( 255, 255, 255 )
			}, 1, 255 )
			draw.TextShadow( {
				text = pan.N_Round.." / 16",
				pos = { w/2, 70 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_CENTER,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( 255, 255, 255 )
			}, 1, 255 )
			if pan.S_Timer != "" then
				local per = math.Clamp( ( pan.N_NTimer -CurTime() )/pan.N_MTimer, 0, 1 )
				local tim = math.max( 0, pan.N_NTimer -CurTime() )
				local min = math.floor( tim/60 )  local sec = ( tim -min*60 )  local mmm = math.floor( sec )  local ccc = Color( 255, 255, 255 )
				if pan.N_TTimer != mmm then
					pan.N_TTimer = mmm  if min <= 0 and pan.N_TTimer <= 5 then surface.PlaySound( "ui/beep07.wav" ) end
				end
				if min <= 0 and mmm <= 5 then ccc = Color( 255, 0, 0 ) elseif per < 0.5 then ccc = Color( 255, 255, 0 ) end
				surface.SetMaterial( Ma2 ) surface.SetDrawColor( 255, 255, 255 ) surface.DrawTexturedRect( w/2 -122, h/2 +8, 96, 96 )
				surface.SetMaterial( Ma3 ) surface.SetDrawColor( ccc ) xdeshe_Circle( w/2 -74, h/2 +56, 48, 100, per )
				draw.TextShadow( {
					text = language.GetPhrase( pan.S_Timer ),
					pos = { w/2 -32, 135 },
					font = "xdeshe_Font3",
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER,
					color = ccc
				}, 1, 255 )
				draw.TextShadow( {
					text = xdeshe_SNum( min )..":"..xdeshe_SNum( mmm )..":"..xdeshe_SNum( math.floor( ( sec -mmm )*100 ) ),
					pos = { w/2 -32, 170 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER,
					color = ccc
				}, 1, 255 )
			elseif pan.N_TTimer != -1 then pan.N_TTimer = -1 end
			draw.TextShadow( {
				text = pan.E_PA:Nick(),
				pos = { 246, 42 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_RIGHT,
				yalign = TEXT_ALIGN_BOTTOM,
				color = Color( 255, 255, 255 )
			}, 1, 255 )
			draw.TextShadow( {
				text = pan.E_PB:Nick(),
				pos = { 554, 42 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_LEFT,
				yalign = TEXT_ALIGN_BOTTOM,
				color = Color( 255, 255, 255 )
			}, 1, 255 )
			draw.NoTexture()
			for i=1, 8 do
				surface.SetDrawColor( 96, 64, 64 ) xdeshe_Circle( w/2 -122 -30*( i-1 ), 100 -30, 14, 4 )
				surface.SetDrawColor( 192, 0, 0 ) xdeshe_Circle( w/2 -122 -30*( i-1 ), 100 -30, 12, 4 )
				surface.SetDrawColor( pan.N_WinA >= i and Color( 255, 255, 255 ) or Color( 0, 0, 0 ) ) xdeshe_Circle( w/2 -122 -30*( i-1 ), 100 -30, 8, 4 )
			end
			for i=1, 8 do
				surface.SetDrawColor( 64, 96, 96 ) xdeshe_Circle( w/2 +120 +30*( i-1 ), 100 -30, 14, 4 )
				surface.SetDrawColor( 0, 192, 192 ) xdeshe_Circle( w/2 +120 +30*( i-1 ), 100 -30, 12, 4 )
				surface.SetDrawColor( pan.N_WinB >= i and Color( 255, 255, 255 ) or Color( 0, 0, 0 ) ) xdeshe_Circle( w/2 +120 +30*( i-1 ), 100 -30, 8, 4 )
			end
		end
		function pan:Think()
			if !IsValid( pan.E_PA ) or !IsValid( pan.E_PB ) or !IsValid( pan.E_Entity ) then pan:Remove() return end
			if pan.N_Flush > 0 and pan.N_Flush <= CurTime() then
				pan.N_Flush = 0
				if pan.P_SA then pan.P_SA:Remove() end if pan.P_SA then pan.P_SB:Remove() end if pan.P_VS then pan.P_VS:Remove() end
			end
		end
		function pan:OnRemove()
			if pan.P_SA then pan.P_SA:Remove() end if pan.P_SA then pan.P_SB:Remove() end if pan.P_PL then pan.P_PL:Remove() end
			if pan.P_VS then pan.P_VS:Remove() end if pan.P_IF then pan.P_IF:Remove() end if pan.P_CD then pan.P_CD:Remove() end
			if pan.P_SC then pan.P_SC:Remove() end
		end
		if true then --头像框A
			pan.P_FA = pan:Add( "DPanel" )  local pax = pan.P_FA
			pax:SetPos( 256 -2, 12 -2 ) pax:SetSize( 36, 36 )
			function pax:Paint( w, h )
				surface.SetDrawColor( 192, 0, 0 ) surface.DrawRect( 0, 0, w, h )
			end
			pan.P_PA = pan:Add( "AvatarImage" )  local pax = pan.P_PA
			pax:SetPos( 256, 12 ) pax:SetSize( 32, 32 )
			pax:SetPlayer( pan.E_PA, 64 )
		end
		if true then --头像框B
			pan.P_FB = pan:Add( "DPanel" )  local pax = pan.P_FB
			pax:SetPos( 512 -2, 12 -2 ) pax:SetSize( 36, 36 )
			function pax:Paint( w, h )
				surface.SetDrawColor( 0, 192, 192 ) surface.DrawRect( 0, 0, w, h )
			end
			pan.P_PB = pan:Add( "AvatarImage" )  local pax = pan.P_PB
			pax:SetPos( 512, 12 ) pax:SetSize( 32, 32 )
			pax:SetPlayer( pan.E_PB, 64 )
		end
		local Mat, Ma2, Ma3 = Material( "vgui/gradient-l" ), Material( "vgui/gradient-r" ), Material( "vgui/gradient_up" )
		if true then --VS动画A
			pan.P_SA = vgui.Create( "DPanel" )  local pax = pan.P_SA
			pax:SetPos( ScrW()/2 -400 -30 -128, ScrH()/2 -90 )  pax:SetSize( 400, 60 )
			pax:MoveTo( ScrW()/2 -400 -30, ScrH()/2 -90, 0.5 )
			pax:SetAlpha( 1 ) pax:AlphaTo( 255, 0.5 )
			pax:MoveTo( ScrW()/2 -400 -30 +128, ScrH()/2 -90 -128, 1, 2 ) pax:AlphaTo( 0, 1, 2 )
			function pax:Paint( w, h )
				draw.NoTexture()
				surface.SetDrawColor( 128, 0, 0 ) xdeshe_CutBox( h/2, 0, 0, w, h, false, false, true, false )
				surface.SetDrawColor( 196, 0, 0 ) xdeshe_CutBox( ( h-2 )/2, 2, 2, w -4, h -4, false, false, true, false )
				surface.SetMaterial( Mat ) surface.SetDrawColor( 128, 0, 0 )
				surface.DrawTexturedRect( 2, 2, w*0.75 -4, h -4 )
				surface.SetDrawColor( 196, 0, 0 ) surface.DrawOutlinedRect( 4, 4, 52, 52 )
				draw.TextShadow( {
					text = pan.E_PA:Nick(),
					pos = { 64, h/2 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
			end
			pan.P_PA2 = pan.P_SA:Add( "AvatarImage" )  local pax = pan.P_PA2
			pax:SetPos( 6, 6 ) pax:SetSize( 48, 48 )
			pax:SetPlayer( pan.E_PA, 64 )
		end
		if true then --VS动画B
			pan.P_SB = vgui.Create( "DPanel" )  local pax = pan.P_SB
			pax:SetPos( ScrW()/2 +30 +128, ScrH()/2 +15 )  pax:SetSize( 400, 60 )
			pax:MoveTo( ScrW()/2 +30, ScrH()/2 +15, 0.5 )
			pax:SetAlpha( 1 ) pax:AlphaTo( 255, 0.5 )
			pax:MoveTo( ScrW()/2 +30 -128, ScrH()/2 +15 +128, 1, 2 ) pax:AlphaTo( 0, 1, 2 )
			function pax:Paint( w, h )
				draw.NoTexture()
				surface.SetDrawColor( 0, 128, 128 ) xdeshe_CutBox( h/2, 0, 0, w, h, true, false, false, false )
				surface.SetDrawColor( 0, 196, 196 ) xdeshe_CutBox( ( h-2 )/2, 2, 2, w -4, h -4, true, false, false, false )
				surface.SetMaterial( Ma2 ) surface.SetDrawColor( 0, 128, 128 )
				surface.DrawTexturedRect( 2 +w*0.25, 2, w*0.75 -4, h -4 )
				surface.SetDrawColor( 0, 196, 196 ) surface.DrawOutlinedRect( 344, 4, 52, 52 )
				draw.TextShadow( {
					text = pan.E_PB:Nick(),
					pos = { w -64, h/2 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_RIGHT,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
			end
			pan.P_PB2 = pan.P_SB:Add( "AvatarImage" )  local pax = pan.P_PB2
			pax:SetPos( 346, 6 ) pax:SetSize( 48, 48 )
			pax:SetPlayer( pan.E_PB, 64 )
		end
		if true then --VS动画VS
			pan.P_VS = vgui.Create( "DPanel" )  local pax = pan.P_VS
			pax:SetPos( ScrW()/2 -48, ScrH()/2 -48 +64 )  pax:SetSize( 96, 96 )
			pax:MoveTo( ScrW()/2 -48, ScrH()/2 -48, 0.5 )
			pax:SetAlpha( 1 ) pax:AlphaTo( 255, 0.5 ) pax:AlphaTo( 0, 1, 2 )
			function pax:Paint( w, h )
				draw.TextShadow( {
					text = "VS",
					pos = { w/2, h/2 },
					font = "xdeshe_Font9",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
			end
		end
		function pan:AnimStage( txt, tx2 ) --场景标题动画
			if pan.P_IF then pan.P_IF:Remove() end
			pan.P_IF = vgui.Create( "DPanel" )  local pax = pan.P_IF
			pax:SetPos( 0, 0 )  pax:SetSize( ScrW(), ScrH() )
			pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
			pax:SetAlpha( 1 ) pax:AlphaTo( 255, 0.5 )
			pax.N_Anim1 = SysTime() +1
			pax.N_Anim2 = SysTime() +0.5
			pax.N_Anim3 = SysTime() +1.5
			pax.N_Anim4 = SysTime() +3
			pax.N_Anim5 = SysTime() +1
			local col = Color( 255, 255, 255 )
			if IsValid( pan.E_PA ) and pan.E_PA == LocalPlayer() then col = Color( 255, 0, 0 ) end
			if IsValid( pan.E_PB ) and pan.E_PB == LocalPlayer() then col = Color( 0, 255, 255 ) end
			function pax:Paint( w, h )
				surface.SetFont( "xdeshe_Font9" ) local ww, hh = surface.GetTextSize( txt )
				ww, hh = math.ceil( ww ), math.ceil( hh )
				local an1 = 1 -math.Clamp( pax.N_Anim1 -SysTime(), 0, 1 )
				local an2 = 1 -math.Clamp( ( pax.N_Anim2 -SysTime() )/0.5, 0, 1 )
				local an3 = 1 -math.Clamp( ( pax.N_Anim3 -SysTime() )/1.5, 0, 1 )
				local an4 = math.Clamp( ( pax.N_Anim4 -SysTime() )/2, 0, 1 )
				local an5 = math.Clamp( ( pax.N_Anim5 -SysTime() +3 ), 0, 1 )
				render.SetScissorRect( w/2 -ww, h*0.25 -hh, w/2 -ww +ww*2*an2, h*0.25, true )
				draw.TextShadow( {
					text = txt,
					pos = { w/2, h*0.25 },
					font = "xdeshe_Font9",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255, an5*255 )
				}, 1, an5*255 )
				render.SetScissorRect( w/2 +ww, h*0.25, w/2 +ww -ww*2*an2, h*0.25 +hh, true )
				draw.TextShadow( {
					text = txt,
					pos = { w/2, h*0.25 },
					font = "xdeshe_Font9",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255, an5*255 )
				}, 1, an5*255 )
				render.SetScissorRect( w/2 -ww +ww*2*an2, h*0.25 -hh, w/2 -ww +ww*2*an1, h*0.25, true )
				draw.TextShadow( {
					text = txt,
					pos = { w/2, h*0.25 },
					font = "xdeshe_Font9",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 192, 0, 0, an5*255 )
				}, 1, an5*255 )
				render.SetScissorRect( w/2 +ww -ww*2*an2, h*0.25, w/2 +ww -ww*2*an1, h*0.25 +hh, true )
				draw.TextShadow( {
					text = txt,
					pos = { w/2, h*0.25 },
					font = "xdeshe_Font9",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 0, 192, 192, an5*255 )
				}, 1, an5*255 )
				render.SetScissorRect( w/2 -( 1-an4 )*w/2, 0, w/2 +( 1-an4 )*w/2, h, true )
				draw.TextShadow( {
					text = tx2,
					pos = { w/2, h*0.34 -32 +32*an3 },
					font = "xdeshe_Font3",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255*an1, 255*an1, 255*an1, 255*an1*an5 )
				}, 1, 255*an1*an5 )
				render.SetScissorRect( w/2 -( 1-an4 )*w/2, 0, w/2 +( 1-an4 )*w/2, h, true )
				draw.RoundedBox( 0, w/2 -ww +2, h*0.3 +2, ww*2, 8, Color( 0, 0, 0, 255*an5 ) )
				draw.RoundedBox( 0, w/2 -ww, h*0.3, ww*2, 8, Color( col.r*0.6, col.g*0.6, col.b*0.6, 255*an5 ) )
				surface.SetMaterial( Ma3 ) surface.SetDrawColor( col.r, col.g, col.b, 255*an5 )
				surface.DrawTexturedRect( w/2 -ww, h*0.3, ww*2, 8 )
				render.SetScissorRect( 0, 0, 0, 0, false )
			end
			function pax:Think()
				if pax.N_Anim5 <= SysTime() -4 then pax:Remove() end
			end
		end
		function pan:AnimCount( txt, col ) --开局计时动画
			if !IsValid( pan.P_CD ) then
				pan.P_CD = vgui.Create( "DPanel" )  local pax = pan.P_CD
				pax:SetPos( ScrW()/2 -144, ScrH()/2 -144 )  pax:SetSize( 288, 288 )
				pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
				function pax:Paint( w, h )
					local an1 = 1 -math.Clamp( ( pax.N_Anim1 -SysTime() )/0.5, 0, 1 )
					local an2 = 1 -math.Clamp( ( pax.N_Anim2 -SysTime() )/0.5, 0, 1 )
					draw.TextShadow( {
						text = pax.S_Str1,
						pos = { w/2, h/2 -64 +64*an1 },
						font = "xdeshe_Font7",
						xalign = TEXT_ALIGN_CENTER,
						yalign = TEXT_ALIGN_CENTER,
						color = pax.C_Col1
					}, 1, 255 )
					draw.TextShadow( {
						text = pax.S_Str2,
						pos = { w/2, h/2 +64*an2 },
						font = "xdeshe_Font7",
						xalign = TEXT_ALIGN_CENTER,
						yalign = TEXT_ALIGN_CENTER,
						color = Color( pax.C_Col2.r, pax.C_Col2.g, pax.C_Col2.b, ( 1-an2 )*255 )
					}, 1, ( 1-an2 )*255 )
				end
				function pax:Think()
					if pax.N_Anim1 > 0 and pax.N_Anim1 <= SysTime() then
						pax.N_Anim1 = 0
						pax.N_Anim2 = SysTime() +0.5
						pax.S_Str2 = pax.S_Str1
						pax.S_Str1 = ""
						pax.C_Col2 = pax.C_Col1
					end
				end
			end
			local pax = pan.P_CD
			pax.N_Anim2 = SysTime() +0.5
			pax.S_Str2 = pax.S_Str1 or ""
			pax.C_Col2 = pax.C_Col1 or Color( 255, 255, 255 )
			pax.N_Anim1 = SysTime() +0.5
			pax.S_Str1 = txt
			pax.C_Col1 = col
		end
		function pan:AnimPlus( ab ) --加分动画
			if ab != 0 then
				if pan.P_IF then pan.P_IF:Remove() end
				pan.P_IF = vgui.Create( "DPanel" )  local pax = pan.P_IF
				pax:SetPos( ScrW()/2 -48 -( ab == 1 and 256 or -256 ), 96 +48 )  pax:SetSize( 96, 64 )
				pax:MoveTo( ScrW()/2 -48 -( ab == 1 and 256 or -256 ), 96, 1.5 )
				pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
				pax:SetAlpha( 255 ) pax:AlphaTo( 0, 1.5 )
				function pax:Paint( w, h )
					draw.TextShadow( {
						text = "+1",
						pos = { w/2, h/2 },
						font = "xdeshe_Font10",
						xalign = TEXT_ALIGN_CENTER,
						yalign = TEXT_ALIGN_CENTER,
						color = ab == 1 and Color( 255, 0, 0 ) or Color( 0, 255, 255 )
					}, 1, 255 )
				end
				timer.Simple( 1.6, function() if IsValid( pax ) then pax:Remove() end end )
			end
			if pan.P_SC then pan.P_SC:Remove() end
			pan.P_SC = vgui.Create( "DPanel" )  local pax = pan.P_SC
			pax:SetPos( ScrW()/2 -512, ScrH()*0.34 -128 )  pax:SetSize( 1024, 256 )
			pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
			pax:SetAlpha( 255 ) pax:AlphaTo( 0, 0.5, 2.5 ) pax:MoveTo( ScrW()/2 -512, ScrH()*0.34, 1, 2.5 )
			pax.N_Anim = SysTime() +1
			pax.N_Spin = 0
			pax.S_Text = "Draw"
			pax.C_Col = Color( 255, 255, 255 )
			if ab == 1 and IsValid( pan ) and IsValid( pan.E_PA ) then
				pax.S_Text = pan.E_PA:Nick().." "..language.GetPhrase( "xdeshe.VM_Score" )
				pax.C_Col = Color( 255, 0, 0 )
			elseif ab == 2 and IsValid( pan ) and IsValid( pan.E_PB ) then
				pax.S_Text = pan.E_PB:Nick().." "..language.GetPhrase( "xdeshe.VM_Score" )
				pax.C_Col = Color( 0, 255, 255 )
			end
			function pax:Paint( w, h )
				local ani = math.Clamp( pax.N_Anim -SysTime(), 0, 1 )
				pax.N_Spin = ( pax.N_Spin +ani/10 )%360
				draw.TextShadow( {
					text = pax.S_Text,
					pos = { w/2 +64*math.sin( pax.N_Spin )*ani, h/2 },
					font = "xdeshe_Font10",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = pax.C_Col
				}, 1, 255 )
			end
			timer.Simple( 3.5, function() if IsValid( pax ) then pax:Remove() end end )
		end
		function pan:ReceiveNotify( tab ) --接信息开动画
			local nam = tab[ 1 ]
			if nam == "stage" then
				pan:AnimStage( tab[ 2 ], tab[ 3 ] )
				pan.N_Round = pan.N_Round +1
			elseif nam == "count" then
				pan:AnimCount( tab[ 2 ], Color( tab[ 3 ], tab[ 4 ], tab[ 5 ] ) )
				if tab[ 2 ] == "3" then surface.PlaySound( "npc/overwatch/radiovoice/three.wav" )
				elseif tab[ 2 ] == "2" then surface.PlaySound( "npc/overwatch/radiovoice/two.wav" )
				elseif tab[ 2 ] == "1" then surface.PlaySound( "npc/overwatch/radiovoice/one.wav" )
				elseif tab[ 2 ] == "Go!" then surface.PlaySound( "ambient/alarms/klaxon1.wav" ) end
			elseif nam == "timer" then
				pan.S_Timer = tab[ 2 ]
				pan.N_NTimer = CurTime() +tab[ 3 ]
				pan.N_MTimer = tab[ 3 ]
				if pan.S_Timer != "" then surface.PlaySound( "ui/beepclear.wav" ) end
			elseif nam == "score" then
				pan:AnimPlus( tab[ 2 ] )
				if tab[ 2 ] == 1 then
					pan.N_WinA = pan.N_WinA +1
				elseif tab[ 2 ] == 2 then
					pan.N_WinB = pan.N_WinB +1
				end
				if IsValid( pan.E_PA ) and IsValid( pan.E_PB ) then
					if tab[ 2 ] == 0 then
						surface.PlaySound( "vo/k_lab2/ba_getgoing.wav" )
					elseif ( tab[ 2 ] == 1 and pan.E_PA == LocalPlayer() ) or ( tab[ 2 ] == 2 and pan.E_PB == LocalPlayer() ) then
						surface.PlaySound( "ambient/levels/canals/windchime2.wav" )
					else
						surface.PlaySound( "physics/metal/metal_grate_impact_hard1.wav" )
					end
				end
			end
		end
		return pan
	end )
	xdeshe_MenuRegister( "vsmg_result", function( id, ent, dat )
		if !IsValid( ent ) or !IsValid( ent:GetXDE_PA() ) or !IsValid( ent:GetXDE_PB() ) then return end
		if IsValid( xdeshe_vguis[ "vsmg" ] ) then xdeshe_vguis[ "vsmg" ]:Remove() end
		local pan = vgui.Create( "DFrame" )  local ply = LocalPlayer()
		pan:SetTitle( "" )
		pan:SetDraggable( false )
		pan:ShowCloseButton( false )
		pan:SetSize( ScrW(), ScrH() )
		pan:SetAlpha( 1 ) pan:AlphaTo( 255, 1 )
		pan:MakePopup()
		pan:Center()
		pan:SetDeleteOnClose( true )
		pan.E_Entity = ent
		pan.N_WinA = dat[ 1 ]  pan.N_WinB = dat[ 2 ]
		pan.N_Result = dat[ 3 ]
		pan.E_PA, pan.E_PB = ( dat[ 3 ] <= 1 and ent:GetXDE_PA() or ent:GetXDE_PB() ), ( dat[ 3 ] <= 1 and ent:GetXDE_PB() or ent:GetXDE_PA() )
		pan.S_PA, pan.S_PB = pan.E_PA:Nick(), pan.E_PB:Nick()
		pan.C_CA, pan.C_CB, pan.C_CC = Color( 255, 255, 255 ), Color( 255, 255, 255 ), Color( 255, 255, 255 )
		pan.S_T1, pan.S_T2 = language.GetPhrase( "xdeshe.Draw" ), language.GetPhrase( "xdeshe.VM_Fin1" )
		if dat[ 3 ] == 1 then
			pan.C_CA = Color( 255, 0, 0 )  pan.C_CB = Color( 0, 255, 255 )
		elseif dat[ 3 ] == 2 then
			pan.C_CA = Color( 0, 255, 255 )  pan.C_CB = Color( 255, 0, 0 )
			pan.N_WinA = dat[ 2 ]  pan.N_WinB = dat[ 1 ]
		end
		if dat[ 3 ] != 0 then
			if ply == ent:GetXDE_PA() then pan.C_CC = Color( 255, 0, 0 )
			elseif ply == ent:GetXDE_PB() then pan.C_CC = Color( 0, 255, 255 ) end
			if ply == pan.E_PA then
				pan.S_T1, pan.S_T2 = language.GetPhrase( "xdeshe.Victory" ), language.GetPhrase( "xdeshe.VM_Fin2" )..pan.E_PB:Nick()
			else
				pan.S_T1, pan.S_T2 = language.GetPhrase( "xdeshe.Defeat" ), language.GetPhrase( "xdeshe.VM_Fin3" )..pan.E_PA:Nick()
			end
		end
		pan.N_Anim1 = SysTime() +3
		pan.N_Anim2 = SysTime() +3.5
		pan.B_Close = false
		pan.N_Blur = SysTime()
		function pan:Paint( w, h )
			Derma_DrawBackgroundBlur( pan, Blur )
			local an1 = math.Clamp( ( pan.N_Anim1 -SysTime() )*2, 0, 1 )
			local an2 = math.Clamp( ( pan.N_Anim2 -SysTime() )*2, 0, 1 )
			draw.TextShadow( {
				text = pan.S_T1,
				pos = { w/2, h/2 -36 -( 1-an1 )*256 },
				font = "xdeshe_Font9",
				color = pan.C_CC,
				xalign = TEXT_ALIGN_CENTER,
				yalign = TEXT_ALIGN_CENTER
			}, 1, 255 )
			draw.TextShadow( {
				text = pan.S_T2,
				pos = { w/2, h/2 +24 -( 1-an1 )*256 },
				font = "xdeshe_Font3",
				color = Color( 255, 255, 255 ),
				xalign = TEXT_ALIGN_CENTER,
				yalign = TEXT_ALIGN_CENTER
			}, 1, 255 )
			draw.RoundedBox( 0, w/2 -300*( 1-an2 ) +1, h/2 -192 +1, 600*( 1-an2 ), 5, Color( 0, 0, 0, ( 1-an2 )*255 ) )
			draw.RoundedBox( 0, w/2 -300*( 1-an2 ), h/2 -192, 600*( 1-an2 ), 5, Color( 255, 255, 255, ( 1-an2 )*255 ) )
			if pan.N_Result == 0 then
				draw.TextShadow( {
					text = language.GetPhrase( "xdeshe.VM_Loser" )..":",
					pos = { w/2 -250, h/2 -150 },
					font = "xdeshe_Font3",
					color = Color( 255, 255, 255, 255*( 1-an2 ) ),
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER
				}, 1, 255*( 1-an2 ) )
			else
				draw.TextShadow( {
					text = language.GetPhrase( "xdeshe.BR36" )..":",
					pos = { w/2 -250, h/2 -150 },
					font = "xdeshe_Font3",
					color = Color( 255, 255, 255, 255*( 1-an2 ) ),
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER
				}, 1, 255*( 1-an2 ) )
			end
			draw.TextShadow( {
				text = language.GetPhrase( "xdeshe.VM_Loser" )..":",
				pos = { w/2 -250, h/2 -5 },
				font = "xdeshe_Font3",
				color = Color( 255, 255, 255, 255*( 1-an2 ) ),
				xalign = TEXT_ALIGN_LEFT,
				yalign = TEXT_ALIGN_CENTER
			}, 1, 255*( 1-an2 ) )
			draw.RoundedBox( 0, w/2 -300*( 1-an2 ) +1, h/2 +152 +1, 600*( 1-an2 ), 5, Color( 0, 0, 0, ( 1-an2 )*255 ) )
			draw.RoundedBox( 0, w/2 -300*( 1-an2 ), h/2 +152, 600*( 1-an2 ), 5, Color( 255, 255, 255, ( 1-an2 )*255 ) )
		end
		local Mat, Ma2, Ma3 = Material( "vgui/gradient-l" ), Material( "vgui/gradient-r" ), Material( "vgui/gradient_up" )
		if true then --结束动画A
			pan.P_SA = pan:Add( "DPanel" )  local pax = pan.P_SA
			pax:SetPos( ScrW()/2 -250 +250, ScrH()/2 -120 )  pax:SetSize( 500, 76 )
			pax:MoveTo( ScrW()/2 -250, ScrH()/2 -120, 0.5, 3 )
			pax:SetAlpha( 0 ) pax:AlphaTo( 255, 0.5, 3 )
			function pax:Paint( w, h )
				draw.NoTexture()
				surface.SetDrawColor( pan.C_CA.r*0.5, pan.C_CA.g*0.5, pan.C_CA.b*0.5 ) xdeshe_CutBox( h/5, 0, 0, w, h, false, false, false, true )
				surface.SetDrawColor( pan.C_CA.r*0.75, pan.C_CA.g*0.75, pan.C_CA.b*0.75 ) xdeshe_CutBox( ( h-2 )/5, 2, 2, w -4, h -4, false, false, false, true )
				surface.SetMaterial( Ma2 ) surface.SetDrawColor( pan.C_CA.r*0.5, pan.C_CA.g*0.5, pan.C_CA.b*0.5 )
				surface.DrawTexturedRect( 2, 2, w -4, h -4 )
				draw.TextShadow( {
					text = pan.S_PA,
					pos = { 406, h/2 -16 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_RIGHT,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
				draw.TextShadow( {
					text = language.GetPhrase( "xdeshe.VM_TWin" )..": "..pan.N_WinA,
					pos = { 410, h/2 +16 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_RIGHT,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
			end
			pan.P_PA2 = pan.P_SA:Add( "AvatarImage" )  local pax = pan.P_PA2
			pax:SetPos( 430, 6 ) pax:SetSize( 64, 64 )
			pax:SetPlayer( pan.E_PA, 64 )
		end
		if true then --结束动画B
			pan.P_SB = pan:Add( "DPanel" )  local pax = pan.P_SB
			pax:SetPos( ScrW()/2 -250 -250, ScrH()/2 +25 )  pax:SetSize( 500, 76 )
			pax:MoveTo( ScrW()/2 -250, ScrH()/2 +25, 0.5, 3 )
			pax:SetAlpha( 0 ) pax:AlphaTo( 255, 0.5, 3 )
			function pax:Paint( w, h )
				draw.NoTexture()
				surface.SetDrawColor( pan.C_CB.r*0.5, pan.C_CB.g*0.5, pan.C_CB.b*0.5 ) xdeshe_CutBox( h/5, 0, 0, w, h, false, false, true, false )
				surface.SetDrawColor( pan.C_CB.r*0.75, pan.C_CB.g*0.75, pan.C_CB.b*0.75 ) xdeshe_CutBox( ( h-2 )/5, 2, 2, w -4, h -4, false, false, true, false )
				surface.SetMaterial( Mat ) surface.SetDrawColor( pan.C_CB.r*0.5, pan.C_CB.g*0.5, pan.C_CB.b*0.5 )
				surface.DrawTexturedRect( 2, 2, w -4, h -4 )
				draw.TextShadow( {
					text = pan.S_PB,
					pos = { 90, h/2 -16 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
				draw.TextShadow( {
					text = language.GetPhrase( "xdeshe.VM_TWin" )..": "..pan.N_WinB,
					pos = { 90, h/2 +16 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_LEFT,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
			end
			pan.P_PB2 = pan.P_SB:Add( "AvatarImage" )  local pax = pan.P_PB2
			pax:SetPos( 6, 6 ) pax:SetSize( 64, 64 )
			pax:SetPlayer( pan.E_PB, 64 )
		end
		if true then --关闭按钮
			pan.P_CL = pan:Add( "DButton" )  local pax = pan.P_CL
			pax:SetPos( ScrW()/2 -100, ScrH()/2 +150 )  pax:SetSize( 200, 60 )
			pax:MoveTo( ScrW()/2 -100, ScrH()/2 +200, 0.5, 3.5 )
			pax:SetAlpha( 0 ) pax:AlphaTo( 255, 0.5, 3.5 ) pax:SetText( "" )
			pax.B_Hover = false  pax.N_Lerp = SysTime() +0.5
			function pax:Paint( w, h )
				local ler = math.Clamp( ( pax.N_Lerp -SysTime() )/0.5, 0, 1 )
				if !pax.B_Hover and !pan.B_Close then ler = 1-ler end
				draw.TextShadow( {
					text = language.GetPhrase( "xdeshe.Confirm" ),
					pos = { w/2, h/2 },
					font = "xdeshe_Font3",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255*ler )
				}, 1, 255 )
				surface.SetDrawColor( 255, 255, 255*ler )  surface.DrawOutlinedRect( 0, 0, w, h, 4 )
				surface.SetDrawColor( 0, 0, 0 )  surface.DrawOutlinedRect( 0, 0, w, h )
			end
			function pax:OnCursorEntered()  pax.B_Hover = true  pax.N_Lerp = SysTime() +0.5 end
			function pax:OnCursorExited()  pax.B_Hover = false  pax.N_Lerp = SysTime() +0.5 end
			function pax:DoClick()
				if pan.B_Close or !pax.B_Hover then return end pan.B_Close = true
				pan:SetKeyboardInputEnabled( false ) pan:SetMouseInputEnabled( false )
				pan:AlphaTo( 0, 0.5 )  timer.Simple( 0.5, function() if IsValid( pan ) then pan:Close() end end )
			end
		end
		return pan
	end )
    xdeshe_MenuRegister( "vsmg_withdraw", function( id, ent, dat )
        if IsValid( xdeshe_vguis[ id ] ) then xdeshe_vguis[ id ]:Remove() end local ply = LocalPlayer()
		local ent = nil
		for k, v in pairs( ents.FindByClass( "sent_she_vsmg" ) ) do
			if IsValid( v ) then ent = v  vsmg.entity = v  break end
		end if !IsValid( ent ) or ent:GetXDE_State() != 2 then return nil end
		local pan = vgui.Create( "DFrame" )
        pan:SetSize( 800, 600 )
        pan:SetTitle( "" )
        pan:ShowCloseButton( false )
        pan:SetScreenLock( true )
        pan:SetDeleteOnClose( true )
        pan:Center()
        pan:MakePopup()
        pan:SetAlpha( 1 )
        pan:AlphaTo( 255, 0.5 )
        pan.B_Close = false
        pan.N_Blur = SysTime()
        function pan:MenuClose() pan:Remove() end
        function pan:Think()
			if !IsValid( ent ) or ent:GetXDE_State() != 2 then self:Remove() end
        end
        function pan:Paint( w, h )
            Derma_DrawBackgroundBlur( pan, pan.N_Blur )
			if !IsValid( ent ) or ent:GetXDE_State() != 2 then return end
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.VM_Quit1" ),
                pos = { w/2, h*0.25 },
                font = "xdeshe_Font9",
                xalign = TEXT_ALIGN_CENTER,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.VM_Quit2" ),
                pos = { w/2, h*0.35 },
                font = "xdeshe_Font3",
                xalign = TEXT_ALIGN_CENTER,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
        end
        for i=1, 2 do --确定按钮
            pan.B_Quit = pan:Add( "DButton" )  local but = pan.B_Quit
            but:SetPos( 300 +( i == 1 and -200 or 200 ), 400 )
            but:SetSize( 200, 50 )
            but:SetIcon( i == 1 and "icon16/tick.png" or "icon16/cross.png" )
            but:SetText( "" )
            but.B_Hover = false
            but.N_Click = 0
            function but:Paint( w, h )
                local alp = math.Clamp( ( but.N_Click-SysTime() )/0.3, 0, 1 )
                if but.B_Hover then alp = 1-alp end
                surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 0, 0, w, h, 4 +alp*4 )
                surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 0, 0, w, h, 1 +alp*4 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Quit"..( i == 1 and "4" or "5" ) ),
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = i == 1 and Color( 255, 255 -alp*255, 255 -alp*255 ) or Color( 255 -alp*255, 255, 255 -alp*255 )
                }, 1, 255 )
            end
            function but:OnCursorEntered() but.B_Hover = true  but.N_Click = SysTime() +0.3 end
            function but:OnCursorExited() but.B_Hover = false  but.N_Click = SysTime() +0.3 end
            function but:DoClick()
                if pan.B_Close then return end pan.B_Close = true
                if i == 1 then
                    net.Start( "NET_VSMG_Withdraw" ) net.SendToServer()
                    surface.PlaySound( "doors/default_locked.wav" )
                else
                    surface.PlaySound( "ui/buttonclick.wav" )
                end
                pan:MenuClose()
            end
        end
        return pan
    end )
end

hook.Add( "SpawnMenuOpen", "vsmg_nocheat", function() if LocalPlayer():GetNWBool( "VSMG" ) then return false end end )
hook.Add( "CanPlayerSuicide", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerNoClip", "vsmg_nocheat", function( ply, bol ) if ply:GetNWBool( "VSMG" ) and bol then return false end end )
hook.Add( "PlayerSpawnEffect", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnNPC", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnObject", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnProp", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnRagdoll", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnSENT", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnSWEP", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerGiveSWEP", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "PlayerSpawnVehicle", "vsmg_nocheat", function( ply ) if ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "CanPlayerUnfreeze", "vsmg_nocheat", function( ply, ent, phy ) if ply:GetNWBool( "VSMG" ) or ent.VSMG_Immune then return false end end )
hook.Add( "PhysgunPickup", "vsmg_pp", function( ply, ent ) if ent.vsmg_NoTool then return false end end )
hook.Add( "CanProperty", "vsmg_cp", function( ply, property, ent ) if ent.vsmg_NoTool then return false end end )
hook.Add( "CanTool", "vsmg_ct", function( ply, tr, toolname, tool, button ) if IsValid( tr.Entity ) and tr.Entity.vsmg_NoTool then return false end end )
hook.Add( "AllowPlayerPickup", "vsmg_app", function( ply, ent ) if ent.vsmg_NoTool and !ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "GravGunPickupAllowed", "vsmg_gpa", function( ply, ent ) if ent.vsmg_NoTool and !ply:GetNWBool( "VSMG" ) then return false end end )
hook.Add( "GravGunPunt", "vsmg_ggp", function( ply, ent ) if ent.vsmg_NoTool and !ply:GetNWBool( "VSMG" ) then return false end end )

concommand.Add( "vsmg_teststage", function( ply, cmd, var )
	if !IsValid( ply ) or !ply:IsSuperAdmin() then return end
	if !istable( var ) or #var != 1 or !istable( vsmg.stages[ var[ 1 ] ] ) then return end
	if IsValid( vsmg.core ) then vsmg.core:Remove() end
	vsmg.core = ents.Create( "base_anim" )
	vsmg.core:SetModel( "models/hunter/blocks/cube025x025x025.mdl" )
	vsmg.core:SetPos( IsValid( vsmg.entity ) and vsmg.entity:GetXDE_SavePos() or Vector( 0, 0, 0 ) )
	vsmg.core:Spawn()
	vsmg.core:SetCollisionBounds( Vector( -2500, -2500, -2500 ), Vector( 2500, 2500, 2500 ) )
	undo.Create( "Test Stage" )
	undo.AddEntity( vsmg.core )
	undo.SetPlayer( ply )
	undo.Finish()
	vsmg.CreateStage( var[ 1 ] )
	vsmg.core:Func_Init()
end )
concommand.Add( "vsmg_forcestage", function( ply, cmd, var )
	if !IsValid( ply ) or !ply:IsSuperAdmin() then return end
	if !istable( var ) or #var != 1 or !istable( vsmg.stages[ var[ 1 ] ] ) then vsmg.fstage = nil return end
	vsmg.fstage = var[ 1 ]
end )
concommand.Add( "vsmg_reloadstage", function( ply, cmd, var )
	if ( IsValid( ply ) and !ply:IsSuperAdmin() ) then return end
	vsmg.LoadFiles()
end )