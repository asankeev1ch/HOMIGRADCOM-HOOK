-- "lua\\autorun\\artemius_scp106_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "SCP 106 Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/scp/106/scp106.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "SCP 106 Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "SCP 106 Angry", 
				Class = "npc_combine",
				Model = "models/artemius/scp/106/scp106.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "SCP 106 Angry", NPC )

local Category = "SCP:CB NPC's"