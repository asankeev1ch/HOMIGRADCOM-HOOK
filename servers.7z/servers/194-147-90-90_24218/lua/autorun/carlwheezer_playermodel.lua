-- "lua\\autorun\\carlwheezer_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "CarlWheezer",
"models/carlwheezer/Playermodels/carlwheezer.mdl" )

list.Set( "PlayerOptionsModel",  "CarlWheezer", 				
"models/carlwheezer/Playermodels/carlwheezer.mdl" )