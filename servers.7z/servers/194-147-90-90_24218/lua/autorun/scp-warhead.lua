-- "lua\\autorun\\scp-warhead.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENUM_SCPWARHEAD_DISABLED 		= 0
ENUM_SCPWARHEAD_ENABLED 		= 1
ENUM_SCPWARHEAD_COUNTING		= 2
ENUM_SCPWARHEAD_CANCEL			= 3
ENUM_SCPWARHEAD_DETONATED 		= 4
ENUM_SCPWARHEAD_RESET 			= 32

SCPWarhead = {
	firstActivation = true,
	resumePoint = nil,
	resumePoints = {30, 40, 50, 60, 70, 80, 90, 100}
}

function SCPWarhead:GetWarheadState()
	return GetGlobalInt("SCP-WARHEAD-STATUS", ENUM_SCPWARHEAD_DISABLED)
end

function SCPWarhead:GetInevitable()
	return ((timer.TimeLeft("SCPWARHEAD-COUNTDOWN") || 0) < 10) && self:GetWarheadState() == ENUM_SCPWARHEAD_COUNTING//GetGlobalBool("SCP-WARHEAD-INEVITABLE", false)
end

function SCPWarhead:GetRestarting()
	return GetGlobalBool("SCP-WARHEAD-RESTARTING", false)
end

function SCPWarhead:GetResumePoint( lastTime )
	if not isnumber(lastTime) then lastTime = timer.TimeLeft("SCPWARHEAD-COUNTDOWN") || 120 end
	for k, v in pairs(self.resumePoints) do
		if lastTime < v then return v end
	end
end