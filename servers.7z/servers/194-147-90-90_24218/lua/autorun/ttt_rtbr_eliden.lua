-- "lua\\autorun\\ttt_rtbr_eliden.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
game.AddParticles("particles/rtbr_d2_eliden.pcf")
game.AddParticles("particles/steampuff.pcf")