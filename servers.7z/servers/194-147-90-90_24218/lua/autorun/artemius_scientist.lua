-- "lua\\autorun\\artemius_scientist.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP Scientist", "models/artemius/human/scientist/scientist.mdl" );