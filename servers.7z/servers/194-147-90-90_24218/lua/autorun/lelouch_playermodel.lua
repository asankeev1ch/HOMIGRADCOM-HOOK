-- "lua\\autorun\\lelouch_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Lelouch vi Britannia", "models/sazuma/lelouch.mdl" )
list.Set( "PlayerOptionsModel", "Lelouch vi Britannia", "models/sazuma/lelouch.mdl" )
player_manager.AddValidHands( "Lelouch vi Britannia", "models/sazuma/lelouch_arms.mdl", 0, "0000000" )