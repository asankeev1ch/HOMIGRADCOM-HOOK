-- "gamemodes\\base\\entities\\entities\\base_entity\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

ENT.Base = "base_entity"
ENT.Type = "anim"

ENT.Spawnable = false
ENT.AdminOnly = false
