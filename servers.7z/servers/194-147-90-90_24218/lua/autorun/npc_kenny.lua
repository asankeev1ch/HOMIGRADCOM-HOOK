-- "lua\\autorun\\npc_kenny.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local Category = "South Park NPCs"

local NPC = { 	Name = "Kenny Mccormick", 
				Class = "npc_Citizen",
				Model = "models/kenny/kenny.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
				Category = Category	}


list.Set( "NPC", "npc_kenny", NPC )