-- "lua\\autorun\\nagievpm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Nagiev", "models/player/kuhnya/nagiev.mdl" )
list.Set( "PlayerOptionsModel", "Nagiev", "models/player/kuhnya/nagiev.mdl" )
player_manager.AddValidHands( "Nagiev", "models/weapons/c_arms_citizen.mdl", 0, "00000000" )
