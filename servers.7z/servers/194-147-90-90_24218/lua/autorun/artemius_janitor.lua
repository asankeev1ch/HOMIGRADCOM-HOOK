-- "lua\\autorun\\artemius_janitor.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP Janitor", "models/artemius/human/janitor/janitor.mdl" );