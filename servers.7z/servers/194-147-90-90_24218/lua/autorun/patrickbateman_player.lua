-- "lua\\autorun\\patrickbateman_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "PatrickBateman", 					"models/patrickbateman/Playermodels/patrickbateman.mdl" )

list.Set( "PlayerOptionsModel",  "PatrickBateman", 					"models/patrickbateman/Playermodels/patrickbateman.mdl" )