-- "lua\\autorun\\cosmosman.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "galaxyman_blue", "models/player/galaxyman/galaxyman_blue.mdl" )
player_manager.AddValidHands( "galaxyman_blue", "models/player/galaxyman/galaxyman_hands_blue.mdl", 0, "00000000", true )
list.Set( "PlayerOptionsModel", "Cosmos Man", "models/player/galaxyman/galaxyman_blue.mdl" )
