-- "gamemodes\\sandbox\\gamemode\\spawnmenu\\creationmenu\\manifest.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

include( "content/content.lua" )
