-- "lua\\autorun\\artemius_zombie_dclass_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Zombie D - Class Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/scp/zombie_dclass/zombie_dclass.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Zombie D - Class Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Zombie D - Class Angry", 
				Class = "npc_combine",
				Model = "models/artemius/scp/zombie_dclass/zombie_dclass.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Zombie D - Class Angry", NPC )

local Category = "SCP:CB NPC's"