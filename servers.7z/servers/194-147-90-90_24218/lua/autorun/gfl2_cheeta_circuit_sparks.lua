-- "lua\\autorun\\gfl2_cheeta_circuit_sparks.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Girls Frontline 2 Cheeta Circuit Sparks (MP7)", "models/player/gfl2_cheeta_circuit_sparks.mdl" )
player_manager.AddValidHands( "Girls Frontline 2 Cheeta Circuit Sparks (MP7)", "models/arms/gfl2_cheeta_circuit_sparks_arms.mdl", 0, "00000000" )

local Category = "Girls Frontline 2"

local NPC =
{
	Name = "Cheeta Circuit Sparks (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/gfl2_cheeta_circuit_sparks_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_cheeta_circuit_sparks_friendly", NPC )

local NPC =
{
	Name = "Cheeta Circuit Sparks (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/gfl2_cheeta_circuit_sparks_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_cheeta_circuit_sparks_enemy", NPC )
