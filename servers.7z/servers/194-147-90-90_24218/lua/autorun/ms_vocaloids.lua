-- "lua\\autorun\\ms_vocaloids.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Mesmerizer Kasane Teto", "models/gamespy/mesmerizer/MSKasaneTeto.mdl" )
player_manager.AddValidHands( "Mesmerizer Kasane Teto", "models/gamespy/mesmerizer/MSKasaneTeto_arms.mdl" )
player_manager.AddValidModel( "Mesmerizer Hatsune Miku", "models/gamespy/mesmerizer/MSMikuHatsune.mdl" )
player_manager.AddValidHands( "Mesmerizer Hatsune Miku", "models/gamespy/mesmerizer/MSMikuHatsune_arms.mdl" )