-- "lua\\autorun\\hl1mikuxin.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "HL1 Hatsune Miku", "models/xinus22/mikuhl1.mdl" )
player_manager.AddValidHands( "HL1 Hatsune Miku", "models/xinus22/mikuhl1_arms.mdl", 0, "00000000" )