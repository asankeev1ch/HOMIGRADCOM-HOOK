-- "lua\\autorun\\gm_bshkas.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if ((game.GetMap() != "gm_bshkas") and (game.GetMap() != "gm_bshkas_nofog") and (game.GetMap() != "gm_bshkas_night")) then return end

if SERVER then
	util.AddNetworkString("bshkasInitPlySpawn")
	util.AddNetworkString("bshkasPlayerSpawn")
	util.AddNetworkString("bshkasPlyEnterWater")
	util.AddNetworkString("bshkasPlyExitWater")
	util.AddNetworkString("openUrl")
end

if CLIENT then
	net.Receive("bshkasInitPlySpawn", function()
		if (!render.GetHDREnabled()) then
			timer.Simple(3, function()
				chat.AddText(Color( 170, 170, 255 ), "Please enable HDR, else this map looks like ass. After that's done, restart the map")
				surface.PlaySound("bshkas/world3.wav")
			end)
		end
		
		if (render.GetDXLevel() < 95) then
			timer.Simple(6, function()
				chat.AddText(Color( 170, 170, 255 ), "Unsupported DirectX level, expect errors (95 required, got ", tostring(render.GetDXLevel()), ", type mat_dxlevel 95 in console. After that, restart your game)")
				surface.PlaySound("bshkas/world3.wav")
			end)
		end
	end)
	
	net.Receive("bshkasPlayerSpawn", function()
		if ((game.GetMap() != "gm_bshkas_nofog") and (game.GetMap() != "gm_bshkas_night")) then
			hook.Add( "RenderScreenspaceEffects", "Bshkas Screen Fog", function()
				DrawMaterialOverlay( "bshkas/exc_screenoverlay01", 1 )
				DrawMaterialOverlay( "bshkas/exc_screenoverlay02", 1 )
				DrawMaterialOverlay( "bshkas/marine_snow2", .1 )
				DrawMaterialOverlay( "bshkas/marine_snow2", .1 )
			end )
		end
	end)
	
	net.Receive("bshkasPlyEnterWater", function()
		LocalPlayer():ScreenFade( SCREENFADE.IN, Color( 0, 0, 0, 255 ), 1, 0 )
		hook.Remove("RenderScreenspaceEffects", "Bshkas Screen Fog")
		
		hook.Add("RenderScreenspaceEffects", "Bshkas Water Effect", function()
			DrawMaterialOverlay( "effects/water_warp01", .1 )
			DrawMaterialOverlay( "bshkas/marine_snow", .1 )
			DrawMaterialOverlay( "bshkas/marine_snow_light", .1 )
			DrawMaterialOverlay( "bshkas/marine_snow2", .1 )
			DrawMotionBlur( 0.5, 0.5, 0.06 )
			DrawBokehDOF( 6, .7, .1 )
		end )
		
	end)
	
	net.Receive("bshkasPlyExitWater", function()
		hook.Remove("RenderScreenspaceEffects", "Bshkas Water Effect")
		
		if ((game.GetMap() != "gm_bshkas_nofog") and (game.GetMap() != "gm_bshkas_night")) then
			LocalPlayer():ScreenFade( SCREENFADE.IN, Color( 200, 200, 200, 255 ), 1, 0 )
			hook.Add( "RenderScreenspaceEffects", "Bshkas Screen Fog", function()
				DrawMaterialOverlay( "bshkas/exc_screenoverlay01", 1 )
				DrawMaterialOverlay( "bshkas/exc_screenoverlay02", 1 )
				DrawMaterialOverlay( "bshkas/marine_snow2", .1 )
				DrawMaterialOverlay( "bshkas/marine_snow2", .1 )
			end )
		end
	end)
	
	net.Receive("openUrl", function()
		local url = net.ReadString()
			
		if BRANCH != "x86-64" then 
			chat.AddText(Color(230,230,230),"Opening ",Color(230,100,230),url, Color(230,230,230)," on the Steam Overlay browser")
			gui.OpenURL("https://"..url) 
			return 
		end

		local frame = vgui.Create( "DFrame" )
		frame:SetTitle( "Web browser" )
		frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
		frame:Center()
		frame:MakePopup()

		local html = vgui.Create( "DHTML", frame )
		html:Dock( FILL )
		html:OpenURL( url )
		chat.AddText(Color(230,230,230),"Opening ",Color(230,100,230),url)
	end)
end

hook.Add( "PlayerSpawn", "BshkasPlayerSpawn", function(player, transition)
	net.Start("bshkasPlayerSpawn")
	net.Send(player)
end)

local load_queue = {}

hook.Add( "PlayerInitialSpawn", "Bshkas/Load", function( ply )
	load_queue[ ply ] = true
end )

hook.Add( "StartCommand", "Bshkas/Load", function( ply, cmd )
	if load_queue[ ply ] and not cmd:IsForced() then
		load_queue[ ply ] = nil

		net.Start("bshkasInitPlySpawn")
		net.Send(ply)
	end
end )

hook.Add( "EntityTakeDamage", "BlockDrowningDmg", function( target, dmginfo )
	if ( target:IsPlayer() and dmginfo:IsDamageType(DMG_DROWN)) then
		return true
	end
end )

--If you wanna play this in TTT for some reason
if (engine.ActiveGamemode() != "terrortown") then return end

hook.Add("TTTPrepareRound", "BshkasTTTPrepRound", function()
	timer.Simple(0.2, function()
		if SERVER then
			net.Start("bshkasPlyExitWater")
			net.Broadcast()
		end
	end)
end)