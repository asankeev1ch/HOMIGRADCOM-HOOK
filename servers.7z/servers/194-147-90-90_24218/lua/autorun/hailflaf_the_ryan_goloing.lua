-- "lua\\autorun\\hailflaf_the_ryan_goloing.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Ryan Gosling half life", 		"models/dejtriyev/hl1/ryangosling.mdl" )
list.Set( "PlayerOptionsModel",  "Ryan Gosling half life", 	"models/dejtriyev/hl1/ryangosling.mdl" )