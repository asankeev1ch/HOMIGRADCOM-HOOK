-- "lua\\autorun\\dexter_morgan_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Dexter Morgan", "models/Dexter_Morgan.mdl" )
player_manager.AddValidHands( "Dexter Morgan", "models/Dexter_Morgan_Arms.mdl", 0, "0" )

local Category = "Commissions"
local NPC = {    Name = "Dexter Morgan", 
                Class = "npc_citizen", 
                Model = "models/Dexter_Morgan.mdl",                 
Health = "250",                 KeyValues = { citizentype = 4 },                 
Category = Category }  list.Set( "NPC", "Dexter_Morgan_npc", NPC ) 