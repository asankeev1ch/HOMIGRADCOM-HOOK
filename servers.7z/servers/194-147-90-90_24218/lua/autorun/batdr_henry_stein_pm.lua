-- "lua\\autorun\\batdr_henry_stein_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
// Ported by Maygik

local modelName = "Henry Stein (BATDR)"
local modelPath = "batdr/henry_stein"

list.Set( "PlayerOptionsModel", modelName, 	"models/" .. modelPath .. ".mdl" )
player_manager.AddValidModel( 	modelName, 	"models/" .. modelPath .. ".mdl" )
player_manager.AddValidHands( 	modelName, 	"models/" .. modelPath .. "_arms.mdl", 0, "00000000" )