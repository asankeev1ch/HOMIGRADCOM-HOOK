-- "gamemodes\\sandbox\\gamemode\\spawnmenu\\controls\\manifest.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

include( "control_presets.lua" )
include( "ropematerial.lua" )

include( "ctrlnumpad.lua" )
include( "ctrlcolor.lua" )
include( "ctrllistbox.lua" )
