-- "lua\\autorun\\gfl2_vector_dorm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Girls Frontline 2 Vector Dorm (KRISS Vector)", "models/player/gfl2_vector_dorm.mdl" )
player_manager.AddValidHands( "Girls Frontline 2 Vector Dorm (KRISS Vector)", "models/arms/gfl2_vector_dorm_arms.mdl", 0, "00000000" )

local Category = "Girls Frontline 2"

local NPC =
{
	Name = "Vector Dorm (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/gfl2_vector_dorm_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_vector_dorm_friendly", NPC )

local NPC =
{
	Name = "Vector Dorm (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/gfl2_vector_dorm_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_vector_dorm_enemy", NPC )
