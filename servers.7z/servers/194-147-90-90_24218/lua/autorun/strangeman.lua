-- "lua\\autorun\\strangeman.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local Category = "StrangeMan"
local NPC = { 	Name = "Strangeman", 
				Class = "npc_citizen",
				Model = "models/zanik/strangemanf.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "strangeman_zanik", NPC )

local NPC = { 	Name = "Strangeman (Evil)", 
				Class = "npc_combine",
				Model = "models/zanik/strangemane.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "strangeman_zanik_evil", NPC )

player_manager.AddValidModel( "Strangeman", "models/player/strangeman.mdl" );
list.Set( "PlayerOptionsModel", "Strangeman", "models/player/strangeman.mdl" );

