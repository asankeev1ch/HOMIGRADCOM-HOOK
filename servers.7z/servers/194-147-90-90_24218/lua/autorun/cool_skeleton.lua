-- "lua\\autorun\\cool_skeleton.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "Cool_skeleton", "models/gruchk/oc/cool_skeleton.mdl" )
player_manager.AddValidModel( "Cool_skeleton", "models/gruchk/oc/cool_skeleton.mdl" )
player_manager.AddValidHands( "Cool_skeleton", "models/gruchk/oc/c_arms_skully.mdl", 0, "00000000" )