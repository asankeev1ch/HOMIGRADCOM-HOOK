-- "lua\\autorun\\artemius_scp049_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "SCP 049 Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/scp/049/scp049.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "SCP 049 Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "SCP 049 Angry", 
				Class = "npc_combine",
				Model = "models/artemius/scp/049/scp049.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "SCP 049 Angry", NPC )

local Category = "SCP:CB NPC's"