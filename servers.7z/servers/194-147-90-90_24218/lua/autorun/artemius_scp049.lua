-- "lua\\autorun\\artemius_scp049.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP 049", "models/artemius/scp/049/scp049.mdl" );
list.Set( "PlayerOptionsModel",  "SCP 049", 					"models/artemius/scp/049/scp049.mdl" )