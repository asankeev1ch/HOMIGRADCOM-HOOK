-- "lua\\autorun\\theboys_homelander_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
// Homelander - GUS
player_manager.AddValidModel( "Homelander", "models/theboys/homelander.mdl" )
player_manager.AddValidHands( "Homelander", "models/theboys/homelander_arms.mdl", 0, "00000000" )