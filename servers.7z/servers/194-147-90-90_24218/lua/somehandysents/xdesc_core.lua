-- "lua\\somehandysents\\xdesc_core.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
xdesc = {}  xdesc.dts = {
    { 6, 12, 18, 24, 30, -1 }, --波数总计
    { 0, 25, 10, 5, 2, 1 }, --补给几率
    { 1, 2, 3 }, --游戏模式
    { 0.25, 0.5, 1, 2 }, --敌人难度
    { 1, 2, 3, 4 }, --敌人行动
    { 0.5, 1, 2, 4, 8 }, --敌人数量
    { "#xdeshe.SC_Undead", "#xdeshe.SC_Resistance", "#xdeshe.SC_Enforcer", "#xdeshe.SC_Combine", "#xdeshe.SC_Random", "#xdeshe.SC_Mixed" }, --敌人种类
}

if SERVER then --纪念，防御战生成器大改以免遭弃稿
    util.AddNetworkString( "xdesc_Start" ) util.AddNetworkString( "xdesc_Ready" ) util.AddNetworkString( "xdesc_Hud" ) util.AddNetworkString( "xdesc_Leave" )
    util.AddNetworkString( "xdesc_Notify" ) util.AddNetworkString( "xdesc_Cam" ) util.AddNetworkString( "xdesc_ReadyCL" )
    xdesc.wps = {}  xdesc.ths = {}  xdesc.uns = {}  --武器，投掷，单位
    xdesc.vxs = {}  xdesc.mts = {}  xdesc.wvs = {}  --NPC声音,突变，波型
    xdesc.cns = { 6, 6, 3, 4, 4, 4, 6 }  xdesc.spawn = {}  xdesc.spawn2 = {} --每个选项限制最大值，重生位置，修正重生位置

    hook.Add( "PlayerDeath", "xdesc_PD", function( ply, inf, atk )
        if ply:GetNWBool( "XDESC" ) then
            local glo = GetGlobal2Entity( "XDESC" )
            if IsValid( glo ) and glo:GetXDE_State() == 3 then
                local spec = xdesc.GetSpec()
                if istable( spec ) and spec.OnDeath then
                    spec:OnDeath( 0, ply, atk, inf )
                end xdesc.LoadoutSave( ply )
                timer.Simple( 0, function() if !ply:Alive() then ply:SetMoveType( MOVETYPE_NONE ) end end )
                xdeshe_MenuOpen( ply, "xdesc3", nil, "_" )
                for k, v in pairs( glo.PlayerJoin ) do
                    if IsValid( v ) and !v:IsBot() then
                        net.Start( "xdesc_Notify" )
                        if glo:GetXDE_Player() <= 2 then
                            net.WriteString( util.TableToJSON( { "plydead" } ) )
                        else
                            net.WriteString( util.TableToJSON( { "plydead", ply:Nick() } ) )
                        end
                        net.Send( v )
                    end
                end
                if !ply:IsBot() then glo:RecordResult( 2, ply:SteamID() ) end
                glo.Result[ 3 ][ 1 ] = ply:Nick()
                glo:RecordResult( 4 ) glo:NextThink( CurTime() +0.1 )
            end
        end
    end )
    hook.Add( "PlayerDeathThink", "xdesc_PDT", function( ply )
        if ply:GetNWBool( "XDESC" ) and IsValid( GetGlobal2Entity( "XDESC" ) ) and GetGlobal2Entity( "XDESC" ):GetXDE_State() >= 3 then
            return false
        end
    end )
    hook.Add( "PlayerSpawn", "xdesc_PS", function( ply )
        if ply:GetNWBool( "XDESC" ) then
            ply:SetNWFloat( "XDESC_F", 0 )
            if isnumber( ply.xdesc_C ) then ply.xdesc_C = nil end
            if isnumber( ply.xdesc_M ) then ply.xdesc_M = nil end
            local spec = xdesc.GetSpec()
            if istable( spec ) and spec.OnSpawn then
                spec:OnSpawn( 0, ply )
            end
            timer.Simple( 0, function()
                if IsValid( ply ) and ply:Alive() then
                    ply:SetHealth( ply:GetMaxHealth() )
                    ply:SetArmor( ply:GetMaxArmor() )
                end
            end )
            xdesc.LoadoutLoad( ply )
        end
    end )
    hook.Add( "EntityTakeDamage", "xdesc_ETD", function( tar, dmg )
        local atk, glo = dmg:GetAttacker(), GetGlobal2Entity( "XDESC" )
        if IsValid( atk ) and ( tar:IsPlayer() and atk:IsPlayer() ) and ( tar:GetNWBool( "XDESC" ) or atk:GetNWBool( "XDESC" ) ) then
            dmg:ScaleDamage( 0 )
            return true
        end
        if IsValid( atk ) and ( atk:GetClass() == "xdesc_bot" or atk:GetClass() == "xdesc_throw" ) then
            if tar == atk or tar:GetClass() == "xdesc_bot" or ( tar:IsPlayer() and !tar:GetNWBool( "XDESC" ) and IsValid( glo ) and glo:GetXDE_State() >= 2 ) then
                dmg:ScaleDamage( 0 )
                return true
            end
            local spec = xdesc.GetSpec()
            if istable( spec ) and spec.OnHurt then
                spec:OnHurt( 0, tar, dmg )
            end
            local sc1 = ( ( IsValid( glo ) and glo:GetXDE_Wave() > 0 ) and math.max( 1, 1 +glo:GetXDE_Wave()/30 ) or 1 )
            if dmg:GetInflictor() and dmg:GetInflictor():GetClass() == "grenade_ar2" then dmg:ScaleDamage( 2 ) end
            local sc2 = ( xdesc.dts[ 4 ][ atk:GetDiffi() ] or 1 )
            dmg:SetDamageType( DMG_GENERIC ) dmg:ScaleDamage( sc1*sc2 )
            if tar:IsPlayer() and tar:Health() >= 40 and dmg:GetDamage() >= tar:Health() and ( !isnumber( tar.xdesc_C ) or tar.xdesc_C <= CurTime() ) then
                tar.xdesc_C = CurTime() +10
                tar:EmitSound( tar:LastHitGroup() == HITGROUP_HEAD and "XDESC.CritHead" or "XDESC.Crit" )
                tar:ScreenFade( SCREENFADE.IN, Color( 155, 0, 0, 128 ), 2, 0 )
                tar:SetLocalVelocity( Vector( 0, 0, tar:GetVelocity().z ) )
                dmg:SetDamage( math.min( tar:Health() -1, dmg:GetDamage() ) )
            end
        end
    end )
    hook.Add( "CreateEntityRagdoll", "xdesc_Rag", function( ent, rag )
        if ent:GetClass() == "xdesc_bot" then
            timer.Simple( 2, function()
                if IsValid( rag ) then
                    rag:Fire( "FadeAndRemove" )
                end
            end )
        end
    end )
	hook.Add( "SetupPlayerVisibility", "xdesc_SPV", function( ply, view )
        if ply:GetNWBool( "XDESC" ) then
            if !ply:Alive() and isvector( ply.xdesc_M ) then
                AddOriginToPVS( ply.xdesc_M )
            end local glo = GetGlobal2Entity( "XDESC" )
            if IsValid( glo ) and IsValid( glo:GetXDE_Boss() ) then
                AddOriginToPVS( glo:GetXDE_Boss():GetPos() )
            end
        end
	end )

    function xdesc.UnitRegister( cls, tab ) --录入单位
        if !isstring( cls ) or cls == "" or cls == "_" or cls == "!V" or !istable( tab ) then return false end
		local inp = {}
		inp.Class       = cls --不动
		inp.Weapons     = ( isstring( tab.Weapons ) or istable( tab.Weapons ) ) and tab.Weapons or "_" --装备武器，留空为随机
        inp.Throws      = ( isstring( tab.Throws ) or istable( tab.Throws ) ) and tab.Throws or "_" --装备手雷，留空为随机
		inp.Model 		= ( isstring( tab.Model ) or istable( tab.Model ) ) and tab.Model or "models/player/kleiner.mdl" --模型
        inp.Speed       = isnumber( tab.Speed ) and math.max( tab.Speed, 0 ) or nil --速度乘积
        inp.Health      = isnumber( tab.Health ) and math.max( tab.Health, 0 ) or nil --血量乘积
        inp.Vox         = isstring( tab.Vox ) and tab.Vox or nil --声音
        inp.OnInit      = isfunction( tab.OnInit ) and tab.OnInit or nil --起始函
        inp.OnThink     = isfunction( tab.OnThink ) and tab.OnThink or nil --思考函
        inp.OnHurt      = isfunction( tab.OnHurt ) and tab.OnHurt or nil --受伤函
        inp.OnDeath     = isfunction( tab.OnDeath ) and tab.OnDeath or nil --死亡函
        xdesc.uns[ cls ] = inp
    end
    function xdesc.WeaponRegister( cls, tab ) --录入武器
        if !isstring( cls ) or cls == "" or cls == "_" or cls == "!V" or !istable( tab ) then return false end
		local inp = {}
		inp.Class       = cls --不动
		inp.HoldType    = ( isstring( tab.HoldType ) and istable( xdeshe_hts[ tab.HoldType ] ) ) and tab.HoldType or "normal" --持枪姿势
		inp.Model 		= isstring( tab.Model ) and tab.Model or "models/weapons/w_pistol.mdl" --模型
        inp.Range       = isnumber( tab.Range ) and math.max( tab.Range, 0 ) or 1024 --范围
        inp.Melee       = isbool( tab.Melee ) and tab.Melee or nil --是否为近战
        inp.Sight       = isbool( tab.Sight ) and tab.Sight or nil --是否为狙击(不能和近战一起)
        inp.SoundFire   = isstring( tab.SoundFire ) and tab.SoundFire or "!V" --枪声
        inp.SoundReload = isstring( tab.SoundReload ) and tab.SoundReload or "!V" --装弹声
        inp.ClipSize    = isnumber( tab.ClipSize ) and math.max( 0, tab.ClipSize ) or 0 --弹量
        inp.TimeReload  = ( isnumber( tab.TimeReload ) and math.max( 0, tab.TimeReload ) or 1 ) --装弹时间
        inp.FireMode    = ( istable( tab.FireMode ) and #tab.FireMode == 3 ) and tab.FireMode or { 0.2, 0, 0 } --开火方式
        inp.FuncFire    = isfunction( tab.FuncFire ) and tab.FuncFire or function( self, ent, wep ) end --开火函

        xdesc.wps[ cls ] = inp
    end
    function xdesc.ThrowRegister( cls, tab ) --录入投掷
        if !isstring( cls ) or cls == "" or cls == "_" or cls == "!V" or !istable( tab ) then return false end
		local inp = {}
		inp.Class       = cls --不动
        inp.Name        = isstring( tab.Name ) and tab.Name or "!V" --名称
        inp.Anim        = isnumber( tab.Anim ) and tab.Anim or nil --投掷动作
        inp.Straight    = isbool( tab.Straight ) and tab.Straight or false --平抛反之为上抛
		inp.Model 		= isstring( tab.Model ) and tab.Model or "models/weapons/w_grenade.mdl" --模型
        inp.Range       = isnumber( tab.Range ) and math.max( tab.Range, 0 ) or 1024 --距离
        inp.Timer       = isnumber( tab.Timer ) and tab.Timer or -1 --爆炸间隔
        inp.PhysSnd     = isstring( tab.PhysSnd ) and tab.PhysSnd or nil --碰撞音效
        inp.FuncInit    = isfunction( tab.FuncInit ) and tab.FuncInit or function( self, gre ) end --起始函
        inp.FuncOn      = isfunction( tab.FuncOn ) and tab.FuncOn or function( self, gre ) end --爆炸函
        xdesc.ths[ cls ] = inp
    end
    function xdesc.SpecRegister( cls, tab ) --录入突变
        if !isstring( cls ) or cls == "" or cls == "_" or cls == "!V" or !istable( tab ) then return false end
		local inp = {}
		inp.Class       = cls
        inp.Info        = isstring( tab.Info ) and tab.Info or "!V"
		inp.OnSpawn 	= isfunction( tab.OnSpawn ) and tab.OnSpawn or nil
        inp.OnDeath 	= isfunction( tab.OnDeath ) and tab.OnDeath or nil
        inp.OnHurt 	    = isfunction( tab.OnHurt ) and tab.OnHurt or nil
		inp.OnTick   	= isfunction( tab.OnTick ) and tab.OnTick or nil
        xdesc.mts[ cls ] = inp
    end
    function xdesc.UnitSpawn( cls, pos, wan, dif, spd, wav, boss ) --生成单位
        if !isstring( cls ) then return nil end local tab = xdesc.uns[ cls ]
        if !istable ( tab ) then return nil end
        local bos = ( isnumber( wav ) and math.max( 1, 1 +wav/30 ) or 1 )
        local nb = ents.Create( "xdesc_bot" )
		local areas = navmesh.Find( pos, 128, nb.loco:GetDeathDropHeight(), nb.loco:GetJumpHeight() )
		if #areas > 0 then
			local ran = VectorRand():GetNormalized()*math.random( -128, 128 )
			local goa = areas[ math.random( #areas ) ]:GetClosestPointOnArea( pos +Vector( ran.x, ran.y, 0 ) )
            local tr = util.TraceHull( {
                start = pos, endpos = goa, filter = nb, mask = MASK_NPCSOLID_BRUSHONLY,
                maxs = Vector( 14, 14, 72 ), mins = Vector( -14, -14, 0 )
            }, nb )
            pos = tr.HitPos +tr.HitNormal
        end
        nb:SetPos( pos )
        nb:SetAngles( Angle( 0, math.random( 0, 360 ), 0 ) )
        local mdl = "_"  if isstring( tab.Model ) then mdl = tab.Model
        elseif istable( tab.Model ) then mdl = tab.Model[ math.random( #tab.Model ) ] end
        if mdl == "_" then for k, v in RandomPairs( player_manager.AllValidModels() ) do mdl = v break end end
        nb:SetModel( mdl ) nb:Spawn() nb:Activate()
        nb.NBType = cls
        local ent = GetGlobal2Entity( "XDESC" )
        local dhp = ( xdesc.dts[ 4 ][ dif ] or 1 )
        local dh2 = ( tab.Health or ( xdesc.wvs[ ent.NB ] and xdesc.wvs[ ent.NB ].Health or 1 ) )
        if boss and IsValid( ent ) and ent:GetXDE_BossHP() > 0 then
            nb:SetMaxHealth( math.ceil( 7000*bos*dhp*dh2 ) )
            nb:SetHealth( math.ceil( 7000*ent:GetXDE_BossHP()*bos*dhp*dh2 ) )
            ent:SetXDE_Boss( nb )
        else
            nb:SetMaxHealth( math.ceil( 100*bos*dhp*dh2 ) )
            nb:SetHealth( math.ceil( 100*bos*dhp*dh2 ) )
        end
        nb:SetHealth2( nb:Health() ) nb:SetWander( isbool( wan ) and wan or false )
		local exp = string.Explode( "/", string.Replace( nb:GetModel(), "_", " " ) )  exp = exp[ #exp ]
		exp = string.Left( exp, string.len( exp ) -4 )
		exp = string.upper( string.Left( exp, 1 ) )..string.Right( exp, string.len( exp ) -1 )
		nb:SetNick( exp ) nb:SetDiffi( dif ) nb.Vox = tab.Vox
        nb:SetAI( spd == 4 and math.random( 1, 3 ) or math.min( 3, spd ) )
        nb:SetSpeed( ( tab.Speed or 1 ) )
        nb:GiveThrow( xdesc.PickTable( tab.Throws ) )
        nb:GiveWeapon( xdesc.PickTable( tab.Weapons ) )
        local spec = xdesc.GetSpec()
        if istable( spec ) and spec.OnSpawn then
            spec:OnSpawn( 1, nb )
        end
        local ent = GetGlobal2Entity( "XDESC" )
        return nb
    end
    function xdesc.ThrowSpawn( cls, pos, vel, dif, own ) --生成投掷
        if !isstring( cls ) then return nil end
        local tab = xdesc.ths[ cls ]
        if !istable ( tab ) then return nil end
        local gre = ents.Create( "xdesc_throw" )
        gre:SetPos( pos )
        gre:SetModel( tab.Model )
        gre:Spawn()
        gre:Activate()
        if IsValid( own ) then
            constraint.NoCollide( own, gre )
        end
        tab:FuncInit( gre, own )
        gre:GetPhysicsObject():SetVelocity( vel )
        gre:GetPhysicsObject():AddAngleVelocity( -gre:GetAngles():Forward()*vel:Length() )
        gre:SetTimer( tab.Timer )
        gre:SetDiffi( dif )
        gre:SetNick( IsValid( own ) and own:GetNick() or "???" )
        gre.PhysSnd = tab.PhysSnd or "Grenade.ImpactHard"
        gre.ThrowCls = cls
        local spec = xdesc.GetSpec()
        if istable( spec ) and spec.OnSpawn then
            spec:OnSpawn( 2, gre )
        end
        return gre
    end
    function xdesc.PickSpec() --挑选突变
        if true then return "ghosttown" end
        if table.IsEmpty( xdesc.mts ) then return "" end
        for k, v in RandomPairs( xdesc.mts ) do return k end
    end
    function xdesc.LoadoutSave( ply ) --装备存储
        if CLIENT or !IsValid( ply ) then return end
        ply.XDESC_LWEP = {}  ply.XDESC_LAMO = {}
        for k, v in pairs( ply:GetWeapons() ) do ply.XDESC_LWEP[ v:GetClass() ] = tostring( v:Clip1() ).."|"..tostring( v:Clip2() ) end
        for k, v in pairs( game.GetAmmoTypes() ) do ply.XDESC_LAMO[ v ] = ply:GetAmmoCount( v ) end
    end
    function xdesc.LoadoutLoad( ply ) --装备读取
        if CLIENT or !IsValid( ply ) then return end
        timer.Simple( 0, function()
            if IsValid( ply ) and ply:Alive() then
                ply:StripWeapons() ply:RemoveAllAmmo()
                if istable( ply.XDESC_LWEP ) then for k, v in pairs( ply.XDESC_LWEP ) do
                    ply:Give( k ) local wep = ply:GetWeapon( k ) local tab = string.Explode( "|", v )
                    if IsValid( wep ) then wep:SetClip1( tonumber( tab[ 1 ] ) ) wep:SetClip2( tonumber( tab[ 2 ] ) ) end end
                end
                if istable( ply.XDESC_LAMO ) then for k, v in pairs( ply.XDESC_LAMO ) do ply:SetAmmo( v, k ) end end
                ply.XDESC_LWEP = nil  ply.XDESC_LAMO = nil
            end
        end )
    end

    net.Receive( "xdesc_Start", function( len, ply )
        if len > 2048 or !ply:IsAdmin() then return end
        local tab = util.JSONToTable( net.ReadString() )
        if !istable( tab ) or #tab != #xdesc.cns then return end
        local ent = nil
        for k, v in pairs( ents.FindByClass( "sent_she_scenario" ) ) do
            if IsValid( v ) then
                ent = v
                break
            end
        end
        if ent == nil then return end
        for k, v in pairs( tab ) do
            v = tonumber( v )
            if !isnumber( v ) then return end
            v = math.Clamp( v, 1, xdesc.cns[ k ] )
            tab[ k ] = v
        end
        SetGlobal2Entity( "XDESC", ent )
        ent:SetXDE_State( 1 )
        ent:SetXDE_Enemy( 0 )
        ent:SetXDE_Player( 0 )
        ent:SetXDE_Wave( 0 )
        ent:SetXDE_Gamemode( tab[ 3 ] )
        ent:SetXDE_MWave( xdesc.dts[ 1 ][ tab[ 1 ] ] )
        ent:SetXDE_Timer( CurTime() +( GetConVar( "developer" ):GetInt() > 0 and 0 or 5 ) )
        ent.StoreDat = tab  ent.Result[ 4 ] = ent.StoreDat
        ent:EmitSound( "ui/beep22.wav", 80, 100 )
    end )
    net.Receive( "xdesc_Ready", function( len, ply )
        if len > 0 or !ply:GetNWBool( "XDESC" ) or !IsValid( GetGlobal2Entity( "XDESC" ) )
        or GetGlobal2Entity( "XDESC" ):GetXDE_State() != 2 then return end
        ply:SetNWBool( "XDESC_P", !ply:GetNWBool( "XDESC_P" ) )
        for k, v in pairs( GetGlobal2Entity( "XDESC" ).PlayerJoin ) do
            if !IsValid( v ) then continue end
            net.Start( "xdesc_ReadyCL" ) net.WriteEntity( ply ) net.WriteBool( ply:GetNWBool( "XDESC_P" ) ) net.Send( v )
        end
    end )
    net.Receive( "xdesc_Cam", function( len, ply )
        if !IsValid( ply ) or ply:Alive() or !ply:GetNWBool( "XDESC" ) then return end
        local exp = string.Explode( " ", net.ReadString() )
        if !istable( exp ) or #exp != 3 then return end
        local xx, yy, zz = tonumber( exp[ 1 ] ), tonumber( exp[ 2 ] ), tonumber( exp[ 3 ] )
        if !isnumber( xx ) or !isnumber( yy ) or !isnumber( zz ) then return end
        ply.xdesc_M = Vector( xx, yy, zz )
    end )
    net.Receive( "xdesc_Leave", function( len, ply )
        if !IsValid( ply ) or !ply:GetNWBool( "XDESC" ) or len > 0 then return end
        local ent = GetGlobal2Entity( "XDESC" )
        if !IsValid( ent ) or ent:GetXDE_State() < 2 then return end
        if ( !ply:Alive() and ent:GetXDE_State() == 3 ) or ( ent:GetXDE_State() == 2 ) then
            ply:SetNWBool( "XDESC", false )
            ply:SetNWBool( "XDESC_P", false )
            ply:SetNWFloat( "XDESC_F", 0 )
            ply.xdesc_C = nil  ply.xdesc_M = nil
            ply.XDESC_LWEP = nil  ply.XDESC_LAMO = nil
            xdeshe_MenuClose( ply, "xdesc2" )
        end
    end )
else
    xdesc.mat1 = xdeshe_OnceMat( "gui/gradient_down" )
    xdesc.mat2 = xdeshe_OnceMat( "vgui/hud/icon_locator_generic" )
    xdesc.mat3 = xdeshe_OnceMat( "gui/center_gradient" )
    xdesc.mat4 = xdeshe_OnceMat( "vgui/zoom" )
    xdesc.mats = {
        xdeshe_OnceMat( "xdeedited/sc_undead.png" ),
        xdeshe_OnceMat( "xdeedited/sc_resistance.png" ),
        xdeshe_OnceMat( "xdeedited/sc_enforcer.png" ),
        xdeshe_OnceMat( "xdeedited/sc_combine.png" ),
        xdeshe_OnceMat( "xdeedited/sc_random.png" ),
        xdeshe_OnceMat( "xdeedited/sc_mixed.png" )
    }

    xdesc.count = -1  xdesc.alpha = -1  xdesc.uilobby = nil
    xdesc.campos = Vector( 0, 0, 0 )  xdesc.camang = Angle( 0, 0, 0 )  xdesc.cament = nil
    xdesc.camtar = false  xdesc.camdel = 0

    hook.Add( "CreateMove", "xdesc_cm", function( cmd )
        local ply = LocalPlayer()
        if !ply:Alive() and IsValid( xdeshe_vguis[ "xdesc3" ] ) then
            local pp, aa = xdesc.campos, xdesc.camang
            if IsValid( xdesc.cament ) and ( !xdesc.cament:Alive() or !xdesc.cament:GetNWBool( "XDESC" ) ) then xdesc.cament = nil end
            if !IsValid( xdesc.cament ) or !xdesc.camtar then
                local spd = GetConVar( "sv_noclipspeed" ):GetFloat()*( xdesc.camdel > CurTime() and 0 or 1 )
                if cmd:KeyDown( IN_SPEED ) then spd = spd*2 elseif cmd:KeyDown( IN_WALK ) then spd = spd/2 end
                if cmd:KeyDown( IN_FORWARD ) then
                    pp = pp +EyeAngles():Forward()*spd
                end if cmd:KeyDown( IN_BACK ) then
                    pp = pp +EyeAngles():Forward()*-spd
                end
                if cmd:KeyDown( IN_MOVELEFT ) then
                    pp = pp +EyeAngles():Right()*-spd
                end if cmd:KeyDown( IN_MOVERIGHT ) then
                    pp = pp +EyeAngles():Right()*spd
                end
            end
            xdesc.camang = cmd:GetViewAngles()
            cmd:ClearButtons()  cmd:ClearMovement()
            xdesc.campos = pp
        end
    end )
    hook.Add( "CalcView", "xdesc_cv", function( ply, pos, angles, fov )
        if !ply:Alive() and IsValid( xdeshe_vguis[ "xdesc3" ] ) and ply:GetNWBool( "XDESC" ) then
            local pp, aa = xdesc.campos, xdesc.camang
            if IsValid( xdesc.cament ) and xdesc.camtar then
                local tr = util.TraceHull( {
                    start = xdesc.cament:WorldSpaceCenter(),
                    endpos = xdesc.cament:WorldSpaceCenter() -xdesc.camang:Forward()*128,
                    filter = xdesc.cament,
                    mins = Vector( -4, -4, -4 ),
                    maxs = Vector( 4, 4, 4 ),
                    mask = MASK_SOLID_BRUSHONLY
                } )
                pp = tr.HitPos +tr.HitNormal
                aa = ( tr.StartPos -tr.HitPos ):Angle()
            end
            local view = {
                origin = pp,
                angles = aa,
                fov = fov,
                drawviewer = false
            }
            return view
        end
    end )
    hook.Add( "HUDPaint", "xdesc_hud", function()
        local ent, ply = GetGlobal2Entity( "XDESC" ), LocalPlayer()
        if IsValid( ply ) and ply:Alive() then
            local tr = util.TraceLine( util.GetPlayerTrace( LocalPlayer() ) )
            if IsValid( tr.Entity ) and tr.Entity:GetClass() == "xdesc_bot" and tr.Entity:GetRenderFX() == 0 then --悬停NPC标签
                local nen = ( IsValid( ent ) and ent:GetXDE_State() == 3 and !ply:GetNWBool( "XDESC" ) )
                local vel = tr.Entity:GetPlayerColor()
                local col = !nen and Color( 255, 255, 255 ) or Color( vel.x*255, vel.y*255, vel.z*255 )
                local text = tr.Entity:GetNick()  local pos = tr.Entity:WorldSpaceCenter():ToScreen()
                local xx, yy = pos.x, pos.y
                draw.SimpleTextOutlined( text, "xdeshe_Font2", xx, yy, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 192 ) )
                local text = math.ceil( tr.Entity:GetHealth2() ).."%"
                draw.SimpleTextOutlined( text, "xdeshe_Font4", xx, yy +25, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 192 ) )
                if nen then
                    draw.SimpleTextOutlined( language.GetPhrase( "xdeshe.NotInGame" ), "xdeshe_Font4", xx, yy +45, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 192 ) )
                end
            end
            if IsValid( ent ) then
                if ply:GetNWBool( "XDESC" ) and ent.PlayerJoin and !table.IsEmpty( ent.PlayerJoin ) then
                    for k, v in pairs( ent.PlayerJoin ) do
                        if !IsValid( v ) or !v:Alive() or !v:GetNWBool( "XDESC" ) or v == LocalPlayer() then continue end
                        local dis = v:GetPos():Distance( ply:GetPos() )
                        local alp = math.Clamp( ( 2048 -dis )/2048, 0, 1 )*200
                        local scr = ( v:EyePos() +Vector( 0, 0, 16 ) ):ToScreen()
                        draw.SimpleTextOutlined( v:Nick().." ("..v:Health()..")", "xdeshe_Font4", scr.x, scr.y, Color( 0, 255, 255, alp ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, alp ) )
                    end
                end
                local gmm = ent:GetXDE_Gamemode()
                local fin = ( gmm == 1 and ent:GetXDE_Timer() <= CurTime() ) or ( gmm == 2 and ent:GetXDE_Timer() <= 0 )
                or ( gmm == 3 and ent:GetXDE_MWave() != -1 and ( CurTime() -ent:GetXDE_Timer() ) >= ent:GetXDE_MWave()*120 )
                if ply:GetNWBool( "XDESC" ) and ent:GetXDE_BossHP() <= 0 and fin then --倒计时结束标记NPC
                    for k, v in pairs( ents.FindByClass( "xdesc_bot" ) ) do
                        if IsValid( v ) and v:Health() > 0 then
                            local pos, col = v:WorldSpaceCenter():ToScreen(), v:GetPlayerColor()
                            draw.SimpleTextOutlined( "D", "xdeshe_Font12", pos.x, pos.y, Color( col.x*255, col.y*255, col.z*255, 128 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 128 ) )
                        end
                    end
                end
                if ply:GetNWBool( "XDESC" ) and ent:GetXDE_BossHP() > 0 then --标记Boss
                    for k, v in pairs( ents.FindByClass( "xdesc_bot" ) ) do
                        if IsValid( v ) and v:Health() > 0 and ent:GetXDE_Boss() == v then
                            local pos = v:WorldSpaceCenter():ToScreen()
                            draw.SimpleTextOutlined( "D", "xdeshe_Font12", pos.x, pos.y, Color( 255, 0, 255, 128 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 128 ) )
                            break
                        end
                    end
                end
                if ent:GetXDE_State() == 1 then --玩家参与倒计时
                    local dis = ply:GetPos():Distance( ent:GetPos() )
                    if dis <= 256 and ply:Alive() and !ply:InVehicle() then
                        local num = math.abs( math.max( 0, math.ceil( ent:GetXDE_Timer() -CurTime() ) ) )
                        if xdesc.count != num then
                            if xdesc.count != -1 then surface.PlaySound( "ui/beep07.wav" ) end
                            xdesc.count = num
                        end
                        if xdesc.alpha == -1 then
                            xdesc.alpha = SysTime() +0.5
                        end
                        local alp = 255 -math.Clamp( ( xdesc.alpha -SysTime() )/0.5, 0, 1 )*255
                        draw.TextShadow( {
                            text = language.GetPhrase( "xdeshe.SC_Begin1" )..xdesc.count..language.GetPhrase( "xdeshe.SC_Begin2" ),
                            pos = { ScrW()/2, ScrH()/2 -8 -128 },
                            font = "xdeshe_Font3",
                            xalign = TEXT_ALIGN_CENTER,
                            yalign = TEXT_ALIGN_CENTER,
                            color = Color( 255, 255, 255, alp )
                        }, 1, alp )
                        draw.TextShadow( {
                            text = language.GetPhrase( "xdeshe.SC_Begin3" ).." ( "..ent:GetXDE_Player().." / 8 )",
                            pos = { ScrW()/2, ScrH()/2 +32 -128 },
                            font = "xdeshe_Font2",
                            xalign = TEXT_ALIGN_CENTER,
                            yalign = TEXT_ALIGN_CENTER,
                            color = ent:GetXDE_Player() >= 8 and Color( 255, 0, 0, alp ) or Color( 255, 255, 255, alp )
                        }, 1, alp )
                    end
                else
                    if xdesc.count != -1 then xdesc.count = -1 end
                    if xdesc.alpha != -1 then xdesc.alpha = -1 end
                end
            end
        end
    end )
	hook.Add( "PlayerBindPress", "xdesc_pbp", function( ply, bind, pressed )
		if ply:GetNWBool( "XDESC" ) and IsValid( GetGlobal2Entity( "XDESC" ) ) and pressed == true then
            local gen = GetGlobal2Entity( "XDESC" )
            if string.find( bind, "+zoom" ) and IsValid( xdesc.uilobby ) and gen:GetXDE_State() == 2 and gen:GetXDE_Timer() -CurTime() <= 44 and ply:Alive() then
			    net.Start( "xdesc_Ready" ) net.SendToServer()
                return true
		    end
            if IsValid( xdeshe_vguis[ "xdesc3" ] ) then local fce = false
                if string.find( bind, "jump" ) then
                    xdesc.camtar = !xdesc.camtar
                    if xdesc.camtar and !IsValid( xdesc.cament ) then fce = true end
                end
                if ( string.find( bind, "attack" ) or string.find( bind, "attack2" ) or fce ) and xdesc.camtar then
                    local pre = string.find( bind, "attack2" )  local joi, jo2 = {}, GetGlobal2Entity( "XDESC" ).PlayerJoin
                    if istable( jo2 ) and !table.IsEmpty( jo2 ) then
                        for k, v in pairs( jo2 ) do
                            if !IsValid( v ) or !v:IsPlayer() or !v:GetNWBool( "XDESC" ) or !v:Alive() then continue end
                            table.insert( joi, v )
                        end
                        for k, v in pairs( joi ) do
                            if !IsValid( xdesc.cament ) then xdesc.cament = v  break elseif xdesc.cament == v then
                                xdesc.cament = ( pre and joi[ k == 1 and #joi or k-1 ] or joi[ k == #joi and 1 or k+1 ] )
                                xdesc.campos = xdesc.cament:WorldSpaceCenter()  break
                            end
                        end
                    end
                    return true
                end
            end
        end
	end )
    hook.Add( "CreateClientsideRagdoll", "xdesc_ccr", function( ent, rag ) --NPC死亡后2秒删除布娃娃
        if ent:GetClass() == "xdesc_bot" then
            timer.Simple( 2, function()
                if IsValid( rag ) then rag:SetSaveValue( "m_bFadingOut", true ) end
            end )
        end
    end )
    hook.Add( "RenderScreenspaceEffects", "xdesc_rse", function() --偷吃闪光弹
        local ply = LocalPlayer()
        if IsValid( ply ) and ply:Alive() and ply:GetNWFloat( "XDESC_F" ) > CurTime() then
            local per = math.Clamp( 1 -( ply:GetNWFloat( "XDESC_F" ) -CurTime() )/2, 0, 1 )
            DrawBloom( per, ( 1-per )*10, 10, 10, 1, 1, 1, 1, 1 )
            DrawMotionBlur( 0.4*( 1-per ), 0.8*( 1-per ), 0.1 )
        elseif IsValid( xdeshe_vguis[ "xdesc3" ] ) and ply:GetNWBool( "XDESC" ) then
            local per = math.Clamp( ( xdeshe_vguis[ "xdesc3" ].N_Lerp -SysTime() ), 0.001, 1 )
            if per > 0 then
                local Screener = {
                    ["$pp_colour_addr"] = 0,
                    ["$pp_colour_addg"] = 0,
                    ["$pp_colour_addb"] = 0,
                    ["$pp_colour_brightness"] = 0,
                    ["$pp_colour_contrast"] = 1,
                    ["$pp_colour_colour"] = per,
                    ["$pp_colour_mulr"] = 0,
                    ["$pp_colour_mulg"] = 0,
                    ["$pp_colour_mulb"] = 0
                }
                DrawColorModify( Screener )
            end
        end
    end )
    hook.Add( "HUDShouldDraw", "xdesc_hudsd", function( name ) --感谢老铁送来的防死亡红屏
        local ply = LocalPlayer()
        if IsValid( ply ) and ply:GetNWBool( "XDESC" ) and name == "CHudDamageIndicator" then 
            return false 
        end
    end )

    net.Receive( "xdesc_Hud", function() --左侧准备条
        if xdesc.uilobby then xdesc.uilobby:Remove() end
        local dat, plys = util.JSONToTable( net.ReadString() ), {}
        for k, v in pairs( player.GetAll() ) do
            if dat[ v:SteamID() ] == 1 then table.insert( plys, v ) v.XDESC_P = false end
        end
        if IsValid( GetGlobal2Entity( "XDESC" ) ) then
            GetGlobal2Entity( "XDESC" ).PlayerJoin = plys
        end
        local pax = vgui.Create( "DPanel" )  xdesc.uilobby = pax
        pax:SetPos( 8 -300, ScrH()*0.1 )
        pax:SetSize( 350, 40 +54*#plys )
        pax:SetAlpha( 1 )
        pax:AlphaTo( 255, 0.5 )
        pax:MoveTo( 8, ScrH()*0.1, 0.5 )
        pax.T_Players = plys
        pax.T_Types = {}
        pax.T_Anims = {}
        pax.N_State = -1
        pax.N_Start = CurTime() +1
        pax.N_Delay = SysTime() +0.5
        for k, v in pairs( plys ) do
            table.insert( pax.T_Types, false ) table.insert( pax.T_Anims, 0 )
        end
        function pax:Paint( w, h )
            if pax.N_Start <= CurTime() and ( !IsValid( GetGlobal2Entity( "XDESC" ) ) or !LocalPlayer():GetNWBool( "XDESC" ) ) then
                pax:Remove()
                return
            end
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) then return end
            draw.RoundedBox( 0, 6, 6, w -12, 40 -12, Color( 0, 0, 0, 200 ) )
            surface.SetDrawColor( 0, 0, 0, 192 ) surface.DrawOutlinedRect( 0, 0, w, 40, 4 )
            surface.SetDrawColor( 255, 255, 255, 192 ) surface.DrawOutlinedRect( 0, 0, w, 40, 1 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.SC_Ready1" )..string.upper( input.LookupBinding( "+zoom", true ) or "+zoom" )..language.GetPhrase( "xdeshe.SC_Ready2" ),
                pos = { w/2, 20 },
                font = "xdeshe_Font2",
                xalign = TEXT_ALIGN_CENTER,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
            for i=1, #pax.T_Players do
                if !IsValid( pax.T_Players[ i ] ) then continue end
                local rd = pax.T_Players[ i ].XDESC_P
                if pax.T_Types[ i ] != rd and !pax.B_Finish then
                    timer.Create( "xdesc_readysnd", 0.1, 1, function()
                        surface.PlaySound( rd and "ui/matchmake_count.wav" or "ui/menu_click04.wav" )
                    end )
                    pax.T_Types[ i ] = rd
                    pax.T_Anims[ i ] = SysTime() +0.5
                    pax.N_Delay = SysTime() +0.5
                end rd = pax.T_Types[ i ]
                local alp = math.Clamp( ( pax.T_Anims[ i ] -SysTime() )/0.5, 0, 1 )
                draw.RoundedBox( 0, 0, i*54 -8, w, 48, rd and Color( 0, 55, 0, 200 ) or Color( 55, 0, 0, 200 ) )
                surface.SetDrawColor( rd and Color( 0, 255, 0, 200 ) or Color( 255, 0, 0, 200 ) )
                surface.DrawOutlinedRect( 0, i*54 -8, w, 48, 2 )
                surface.SetDrawColor( rd and Color( 0, 255, 0, alp*255 ) or Color( 255, 0, 0, alp*255 ) )
                surface.DrawRect( 0, i*54 -8, w, 48 )
                draw.TextShadow( {
                    text = pax.T_Players[ i ]:Nick(),
                    pos = { 50, i*54 +8 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_LEFT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255, 255, 255 )
                }, 1, 255 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe."..( rd and "Ready" or "NotReady" ) ),
                    pos = { w -6, i*54 +22 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_RIGHT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = rd and Color( 0, 255, 0 ) or Color( 255, 0, 0 )
                }, 1, 255 )
            end
            local sta = ent:GetXDE_State()
            if pax.N_State != sta and pax.N_Delay <= SysTime() then
                pax.N_State = sta
                if sta != 2 then
                    pax:AlphaTo( 0, 0.5 )
                    timer.Simple( 0.5, function()
                        if IsValid( pax ) then pax:Remove() end
                    end )
                end
            end
        end
        for i=1, #pax.T_Players do
            local avt = pax:Add( "AvatarImage" )
            avt:SetSize( 40, 40 )
            avt:SetPos( 4, i*54 -4 )
            avt:SetPlayer( pax.T_Players[ i ], 64 )
        end
    end )
	net.Receive( "xdesc_Notify", function()
		local pan = xdeshe_vguis[ "xdesc2" ]  if !IsValid( pan ) then return end
		pan:ReceiveNotify( util.JSONToTable( net.ReadString() ) )
	end )
    net.Receive( "xdesc_ReadyCL", function()
        local ent, bol = net.ReadEntity(), net.ReadBool()
        if IsValid( ent ) then ent.XDESC_P = bol end
    end )

    if true then local nam = "xdesc_molotov"
        local EFFECT = {}
        function EFFECT:Init( data )
            local pos, sca = data:GetOrigin(), math.Clamp( data:GetScale(), 1, 10 )
            self.Emitter = ParticleEmitter( pos )
            self.NextEmit = 0
            self:SetRenderBounds( -Vector( 512, 512, 512 ), Vector( 512, 512, 512 ) )
            sound.Play( "^weapons/molotov/molotov_detonate_3.wav", pos, 80, math.random( 110, 120 ) -5*sca, 1 )
            for i=1, 8 do
                local particle = self.Emitter:Add( "effects/fire_cloud"..math.random( 1, 2 ), pos +Vector( 0, 0, 8 ) )
                if particle then
                    particle:SetVelocity( VectorRand():GetNormalized()*400*sca/5 )
                    particle:SetLifeTime( 0 )
                    particle:SetDieTime( math.Rand( 0.5, 1 ) )
                    particle:SetStartAlpha( 255 )
                    particle:SetEndAlpha( 0 )
                    local Siz = math.Rand( 32, 64 )*sca/5
                    particle:SetStartSize( Siz )
                    particle:SetEndSize( Siz*2 )
                    particle:SetGravity( Vector( 0, 0, 50 ) )
                    particle:SetColor( 255, 255, 155 )
                    particle:SetAirResistance( 400 )
                    particle:SetRoll( math.random( 0, 360 ) )
                end
            end
            for i=1, 32 do
                local particle = self.Emitter:Add( "particle/particle_smokegrenade1", pos +Vector( 0, 0, 8 ) )
                if particle then
                    particle:SetVelocity( VectorRand():GetNormalized()*200*sca/5 )
                    particle:SetLifeTime( 0 )
                    particle:SetDieTime( math.Rand( 3, 6 ) )
                    particle:SetStartAlpha( 255 )
                    particle:SetEndAlpha( 0 )
                    local Siz = math.Rand( 64, 128 )*sca/5
                    particle:SetStartSize( Siz/4 )
                    particle:SetEndSize( Siz )
                    particle:SetRoll( math.random( 0, 360 ) )
                    particle:SetColor( 55, 55, 55 )
                    particle:SetGravity( Vector( 0, 0, 0 ) )
                    particle:SetAirResistance( 100 )
                    particle:SetCollide( true )
                    particle:SetBounce( 1 )
                end
            end
            for i=1, 24 do
                local particle = self.Emitter:Add( "effects/fire_cloud"..math.random( 1, 2 ), pos )
                if particle then
                    particle:SetVelocity( VectorRand():GetNormalized()*math.random( 250, 500 )*sca/5 )
                    particle:SetLifeTime( 0 )
                    particle:SetDieTime( math.Rand( 0.5, 1 ) )
                    particle:SetStartAlpha( 255 )
                    particle:SetEndAlpha( 0 )
                    local Siz = math.Rand( 32, 64 )*sca/5
                    particle:SetStartSize( Siz/4 )
                    particle:SetEndSize( Siz/4 )
                    particle:SetStartLength( Siz )
                    particle:SetEndLength( Siz )
                    particle:SetColor( 255, 255, 155 )
                    particle:SetAirResistance( 200 )
                    particle:SetRoll( math.random( 0, 360 ) )
                end
            end
            self.Emitter:Finish()
        end
        function EFFECT:Think() return false end
        function EFFECT:Render() end
        effects.Register( EFFECT, nam )
    end
    if true then local nam = "xdesc_flash"
        local EFFECT = {}
        function EFFECT:Init( data )
            local pos = data:GetOrigin()
            self:SetRenderBounds( -Vector( 512, 512, 512 ), Vector( 512, 512, 512 ) )
            self.Emitter = ParticleEmitter( pos )
            for i=1, 1 do
                local particle = self.Emitter:Add( "particle/warp2_warp", pos )
                particle:SetLifeTime( 0 )
                particle:SetDieTime( 0.25 )
                local Size = 10
                particle:SetStartSize( 0 )
                particle:SetEndSize( Size*16 )
                particle:SetStartAlpha( 128 )
                particle:SetEndAlpha( 0 )
                particle:SetRoll( math.random( 0, 360 ) )
                particle:SetColor( 255, 255, 255 )
                particle:SetLighting( false )
            end
            for i=1, 4 do
                local particle = self.Emitter:Add( "particle/particle_glow_04", pos )
                particle:SetLifeTime( 0 )
                particle:SetDieTime( 0.25 )
                local Size = 10
                particle:SetStartSize( 0 )
                particle:SetEndSize( Size*16 )
                particle:SetStartAlpha( 255 )
                particle:SetEndAlpha( 0 )
                particle:SetRoll( math.random( 0, 360 ) )
                particle:SetColor( 255, 255, 255 )
                particle:SetLighting( false )
            end
            for i=1, math.random( 16, 24 ) do
                local particle = self.Emitter:Add( "effects/spark", pos )
                particle:SetVelocity( VectorRand():GetNormalized()*math.random( 128, 512 ) )
                particle:SetLifeTime( 0 )
                particle:SetDieTime( 0.5 )
                local Siz = math.Rand( 4, 8 )
                particle:SetStartSize( Siz )
                particle:SetEndSize( 0 )
                particle:SetStartLength( Siz*2 )
                particle:SetEndLength( Siz )
                particle:SetStartAlpha( 128 )
                particle:SetEndAlpha( 0 )
                particle:SetColor( 255, 255, 255 )
                particle:SetLighting( false )
                particle:SetCollide( true )
                particle:SetGravity( Vector( 0, 0, -128 ) )
                particle:SetBounce( 1 )
            end
            for i=1, math.random( 16, 24 ) do
                local particle = self.Emitter:Add( "particle/particle_smokegrenade1", pos +Vector( 0, 0, 8 ) )
                if particle then
                    particle:SetVelocity( VectorRand():GetNormalized()*math.random( 64, 256 ) )
                    particle:SetLifeTime( 0 )
                    particle:SetDieTime( math.Rand( 1.5, 3 ) )
                    particle:SetStartAlpha( 128 )
                    particle:SetEndAlpha( 0 )
                    local Siz = math.Rand( 32, 64 )
                    particle:SetStartSize( Siz/4 )
                    particle:SetEndSize( Siz )
                    particle:SetRoll( math.random( 0, 360 ) )
                    particle:SetColor( 128, 128, 128 )
                    particle:SetGravity( Vector( 0, 0, math.random( 32, 64 ) ) )
                    particle:SetAirResistance( 128 )
                    particle:SetCollide( true )
                    particle:SetBounce( 1 )
                end
            end
            local dlight = DynamicLight( 0 )
            if dlight then
                dlight.pos = pos
                dlight.r = 255
                dlight.g = 255
                dlight.b = 255
                dlight.brightness = 4
                dlight.decay = 2048
                dlight.size = 1024
                dlight.dietime = CurTime()+0.5
            end
        end
        function EFFECT:Think() return false end
        function EFFECT:Render() return end
        effects.Register( EFFECT, nam )
    end
    xdeshe_MenuRegister( "xdesc", function( id, ent, dat ) --巨几把长的装配界面
        local now = IsValid( xdeshe_vguis[ id ] )
        local pan = ( IsValid( xdeshe_vguis[ id ] ) and xdeshe_vguis[ id ] or vgui.Create( "DFrame" ) )
        surface.PlaySound( "ui/hint.wav" ) local lr = false
        pan:Show()
        pan:SetSize( 60, 40 )
        pan:Center()
        pan:MakePopup()
        pan:SetAlpha( 1 )
        pan:AlphaTo( 255, 0.2 )
        pan:SizeTo( 600, 40, 0.2 )
        pan:SizeTo( 600, 384, 0.2, 0.3 )
        pan:MoveTo( ScrW()/2 -300, ScrH()/2 -20, 0.2 )
        pan:MoveTo( ScrW()/2 -300, ScrH()/2 -192, 0.2, 0.3 )
        pan.B_Close = false
        pan.N_Cool = 0
        pan.N_Change = 0
        pan.P_Sub = nil
        xdeshe_mark = nil  xdeshe_mtype = nil  xdeshe_delay = 0
        if now then return end
        pan.N_Select = 1
        pan:SetTitle( "" )
        pan:ShowCloseButton( false )
        pan:SetScreenLock( true )
        pan:SetDeleteOnClose( true )
        local function CreateAButton( pax, txt, x, y, w, h ) --按钮
            local but = pax:Add( "DButton" )
            but:SetSize( w, h )
            but:SetPos( x, y )
            but:SetText( "" )
            but.B_Hover = false
            but.N_Click = 0
            function but:Paint( w, h )
                local alp = math.Clamp( ( but.N_Click-SysTime() )/0.3, 0, 1 )
                surface.SetDrawColor( 125, 125, 125 ) surface.DrawRect( 0, 0, w, h )
                surface.SetDrawColor( 128, 128, 128 ) surface.DrawRect( 0, h/2, w, h/2 )
                surface.SetDrawColor( 255, 255, 255, alp*255 ) surface.DrawRect( 0, 0, w, h )
                surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
                surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 0, 0, w, h )
                draw.TextShadow( {
                    text = language.GetPhrase( txt ),
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255 -alp*255, 255 -alp*255, 255 -alp*255 )
                }, 1, 255 )
            end
            function but:OnCursorEntered() but.B_Hover = true end
            function but:OnCursorExited() but.B_Hover = false end
            function but:DoClick2() end
            function but:DoClick()
                if pan.N_Cool > SysTime() then return end
                surface.PlaySound( "ui/buttonclick.wav" )
                pan.N_Cool = SysTime() +0.2
                but.N_Click = SysTime() +0.2
                but:DoClick2()
            end
            return but
        end
        local function CreateATab( pax, txt, x, y, w, h, tab, con, tag ) --下拉框
            local but = pax:Add( "DButton" )
            but:SetSize( w, h )
            but:SetPos( x, y )
            but:SetText( "" )
            but.B_Hover = false
            but.N_Click = 0
            but.S_ConVar = con
            but.N_Select = math.Clamp( GetConVar( con ):GetInt(), 1, #tab )
            but.S_Tag = tag
            function but:Paint( w, h )
                local alp = math.Clamp( ( but.N_Click-SysTime() )/0.3, 0, 1 )
                local cc = ( IsValid( but.P_Out ) and !but.P_Out.B_Close )
                local col1 = ( cc and Color( 96, 96, 216 ) or Color( 125, 125, 125 ) )
                local col2 = ( cc and Color( 64, 64, 192 ) or Color( 100, 100, 100 ) )
                surface.SetDrawColor( col1 ) surface.DrawRect( 0, 0, w, h )
                surface.SetDrawColor( col2 ) surface.DrawRect( 0, h/2, w, h/2 )
                surface.SetDrawColor( 255, 255, 255, alp*255 ) surface.DrawRect( 0, 0, w, h )
                surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
                surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 0, 0, w, h )
                draw.TextShadow( {
                    text = language.GetPhrase( txt ),
                    pos = { 8, h/2 },
                    font = "xdeshe_Font5",
                    xalign = TEXT_ALIGN_LEFT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255 -alp*255, 255 -alp*255, 255 -alp*255 )
                }, 1, 255 )
                draw.TextShadow( {
                    text = language.GetPhrase( tab[ but.N_Select ] ),
                    pos = { w -8, h/2 },
                    font = "xdeshe_Font5",
                    xalign = TEXT_ALIGN_RIGHT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255 -alp*255, 255 -alp*255, 255 -alp*255 )
                }, 1, 255 )
            end
            function but:OnCursorEntered()
                but.B_Hover = true
                xdeshe_mark = but.S_Tag
                xdeshe_mtype = "xdesc"
            end
            function but:OnCursorExited()
                but.B_Hover = false
                if xdeshe_mark == but.S_Tag then
                    xdeshe_mark = nil
                    xdeshe_mtype = nil
                end
            end
            function but:DoClick()
                if pan.N_Cool > SysTime() or but.N_Click > SysTime() then return end
                surface.PlaySound( "ui/buttonrollover.wav" )
                pan.N_Cool = SysTime() +0.2
                but.N_Click = SysTime() +0.2
                if IsValid( pan.P_Sub ) then
                    if but.P_Out and but.P_Out == pan.P_Sub then
                        pan.P_Sub.B_Close = true
                        pan.P_Sub:SizeTo( w, 30, 0.2 )
                        pan.P_Sub:AlphaTo( 1, 0.2 )
                        timer.Simple( 0.2, function()
                            if IsValid( pan ) and pan.P_Sub and pan.P_Sub.B_Close then
                                pan.P_Sub:Remove()
                            end
                        end )
                        return
                    else
                        pan.P_Sub:Remove()
                    end
                end
                local x1, y1 = pax:GetPos()
                local x2, y2 = pan.P_Center:GetPos()
                local x3, y3 = but:GetPos()
                local x4, y4 = pan:GetPos()
                local sub = vgui.Create( "DFrame" )
                sub:SetSize( w, 33 )
                sub:SizeTo( w, 30*#tab +3, 0.2 )
                sub:SetPos( x1 +x2 +x3 +x4, y1 +y2 +y3 +y4 )
                sub:SetAlpha( 1 )
                sub:AlphaTo( 255, 0.2 )
                sub:MoveTo( x1 +x2 +x3 +x4, y1 +y2 +y3 +y4 +30, 0.2 )
                sub:SetDraggable( false )
                sub:ShowCloseButton( false )
                sub:MakePopup()
                sub.N_Id = 0
                sub.B_Close = false
                sub.S_Tag = tag
                function sub:Paint( w, h )
                    draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
                    surface.SetDrawColor( 150, 150, 150 ) surface.DrawOutlinedRect( 0, 0, w, h )
                    surface.DrawRect( 0, h -2, w, 2 )
                end
                but.P_Out = sub
                pan.P_Sub = sub
                for i=1, #tab do
                    if !sub then break end
                    local sss = sub:Add( "DButton" )
                    sss:SetText( "" )
                    sss:SetSize( w -4, 30 )
                    sss:SetPos( 2, ( i-1 )*30 )
                    sss.N_Id = i
                    sss.B_Hover = false
                    function sss:Paint( w, h )
                        local bb = ( sss.B_Hover )
                        draw.RoundedBox( 0, 0, 0, w, h, bb and Color( 55, 55, 55 ) or Color( 255, 255, 255 ) )
                        draw.Text( {
                            text = tab[ i ],
                            pos = { w/2, h/2 },
                            font = "xdeshe_Font2",
                            xalign = TEXT_ALIGN_CENTER,
                            yalign = TEXT_ALIGN_CENTER,
                            color = bb and Color( 255, 255, 0 ) or Color( 0, 0, 0 )
                        } )
                    end
                    function sss:OnCursorEntered() sss.B_Hover = true end
                    function sss:OnCursorExited() sss.B_Hover = false end
                    function sss:DoClick()
                        if !sss.B_Hover or sub.B_Close then return end
                        surface.PlaySound( "ui/buttonclickrelease.wav" )
                        but.N_Select = sss.N_Id
                        pan.P_Sub:Remove()
                        RunConsoleCommand( con, sss.N_Id )
                    end
                end
            end
            return but
        end
        local function CreateAInfo( pax, txt, mat ) --信息框
            lr = !lr
            local inf = pax:Add( "DPanel" )
            inf:SetSize( 0, 138 )
            inf:Dock( TOP )
            inf.S_Txt = language.GetPhrase( txt ) or "???"
            inf.B_LR = lr
            function inf:Paint( w, h )
                local xx, yy = ( inf.B_LR and 146 or 12 ), 12
                local mark = markup.Parse( "<color=255,255,255,255><font=xdeshe_Font4>"..( inf.S_Txt ).."</color></font>", 424 )
                surface.SetDrawColor( 55, 55, 55 )
                surface.DrawRect( xx -8, yy -8, 424 +16, 112 +16 )
                surface.SetDrawColor( 128, 128, 128 )
                surface.DrawOutlinedRect( xx -8, yy -8, 424 +16, 112 +16, 2 )
                surface.SetDrawColor( 192, 192, 192 )
                surface.DrawOutlinedRect( xx -8, yy -8, 424 +16, 112 +16 )
                mark:Draw( xx, yy, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
            end
            inf.P_Back = inf:Add( "DPanel" )
            inf.P_Back:SetPos( !inf.B_LR and 450 or 4, 4 )
            inf.P_Back:SetSize( 128, 128 )
            function inf.P_Back:Paint( w, h )
                draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
                surface.SetDrawColor( 150, 150, 150 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
                surface.SetDrawColor( 200, 200, 200 ) surface.DrawOutlinedRect( 0, 0, w, h )
            end
            local ico = inf.P_Back:Add( "DPanel" )
            ico:SetPos( 2, 2 )
            ico:SetSize( 128, 128 )
            local mmm = Material( mat )
            function ico:Paint( w, h )
                if mmm then
                    surface.SetDrawColor( 255, 255, 255 )
                    surface.SetMaterial( mmm )
                    surface.DrawTexturedRect( 0, 0, w, h )
                end
            end
            if true then --画框B
                inf.P_Frame = inf:Add( "DPanel" )
                inf.P_Frame:SetPos( !inf.B_LR and 450 or 4, 4 )
                inf.P_Frame:SetSize( 128, 128 )
                function inf.P_Frame:Paint( w, h )
                    surface.SetDrawColor( 150, 150, 150 ) surface.DrawOutlinedRect( 0, 0, w, h, 4 )
                    surface.SetDrawColor( 200, 200, 200 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
                end
            end
            return inf
        end
        function pan:OnRemove() if pan.P_Sub then pan.P_Sub:Remove() end end
        function pan:Paint( w, h )
            surface.SetDrawColor( 200, 200, 200 ) surface.DrawRect( 0, 0, w, h )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawRect( 0, 0, w, 40 )
            surface.SetMaterial( xdesc.mat1 ) surface.SetDrawColor( 255, 255, 255, 55 ) surface.DrawTexturedRect( 0, 0, w, 40 )
            surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 0, 0, w, h )
            surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 8, 88, 584, 286, 2 )
            surface.SetDrawColor( 255, 255, 255 ) surface.DrawRect( 8, 88, 584, 286 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.sent_scenario" ),
                pos = { 12, 20 },
                font = "xdeshe_Font2",
                xalign = TEXT_ALIGN_LEFT,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
        end
        function pan:MenuClose()
            if pan.B_Close then return end pan.B_Close = true  pan:AlphaTo( 1, 0.2 )
            timer.Simple( 0.2, function() if IsValid( pan ) then pan:Hide() end end )
            pan:SetMouseInputEnabled( false ) pan:SetKeyboardInputEnabled( false )
            net.Start( "xdeshe_C2S_MenuClose" ) net.SendToServer()
            if pan.P_Sub then pan.P_Sub:Remove() end
            if xdeshe_mtype == "xdesc" then
                xdeshe_mark = nil
                xdeshe_mtype = nil
            end
        end
        if true then -- 关闭按钮
            pan.P_Close = pan:Add( "DButton" )  local pax = pan.P_Close
            pax:SetText( "" )
            pax:SetPos( 560, 4 )
            pax:SetSize( 32, 32 )
            pax.B_Hover = false
            function pax:Paint( w, h )
                draw.TextShadow( {
                    text = "×",
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = ( pax.B_Hover and Color( 255, 0, 0 ) or Color( 255, 255, 255 ) )
                }, 1, 255 )
            end
            function pax:DoClick()
                if pan.B_Close then return end
                surface.PlaySound( "ui/buttonclick.wav" )
                pan:MenuClose()
            end
            function pax:OnCursorEntered() pax.B_Hover = true end
            function pax:OnCursorExited() pax.B_Hover = false end
        end
        for i=1, 2 do --切换按钮
            local but = pan:Add( "DButton" )
            but:SetSize( 294, 30 )
            but:SetPos( 300 -580 +i*292 -5, 50 )
            but:SetText( "" )
            but.B_Hover = false
            but.N_Lerp = 0
            but.N_Click = 0
            function but:Paint( w, h )
                but.N_Lerp = Lerp( 0.1, but.N_Lerp, ( but.B_Hover or pan.N_Select == i ) and 0 or 1 )
                local ler = but.N_Lerp
                local col = Color( 255, 255, 255 )
                local alp = math.Clamp( ( but.N_Click-SysTime() )/0.3, 0, 1 )
                local bb = ( i == 1 )
                draw.RoundedBoxEx( 8, 0, 0, w, h, Color( 192, 192, 192 ), bb, !bb, bb, !bb )
                draw.RoundedBoxEx( 8, 1, 1, w -2, h -2, Color( 255 -ler*155, 255 -ler*155, 255 -ler*155 ), bb, !bb, bb, !bb )
                draw.RoundedBoxEx( 8, 1, 1, w -2, ( h -2 )/2, Color( 200 -ler*55, 200 -ler*55, 200 -ler*55, 55 ), bb, !bb, false, false )
                draw.RoundedBoxEx( 8, 1, 1, w -2, h -2, Color( 0, 0, 0, alp*155 ), bb, !bb, bb, !bb )
                draw.Text( {
                    text = language.GetPhrase( "xdeshe."..( i == 1 and "Configs" or "Guide" ) ),
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font4",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( ler*255, ler*255, ler*255 )
                } )
            end
            function but:OnCursorEntered() but.B_Hover = true end
            function but:OnCursorExited() but.B_Hover = false end
            if i == 1 then pan.P_B1 = but else pan.P_B2 = but end
            function but:DoClick()
                if pan.N_Cool > SysTime() or pan.N_Select == i then return end
                surface.PlaySound( "ui/buttonclick.wav" )
                pan.N_Cool = SysTime() +0.2
                but.N_Click = SysTime() +0.4
                if i == 2 then
                    pan.P_P1:SetPos( 0, 0 )
                    pan.P_P2:SetPos( 584, 0 )
                    pan.P_P1:MoveTo( -584, 0, 0.4 )
                    pan.P_P2:MoveTo( 0, 0, 0.4 )
                else
                    pan.P_P1:SetPos( -584, 0 )
                    pan.P_P2:SetPos( 0, 0 )
                    pan.P_P1:MoveTo( 0, 0, 0.4 )
                    pan.P_P2:MoveTo( 584, 0, 0.4 )
                end
                pan.N_Select = i
            end
        end
        if true then --中心面板
            pan.P_Center = pan:Add( "DPanel" )  local pax = pan.P_Center
            pax:SetPos( 9, 89 ) pax:SetSize( 582, 286 )
            function pax:Paint( w, h ) end
        end
        for i=1, 2 do --左右面板
            local pax = pan.P_Center:Add( "DScrollPanel" )
            pax:SetPos( i == 1 and 0 or 582, 0 ) pax:SetSize( 582, 286 )
            local vba = pax:GetVBar()  vba:SetHideButtons( true ) vba:SetSize( 0, 0 )
            if i == 1 then pan.P_P1 = pax
                function pax:Paint( w, h )
                    draw.RoundedBox( 0, 206, 4, 372, 30, Color( 55, 55, 55 ) )
                    surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 206, 4, 372, 30, 2 )
                    surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 206, 4, 372, 30 )
                    draw.RoundedBox( 0, 206, 39, 372, 108, Color( 55, 55, 55 ) )
                    surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 206, 39, 372, 108, 2 )
                    surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 206, 39, 372, 108 )
                    local et = math.Clamp( GetConVar( "xdesc_enemy" ):GetInt(), 1, 6 )
                    local alp = 1 -math.Clamp( ( pan.N_Change-SysTime() )/0.3, 0, 1 )
                    draw.Text( {
                        text = language.GetPhrase( "xdeshe.SC_EType" ).."  -  "..language.GetPhrase( xdesc.dts[ 7 ][ et ] ),
                        pos = { 212, 19 },
                        font = "xdeshe_Font4",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER, 
                        color = Color( 255, 255, 255, alp*255 )
                    } )
                    local det = ""  if xdesc.dts[ 7 ][ et ] then
                        det = language.GetPhrase( ( xdesc.dts[ 7 ][ et ] ).."I" )
                    end
                    local mark = markup.Parse( "<color=255,255,255,255><font=xdeshe_Font4>"..det.."</color></font>", 372 )
                    mark:Draw( 212, 47, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, alp*255 )
                end
                local b1 = CreateAButton( pax, "<", 4, 4, 24, 144 )
                local b2 = CreateAButton( pax, ">", 32 +144, 4, 24, 144 )
                function b2:DoClick2()
                    local et = math.Clamp( GetConVar( "xdesc_enemy" ):GetInt(), 1, 6 )
                    local e2 = ( et <= 1 and 6 or et -1 )
                    RunConsoleCommand( "xdesc_enemy", e2 )
                    pan.P_I1:SetPos( 0, 2 )
                    pan.P_I2:SetPos( 0 +144, 2 )
                    pan.P_I1.N_Ico = et
                    pan.P_I1:MoveTo( 0 -144, 2, 0.2 )
                    pan.P_I2:MoveTo( 0, 2, 0.2 )
                    pan.P_I2.N_Ico = e2
                    pan.N_Change = SysTime() +0.3
                end
                function b1:DoClick2()
                    local et = math.Clamp( GetConVar( "xdesc_enemy" ):GetInt(), 1, 6 )
                    local e2 = ( et >= 6 and 1 or et +1 )
                    RunConsoleCommand( "xdesc_enemy", e2 )
                    pan.P_I1:SetPos( 0, 2 )
                    pan.P_I2:SetPos( 0 -144, 2 )
                    pan.P_I1.N_Ico = et
                    pan.P_I1:MoveTo( 0 +144, 2, 0.2 )
                    pan.P_I2:MoveTo( 0, 2, 0.2 )
                    pan.P_I2.N_Ico = e2
                    pan.N_Change = SysTime() +0.3
                end
                if true then --画框A
                    pax.P_Back = pax:Add( "DPanel" )
                    pax.P_Back:SetPos( 30, 4 )
                    pax.P_Back:SetSize( 144, 144 )
                    function pax.P_Back:Paint( w, h )
                        draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
                        surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
                        surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 0, 0, w, h )
                    end
                end
                for i=1, 2 do --画像
                    local ico = pax.P_Back:Add( "DPanel" )
                    ico:SetPos( ( i-1 )*144, 2 )
                    ico:SetSize( 144, 144 )
                    ico.N_Ico = GetConVar( "xdesc_enemy" ):GetInt()
                    function ico:Paint( w, h )
                        if xdesc.mats[ ico.N_Ico ] then
                            surface.SetDrawColor( 255, 255, 255 )
                            surface.SetMaterial( xdesc.mats[ ico.N_Ico ] )
                            surface.DrawTexturedRect( 0, 0, w, h )
                        end
                    end
                    if i == 1 then pan.P_I1 = ico else pan.P_I2 = ico end
                end
                if true then --画框B
                    pax.P_Frame = pax:Add( "DPanel" )
                    pax.P_Frame:SetPos( 30, 4 )
                    pax.P_Frame:SetSize( 144, 144 )
                    function pax.P_Frame:Paint( w, h )
                        surface.SetDrawColor( 0, 0, 0, 155 ) surface.DrawOutlinedRect( 0, 0, w, h, 8 )
                    end
                end
                if true then --开始按钮
                    local but = pax:Add( "DButton" )
                    but:SetSize( 210, 35 )
                    but:SetPos( 582/2 -210/2, 242 )
                    but:SetText( "" )
                    but.B_Hover = false
                    but.N_Click = 0
                    function but:Paint( w, h )
                        local alp = math.Clamp( ( but.N_Click-SysTime() )/0.3, 0, 1 )
                        draw.RoundedBox( 8, 0, 0, w, h, Color( 192, 192, 192 ) )
                        draw.RoundedBox( 8, 1, 1, w -2, h -2, Color( 64, 64, 192 ) )
                        draw.RoundedBoxEx( 8, 1, 1, w -2, h/2 -2, Color( 96, 96, 216 ), true, true, false, false )
                        draw.RoundedBox( 8, 1, 1, w -2, h -2, Color( 255, 255, 255, alp*255 ) )
                        draw.TextShadow( {
                            text = language.GetPhrase( "xdeshe.Start" ),
                            pos = { w/2, h/2 },
                            font = "xdeshe_Font2",
                            xalign = TEXT_ALIGN_CENTER,
                            yalign = TEXT_ALIGN_CENTER,
                            color = Color( 255 -alp*255, 255 -alp*255, 255 -alp*255 )
                        }, 1, 255 )
                    end
                    function but:OnCursorEntered() but.B_Hover = true end
                    function but:OnCursorExited() but.B_Hover = false end
                    function but:DoClick()
                        if pan.N_Cool > SysTime() or but.N_Click > SysTime() or but.B_Close then return end
                        but.N_Click = SysTime() +0.3
                        surface.PlaySound( "ui/buttonclickrelease.wav" )
                        net.Start( "xdesc_Start" )
                        net.WriteString( util.TableToJSON( {
                            GetConVar( "xdesc_waves" ):GetInt(),
                            GetConVar( "xdesc_supply" ):GetInt(),
                            GetConVar( "xdesc_gamemode" ):GetInt(),
                            GetConVar( "xdesc_difficulty" ):GetInt(),
                            GetConVar( "xdesc_movement" ):GetInt(),
                            GetConVar( "xdesc_amount" ):GetInt(),
                            GetConVar( "xdesc_enemy" ):GetInt(),
                        } ) )
                        net.SendToServer()
                        pan:MenuClose()
                    end
                end
                local s1 = CreateATab( pax, "#xdeshe.SC_C1", 4, 160, 180, 30, { "#xdeshe.SC_C11", "#xdeshe.SC_C12", "#xdeshe.SC_C13", "#xdeshe.SC_C14", "#xdeshe.SC_C15", "#xdeshe.SC_C16" }, "xdesc_waves", 1 )
                local s2 = CreateATab( pax, "#xdeshe.SC_C2", 200, 160, 180, 30, { "#xdeshe.SC_C21", "#xdeshe.SC_C22", "#xdeshe.SC_C23", "#xdeshe.SC_C24", "#xdeshe.SC_C25", "#xdeshe.SC_C26" }, "xdesc_supply", 2 )
                local s3 = CreateATab( pax, "#xdeshe.SC_C3", 398, 160, 180, 30, { "#xdeshe.SC_C31", "#xdeshe.SC_C32", "#xdeshe.SC_C33" }, "xdesc_gamemode", 3 )
                local s4 = CreateATab( pax, "#xdeshe.SC_C4", 4, 200, 180, 30, { "#xdeshe.SC_C41", "#xdeshe.SC_C42", "#xdeshe.SC_C43", "#xdeshe.SC_C44" }, "xdesc_difficulty", 4 )
                local s5 = CreateATab( pax, "#xdeshe.SC_C5", 200, 200, 180, 30, { "#xdeshe.SC_C51", "#xdeshe.SC_C52", "#xdeshe.SC_C53", "#xdeshe.SC_C54" }, "xdesc_movement", 5 )
                local s6 = CreateATab( pax, "#xdeshe.SC_C6", 398, 200, 180, 30, { "#xdeshe.SC_C61", "#xdeshe.SC_C62", "#xdeshe.SC_C63", "#xdeshe.SC_C64", "#xdeshe.SC_C65" }, "xdesc_amount", 6 )
            else --折不起来了他妈的
                pan.P_P2 = pax
                function pax:Paint( w, h ) end
                CreateAInfo( pax, "#xdeshe.SC_H1", "xdeedited/sc_random.png" )
                CreateAInfo( pax, "#xdeshe.SC_H2", "xdeedited/sc_info1.png" )
                CreateAInfo( pax, "#xdeshe.SC_H3", "entities/xdesc_spawner.png" )
                CreateAInfo( pax, "#xdeshe.SC_H4", "entities/sent_she_supply.png" )
                CreateAInfo( pax, "#xdeshe.SC_H5", "entities/xdesc_bot.png" )
            end
        end
        return pan
    end )
	xdeshe_MenuRegister( "xdesc2", function( id, ent, dat ) --存活HUD
        if IsValid( xdeshe_vguis[ id ] ) then xdeshe_vguis[ id ]:Remove() end
		local pan = vgui.Create( "DFrame" )  local ply = LocalPlayer()
		pan:SetKeyboardInputEnabled( false ) pan:SetMouseInputEnabled( false )
		pan:SetTitle( "" ) pan:SetDraggable( false )
		pan:ShowCloseButton( false )
		pan:SetSize( 600, 120, 1 ) pan:SetPos( ScrW()/2 -300, 8 )
		pan:SetAlpha( 1 ) pan:AlphaTo( 255, 1 )
		pan:SetDeleteOnClose( true )
        pan.N_TTimer = 0
		pan.N_Start = CurTime() +1
        pan.N_Nums = { 2, 45, 0, 0, 0, 0, 0, 0, 0 } --状态，计时，波数，最大波，玩家，敌人，补给
        pan.S_Snd = nil  pan.S_Sn2 = nil
		local Ma2, Ma3 = xdeshe_OnceMat( "vgui/hud/survivaltimerclock" ), xdeshe_OnceMat( "vgui/hud/survivaltimerclockface" )
        function pan:OnRemove()
            if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
            if pan.S_Sn2 then pan.S_Sn2:Stop() pan.S_Sn2 = nil end
            if pan.P_IF then pan.P_IF:Remove() end
        end
        function pan:Think()
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) then
                if pan.N_Start <= CurTime() then pan:Remove() end
                return
            end
            pan.N_Nums[ 1 ] = ent:GetXDE_State()  pan.N_Nums[ 2 ] = ent:GetXDE_Timer()
            pan.N_Nums[ 3 ] = ent:GetXDE_Wave()  pan.N_Nums[ 4 ] = ent:GetXDE_MWave()
            pan.N_Nums[ 5 ] = ent:GetXDE_Player()  pan.N_Nums[ 6 ] = ent:GetXDE_Enemy()
            pan.N_Nums[ 7 ] = ent:GetXDE_Supply()  pan.N_Nums[ 8 ] = ent:GetXDE_BossHP()
            pan.N_Nums[ 9 ] = ent:GetXDE_Gamemode()
        end
        function pan:MenuClose() pan:Remove() if xdesc.uilobby then xdesc.uilobby:Remove() end end
		function pan:Paint( w, h )
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) or !ply:Alive() or GetConVar( "cl_drawhud" ):GetInt() < 1 then
                return
            end
			surface.SetDrawColor( 0, 0, 0, 192 )
			surface.DrawOutlinedRect( 0, 0, 400, h, 6 ) surface.DrawRect( 8, 8, 400 -16, h -16 )
			surface.DrawOutlinedRect( 405, 0, 186, h, 6 ) surface.DrawRect( 405 +8, 8, 186 -16, h -16 )
			surface.SetDrawColor( 255, 255, 255, 192 )
			surface.DrawOutlinedRect( 0, 0, 400, h ) surface.DrawOutlinedRect( 405, 0, 186, h )
            local per, tim, sta = 0, pan.N_Nums[ 2 ], pan.N_Nums[ 1 ]
            if pan.N_Nums[ 9 ] == 1 or sta == 2 then
                tim = math.max( 0, pan.N_Nums[ 2 ] -CurTime() )
                per = math.Clamp( tim/( sta == 2 and 45 or 120 ), 0, 1 )
            elseif pan.N_Nums[ 9 ] == 2 then
                tim = math.max( 0, pan.N_Nums[ 2 ] )
                per = math.Clamp( tim/50, 0, 1 )
            elseif pan.N_Nums[ 9 ] == 3 then
                if pan.N_Nums[ 4 ] == -1 then tim = CurTime() -tim else
                    tim = math.max( 0, pan.N_Nums[ 4 ]*90 -( CurTime() -tim ) )
                end
                per = pan.N_Nums[ 4 ] == -1 and -1 or ( math.Clamp( tim/( pan.N_Nums[ 4 ]*90 ), 0, 1 ) )
            end
            local mii = math.floor( tim/60 )  local sec = ( tim -mii*60 )  local mmm = math.floor( sec )  local xxx = math.floor( ( sec -mmm )*100 )
            if sta == 2 and pan.N_TTimer != mmm then pan.N_TTimer = mmm
                if mii <= 0 and pan.N_TTimer <= 10 and pan.N_Nums[ 8 ] <= 0 and pan.N_Nums[ 1 ] == 2 and ( pan.N_Nums[ 3 ] +1 )%6 != 0 then
                    surface.PlaySound( "buttons/arena_switch_press_02.wav" )
                end
                if mii <= 0 and pan.N_TTimer == 29 and pan.N_Nums[ 1 ] == 2 then
                    if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                    sound.PlayFile( "sound/zombie/cso2_zombie_roundstart.mp3", "noplay", function( station, errCode, errStr )
                        if IsValid( station ) then
                            if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                            station:Play() station:SetVolume( 0.75 ) pan.S_Snd = station
                        end
                    end )
                end
                if mii <= 0 and pan.N_TTimer == 10 and pan.N_Nums[ 1 ] == 2 and ( pan.N_Nums[ 3 ] +1 )%6 == 0 then
                    if pan.S_Sn2 then pan.S_Sn2:Stop() end
                    pan.S_Sn2 = CreateSound( Entity( 0 ), "zombie/game_start_warning.wav" )  pan.S_Sn2:SetSoundLevel( 0 )
                    pan.S_Sn2:Play() pan.S_Sn2:ChangeVolume( 0.75 )
                end
                if mii <= 0 and pan.N_TTimer == 2 then
                    if pan.S_Sn2 then pan.S_Sn2:ChangeVolume( 0, 3 ) end
                end
            end local cc, c2 = Color( 255, 255, 255 ), Color( 255, 255, 255 )
            if per != -1 then
                cc = per <= 0.5 and ( per > 0.2 and Color( 255, 255, math.abs( math.sin( SysTime()*2 ) )*255 )
                or Color( 255, math.abs( math.sin( SysTime()*4 ) )*255, math.abs( math.sin( SysTime()*4 ) )*255 ) ) or Color( 255, 255, 255 )
                c2 = per <= 0.5 and ( per > 0.2 and Color( 255, 255, 0 ) or Color( 255, 0, 0 ) ) or Color( 255, 255, 255 )
                surface.SetMaterial( Ma2 ) surface.SetDrawColor( 255, 255, 255 ) surface.DrawTexturedRect( -8, h/2 -56, 128, 128 )
                if pan.N_Nums[ 8 ] > 0 then cc, c2, per = Color( 255, 0, 255 ), Color( 255, 0, 255 ), pan.N_Nums[ 8 ] end
                surface.SetMaterial( Ma3 ) surface.SetDrawColor( c2 ) xdeshe_Circle( -8 +64, h/2 +8, 64, 100, per )
            end
            local w1, w2 = "", ""
            if pan.N_Nums[ 9 ] == 3 then w2 = ( language.GetPhrase( "xdeshe."..( pan.N_Nums[ 1 ] == 2 and "Prepare" or "Survive" ) ).." " ) else
                w1 = ( pan.N_Nums[ 1 ] == 2 and pan.N_Nums[ 3 ] +1 or pan.N_Nums[ 3 ] )..( pan.N_Nums[ 4 ] <= 0 and "" or " / "..pan.N_Nums[ 4 ] )
                w2 = ( language.GetPhrase( "xdeshe."..( pan.N_Nums[ 1 ] == 2 and "Prepare" or "Wave" ) ).." " )
            end
            draw.TextShadow( {
				text = w2..w1,
				pos = { w/2 -72, 32 },
				font = "xdeshe_Font3",
				xalign = TEXT_ALIGN_CENTER,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( 255, 255, 255, 255 )
			}, 1, 255 )
            local gmm = ent:GetXDE_Gamemode()
            local fin = ( gmm == 1 and ent:GetXDE_Timer() <= CurTime() ) or ( gmm == 2 and ent:GetXDE_Timer() <= 0 )
            or ( gmm == 3 and ent:GetXDE_MWave() != -1 and ( CurTime() -ent:GetXDE_Timer() ) >= ent:GetXDE_MWave()*90 )
            if pan.N_Nums[ 8 ] > 0 then
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Boss" )..":",
                    pos = { w/2 -72, 64 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = cc
                }, 1, 255 )
                draw.TextShadow( {
                    text = math.Round( pan.N_Nums[ 8 ]*100, 1 ).."%",
                    pos = { w/2 -72, 88 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = cc
                }, 1, 255 )
            elseif fin and pan.N_Nums[ 1 ] == 3 and pan.N_Nums[ 6 ] > 0 then
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Defeat1" ),
                    pos = { w/2 -72, 64 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = cc
                }, 1, 255 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Defeat2" ),
                    pos = { w/2 -72, 88 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = cc
                }, 1, 255 )
            else
                if pan.N_Nums[ 9 ] == 1 or pan.N_Nums[ 9 ] == 3 or sta == 2 then
                    local mii = math.floor( tim/60 )  local sec = ( tim -mii*60 )  local mmm = math.floor( sec )  local xxx = math.floor( ( sec -mmm )*100 )
                    draw.TextShadow( {
                        text = xdeshe_SNum( mii )..":"..xdeshe_SNum( mmm )..":"..xdeshe_SNum( xxx ),
                        pos = { w/2 -72, 80 },
                        font = "xdeshe_Font10",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = cc
                    }, 1, 255 )
                elseif pan.N_Nums[ 9 ] == 2 then
                    draw.TextShadow( {
                        text = tim.." / 50",
                        pos = { w/2 -72, 80 },
                        font = "xdeshe_Font10",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = cc
                    }, 1, 255 )
                end
            end
			draw.TextShadow( {
				text = language.GetPhrase( "xdeshe.SC_Begin3" )..": "..pan.N_Nums[ 5 ],
				pos = { w/2 +120, 32 -4 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_LEFT,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( 255, 255, 255, 255 )
			}, 1, 255 )
			draw.TextShadow( {
				text = language.GetPhrase( "xdeshe.SC_Begin4" )..": "..pan.N_Nums[ 6 ],
				pos = { w/2 +120, 64 -4 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_LEFT,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( 255, 255, 255, 255 )
			}, 1, 255 )
			draw.TextShadow( {
				text = language.GetPhrase( "xdeshe.SC_Begin5" )..": "..pan.N_Nums[ 7 ],
				pos = { w/2 +120, 96 -4 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_LEFT,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( 255, 255, 255, 255 )
			}, 1, 255 )
		end
        function pan:ReceiveNotify( tab ) --先写的vsmg后写的这个
            local nam = tab[ 1 ]
            if nam == "wavestart" then
                if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                if pan.P_IF then pan.P_IF:Remove() end
                pan.P_IF = vgui.Create( "DPanel" )  local pax = pan.P_IF
                pax:SetPos( ScrW()/2 -300, ScrH()*0.25 ) pax:MoveTo( ScrW()/2 -275, ScrH()*0.25 -48, 0.5 )
                pax:MoveTo( ScrW()/2, ScrH()*0.25 -48, 1, 3 )
                pax:SetSize( 600, 0 ) pax:SizeTo( 550, 96, 0.5 ) pax:SizeTo( 0, 96, 1, 3 )
                pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
                pax:SetAlpha( 255 ) pax:AlphaTo( 0, 1, 3 )
                local tas = { "#xdeshe.SC_Mode1", "#xdeshe.SC_Mode2", "#xdeshe.SC_Mode3" }
                local str = ( tab[ 2 ]%6 == 0 and "#xdeshe.BossWave" or tas[ tab[ 4 ] ] )
                local ccc = ( tab[ 2 ]%6 == 0 and Color( 255, 0, 255 ) or ( tab[ 2 ]%3 == 0 and Color( 255, 255, 0 ) or Color( 255, 255, 255 ) ) )
                if tab[ 3 ] and tab[ 3 ] != "" then str = language.GetPhrase( "xdeshe.Special" )..": "..tab[ 3 ] end
                function pax:Paint( w, h )
                    draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0, 192 ) )
                    draw.TextShadow( {
                        text = language.GetPhrase( "xdeshe.Wave" ).." "..tab[ 2 ].." "..language.GetPhrase( "xdeshe.Started" ),
                        pos = { w/2, 28 },
                        font = "xdeshe_Font3",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = language.GetPhrase( str ),
                        pos = { w/2, 68 },
                        font = "xdeshe_Font3",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = ccc
                    }, 1, 255 )
                end
                surface.PlaySound( "ui/critical_event_1.wav" )
                local ent = GetGlobal2Entity( "XDESC" )
                if IsValid( ent ) and istable( ent.PlayerJoin ) then
                    for k, v in pairs( ent.PlayerJoin ) do
                        if IsValid( v ) then v.XDESC_P = nil end
                    end
                end
                if IsValid( xdesc.uilobby ) then xdesc.uilobby.B_Finish = true end
            elseif nam == "waveend" then
                if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                if pan.P_IF then pan.P_IF:Remove() end
                pan.P_IF = vgui.Create( "DPanel" )  local pax = pan.P_IF
                pax:SetPos( ScrW()/2 -350, ScrH()*0.25 ) pax:MoveTo( ScrW()/2 -300, ScrH()*0.25 -72, 0.5 )
                pax:MoveTo( ScrW()/2, ScrH()*0.25 -72, 1, 3 )
                pax:SetSize( 700, 0 ) pax:SizeTo( 600, 72, 0.5 ) pax:SizeTo( 0, 72, 1, 3 )
                pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
                pax:SetAlpha( 255 ) pax:AlphaTo( 0, 1, 3 )
                function pax:Paint( w, h )
                    draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0, 192 ) )
                    draw.TextShadow( {
                        text = language.GetPhrase( "xdeshe.Wave" ).." "..tab[ 2 ].." "..language.GetPhrase( "xdeshe.Complete" ),
                        pos = { w/2, h/2 },
                        font = "xdeshe_Font10",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255, 255 )
                    }, 1, 255 )
                end
                surface.PlaySound( "ui/spot_mission_end.wav" )
            elseif nam == "victory" then
                if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                if pan.P_IF then pan.P_IF:Remove() end if pan.P_IX then pan.P_IX:Remove() end
                pan.P_IX = vgui.Create( "DPanel" )  local pax = pan.P_IX
                pax:SetPos( ScrW()/2 -384, ScrH()/2 -100 -64 )
                pax:MoveTo( ScrW()/2 -384, ScrH()/2 -100, 1, 4 )
                pax:SetSize( 768, 128 ) pax:SizeTo( 768, 200, 0.5 )
                pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
                pax:SetAlpha( 1 ) pax:AlphaTo( 255, 1 ) pax:AlphaTo( 0, 1, 4 )
                pax.N_Lerp = SysTime() +1
                function pax:Paint( w, h )
                    draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0, 192 ) )
                    local ler = 1 -math.Clamp( pax.N_Lerp -SysTime(), 0, 1 )
                    draw.TextShadow( {
                        text = language.GetPhrase( "xdeshe.SC_Complete1" ),
                        pos = { w/2, h/2 -32 },
                        font = "xdeshe_Font9",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255*( 1-ler ) )
                    }, 1, 255*ler )
                    draw.TextShadow( {
                        text = language.GetPhrase( "xdeshe.SC_Complete2" ).." "..tab[ 2 ].." "..language.GetPhrase( "xdeshe.SC_Complete3" ),
                        pos = { w/2, h/2 +32 },
                        font = "xdeshe_Font10",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255*( 1-ler ) )
                    }, 1, 255*ler )
                end
                surface.PlaySound( "music/bgm_roundwin.mp3" )
                timer.Simple( 11, function() if IsValid( pax ) then pax:Remove() end end )
            elseif nam == "defeat" then
                if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                if pan.P_IF then pan.P_IF:Remove() end if pan.P_IX then pan.P_IX:Remove() end
                pan.P_IX = vgui.Create( "DPanel" )  local pax = pan.P_IX
                pax:SetPos( ScrW()/2 -384, ScrH()/2 -100 -64 )
                pax:MoveTo( ScrW()/2 -384, ScrH()/2 -100, 1, 4 )
                pax:SetSize( 768, 128 ) pax:SizeTo( 768, 200, 0.5 )
                pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
                pax:SetAlpha( 1 ) pax:AlphaTo( 255, 1 ) pax:AlphaTo( 0, 1, 4 )
                pax.N_Lerp = SysTime() +1
                function pax:Paint( w, h )
                    draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0, 192 ) )
                    local ler = 1 -math.Clamp( pax.N_Lerp -SysTime(), 0, 1 )
                    draw.TextShadow( {
                        text = language.GetPhrase( "xdeshe.SC_Complete4" ),
                        pos = { w/2, h/2 -32 },
                        font = "xdeshe_Font9",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255*( 1-ler ), 255*( 1-ler ) )
                    }, 1, 255*ler )
                    draw.TextShadow( {
                        text = language.GetPhrase( "xdeshe.SC_Complete2" ).." "..tab[ 2 ].." "..language.GetPhrase( "xdeshe.SC_Complete3" ),
                        pos = { w/2, h/2 +32 },
                        font = "xdeshe_Font10",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255*( 1-ler ), 255*( 1-ler ) )
                    }, 1, 255*ler )
                end
                surface.PlaySound( "music/bgm_roundlose.mp3" )
                timer.Simple( 11, function() if IsValid( pax ) then pax:Remove() end end )
            elseif nam == "plydead" then
                if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                if IsValid( pan.P_IP ) then pan.P_IP:Remove() end local las = tab[ 2 ]
                sound.PlayFile( !las and "sound/zombie/zcity/zcity_lastman_ui.wav" or "sound/zombie/zcity/zcity_killmessage_ui.wav", "noplay", function( station, errCode, errStr )
                    if IsValid( pan ) and IsValid( station ) then
                        if pan.S_Snd then pan.S_Snd:Stop() pan.S_Snd = nil end
                        station:Play() station:SetVolume( 0.5 ) pan.S_Snd = station
                    end
                end )
                pan.P_IP = vgui.Create( "DPanel" )  local pax = pan.P_IP
                pax:SetSize( 600, 130, 1 ) pax:SetPos( ScrW()/2 -300, 110 )
                pax:MoveTo( ScrW()/2 -300, 130, 1, 4 )
                pax:SetKeyboardInputEnabled( false ) pax:SetMouseInputEnabled( false )
                pax:SetAlpha( 1 ) pax:AlphaTo( 255, 0.5 ) pax:AlphaTo( 0, 1, 4 )
                pax.N_Shake = SysTime() +0.5
                function pax:Paint( w, h )
                    if !IsValid( pan ) then return end
                    local ler = math.Clamp( ( pax.N_Shake -SysTime() )/0.5, 0, 1 )
                    draw.TextShadow( {
                        text = las and las.." "..language.GetPhrase( "xdeshe.SC_Slain1" ) or language.GetPhrase( "xdeshe.SC_Slain2" ),
                        pos = { w/2 +math.Rand( -ler, ler )*10, h/2 +math.Rand( -ler, ler )*10 },
                        font = "xdeshe_Font3",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = las and Color( 255, 165 +90*ler, 255*ler ) or Color( 220 +35*ler, 20 +235*ler, 60 +195*ler )
                    }, 1, 255 )
                end
                timer.Create( "xdesc_plydeadui", 5, 1, function()
                    if IsValid( pax ) then pax:Remove() end
                end )
            end
        end
		return pan
	end )
	xdeshe_MenuRegister( "xdesc3", function( id, ent, dat ) --死亡HUD
		local pan = vgui.Create( "DFrame" )  local ply = LocalPlayer()
        xdesc.campos = ply:EyePos()  xdesc.camang = ply:EyeAngles()  xdesc.cament = nil
		pan:SetKeyboardInputEnabled( false ) pan:SetMouseInputEnabled( false )
		pan:SetTitle( "" ) pan:SetDraggable( false ) pan:ShowCloseButton( false )
		pan:SetSize( ScrW(), ScrH() ) pan:SetPos( 0, 0 )
		pan:SetAlpha( 1 ) pan:AlphaTo( 255, 1 )
		pan:SetDeleteOnClose( true ) xdesc.camdel = CurTime() +1
		pan.N_Lerp = SysTime() +1  pan.N_Updater = CurTime() +0.1  pan.N_Start = CurTime() +1
        pan.N_Nums = { 2, 45, 0, 0, 0, 0, 0 }
        function pan:Think()
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) or ent:GetXDE_State() <= 2 or ply:Alive() or !ply:GetNWBool( "XDESC" ) then
                if pan.N_Start <= CurTime() then pan:Remove() end
                return
            end
            if pan.N_Updater <= CurTime() then pan.N_Updater = CurTime() +0.1
                local xx, yy, zz = math.Round( xdesc.campos.x ), math.Round( xdesc.campos.y ), math.Round( xdesc.campos.z )
                net.Start( "xdesc_Cam" ) net.WriteString( xx.." "..yy.." "..zz ) net.SendToServer()
            end
            pan.N_Nums[ 1 ] = ent:GetXDE_State()  pan.N_Nums[ 2 ] = ent:GetXDE_Timer()
            pan.N_Nums[ 3 ] = ent:GetXDE_Wave()  pan.N_Nums[ 4 ] = ent:GetXDE_MWave()
            pan.N_Nums[ 5 ] = ent:GetXDE_Player()  pan.N_Nums[ 6 ] = ent:GetXDE_Enemy()
            pan.N_Nums[ 7 ] = ent:GetXDE_Supply()  pan.N_Nums[ 8 ] = ent:GetXDE_BossHP()
            pan.N_Nums[ 9 ] = ent:GetXDE_Gamemode()
        end
        function pan:MenuClose() pan:Remove() end
        local Mat = xdeshe_OnceMat( "hud/killicons/default" )
		function pan:Paint( w, h )
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) or ent:GetXDE_State() <= 2 or ply:Alive() or !ply:GetNWBool( "XDESC" ) or GetConVar( "cl_drawhud" ):GetInt() < 1 then
                return
            end
            local ler = 1 -math.Clamp( pan.N_Lerp -SysTime(), 0, 1 )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawRect( 0, 0, w, ScrH()*0.1*ler )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawRect( 0, ScrH()*0.9 +( 1-ler )*ScrH()*0.1 +1, w, ScrH()*0.1*ler )
            surface.SetDrawColor( 255, 255, 255 ) surface.SetMaterial( Mat ) surface.DrawTexturedRect( 0, -ScrH()*0.1 +ScrH()*0.1*ler +2, 96, 96 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.SC_Slain3" ),
                pos = { 96, 36 -ScrH()*0.1 +ScrH()*0.1*ler },
                font = "xdeshe_Font10",
                xalign = TEXT_ALIGN_LEFT,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 192, 192, 192 )
            }, 1, 255 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.SC_Slain4" ),
                pos = { 102, 76 -ScrH()*0.1 +ScrH()*0.1*ler },
                font = "xdeshe_Font2",
                xalign = TEXT_ALIGN_LEFT,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 192, 0, 0 )
            }, 1, 255 )
            local w1, w2 = "", ""
            if pan.N_Nums[ 9 ] == 3 then w2 = ( language.GetPhrase( "xdeshe."..( pan.N_Nums[ 1 ] == 2 and "Prepare" or "Survive" ) ).." " ) else
                w1 = ( pan.N_Nums[ 1 ] == 2 and pan.N_Nums[ 3 ] +1 or pan.N_Nums[ 3 ] )..( pan.N_Nums[ 4 ] <= 0 and "" or " / "..pan.N_Nums[ 4 ] )
                w2 = ( language.GetPhrase( "xdeshe."..( pan.N_Nums[ 1 ] == 2 and "Prepare" or "Wave" ) ).." " )
            end
            local per, tim, sta, str = 0, pan.N_Nums[ 2 ], pan.N_Nums[ 1 ], ""
            if pan.N_Nums[ 9 ] == 1 or sta == 2 then
                tim = math.max( 0, pan.N_Nums[ 2 ] -CurTime() )
                per = math.Clamp( tim/( sta == 2 and 45 or 120 ), 0, 1 )
            elseif pan.N_Nums[ 9 ] == 2 then
                tim = math.max( 0, pan.N_Nums[ 2 ] )
                per = math.Clamp( tim/50, 0, 1 )
            elseif pan.N_Nums[ 9 ] == 3 then
                if pan.N_Nums[ 4 ] == -1 then tim = CurTime() -tim else
                    tim = math.max( 0, pan.N_Nums[ 4 ]*90 -( CurTime() -tim ) )
                end
                per = pan.N_Nums[ 4 ] == -1 and -1 or ( math.Clamp( tim/( pan.N_Nums[ 4 ]*90 ), 0, 1 ) )
            end
            if pan.N_Nums[ 9 ] == 3 or pan.N_Nums[ 9 ] == 1 then
                local mii = math.floor( tim/60 )  local sec = ( tim -mii*60 )  local mmm = math.floor( sec )  local xxx = math.floor( ( sec -mmm )*100 )
                str = xdeshe_SNum( mii )..":"..xdeshe_SNum( mmm )..":"..xdeshe_SNum( xxx )
            else str = tim.." / 50" end
            local cl1, wav = Color( 255, 255, 255 ), pan.N_Nums[ 3 ]
            if wav > 0 and wav%6 == 0 then cl1 = Color( 255, 0, 255 )
            elseif wav > 0 and wav%3 == 0 then cl1 = Color( 255, 255, 0 ) end
            local cc = per <= 0.5 and ( per > 0.2 and Color( 255, 255, math.abs( math.sin( SysTime()*2 ) )*255 )
            or Color( 255, math.abs( math.sin( SysTime()*4 ) )*255, math.abs( math.sin( SysTime()*4 ) )*255 ) ) or Color( 255, 255, 255 )
			if pan.N_Nums[ 8 ] > 0 then cc = Color( 255, 0, 255 ) end
            draw.TextShadow( {
                text = w2..w1,
                pos = { 16, 36 +ScrH()*0.9 +ScrH()*0.1*( 1-ler ) },
                font = "xdeshe_Font3",
                xalign = TEXT_ALIGN_LEFT,
                yalign = TEXT_ALIGN_CENTER,
                color = cl1
            }, 1, 255 )
            if pan.N_Nums[ 8 ] > 0 then
                draw.TextShadow( {
                    text = math.Round( pan.N_Nums[ 8 ]*100, 1 ).."%",
                    pos = { 16, 78 +ScrH()*0.9 +ScrH()*0.1*( 1-ler ) },
                    font = "xdeshe_Font3",
                    xalign = TEXT_ALIGN_LEFT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = cc
                }, 1, 255 )
            else
                draw.TextShadow( {
                    text = str,
                    pos = { 16, 78 +ScrH()*0.9 +ScrH()*0.1*( 1-ler ) },
                    font = "xdeshe_Font3",
                    xalign = TEXT_ALIGN_LEFT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = cc
                }, 1, 255 )
            end
            if IsValid( xdesc.cament ) and xdesc.cament:IsPlayer() and xdesc.camtar then
                local hp = xdesc.cament:Health() <= 0 and language.GetPhrase( "xdeshe.Dead" ) or xdesc.cament:Health()
                draw.TextShadow( {
                    text = xdesc.cament:Nick().." [ "..hp.." ]",
                    pos = { ScrW()/2, 52 +ScrH()*0.9 +ScrH()*0.2*( 1-ler ) },
                    font = "xdeshe_Font3",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = xdesc.cament:Health() <= 0 and Color( 255, 0, 0 ) or Color( 255, 255, 255 )
                }, 1, 255 )
            end
        end
        return pan
    end )
    xdeshe_MenuRegister( "xdesc4", function( id, ent, dat ) --结算界面
        if IsValid( xdeshe_vguis[ id ] ) then xdeshe_vguis[ id ]:Remove() end
        local pan = vgui.Create( "DFrame" )
        pan:Show()
        pan:SetSize( 600, 40 )
        pan:Center()
        pan:SetAlpha( 0 )
        pan:AlphaTo( 255, 0.5, 4 )
        pan:SizeTo( 600, 400, 0.5, 4 )
        pan:MoveTo( ScrW()/2 -300, ScrH()/2 -200, 0.5, 4 )
        pan.B_Close = false
        pan.B_Win = ( dat[1][1] >= dat[1][2] )
        timer.Simple( 4, function() if IsValid( pan ) and !pan.B_Close then pan:MakePopup() end end )
        pan:SetTitle( "" )
        pan:ShowCloseButton( false )
        pan:SetScreenLock( true )
        pan.N_Curt = CurTime()
        pan:SetDeleteOnClose( true )
        function pan:Paint( w, h )
            surface.SetDrawColor( 200, 200, 200 ) surface.DrawRect( 0, 0, w, h )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawRect( 0, 0, w, 40 )
            surface.SetMaterial( xdesc.mat1 ) surface.SetDrawColor( 255, 255, 255, 55 ) surface.DrawTexturedRect( 0, 0, w, 40 )
            surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 0, 0, w, h )
            surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 8, 88, 584, 286, 2 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe."..( pan.B_Win and "Victory" or "Defeat" ) ),
                pos = { w/2, 20 },
                font = "xdeshe_Font2",
                xalign = TEXT_ALIGN_CENTER,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
        end
        function pan:MenuClose()
            if pan.B_Close then return end pan.B_Close = true  pan:AlphaTo( 1, 0.2 )
            timer.Simple( 0.2, function() if IsValid( pan ) then pan:Hide() end end )
            pan:SetMouseInputEnabled( false ) pan:SetKeyboardInputEnabled( false )
        end
        if true then -- 关闭按钮
            pan.P_Close = pan:Add( "DButton" )  local pax = pan.P_Close
            pax:SetText( "" )
            pax:SetPos( 560, 4 )
            pax:SetSize( 32, 32 )
            pax.B_Hover = false
            function pax:Paint( w, h )
                draw.TextShadow( {
                    text = "×",
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = ( pax.B_Hover and Color( 255, 0, 0 ) or Color( 255, 255, 255 ) )
                }, 1, 255 )
            end
            function pax:DoClick()
                if pan.B_Close then return end
                surface.PlaySound( "ui/buttonclick.wav" )
                pan:MenuClose()
            end
            function pax:OnCursorEntered() pax.B_Hover = true end
            function pax:OnCursorExited() pax.B_Hover = false end
        end
        if true then -- 芬兰
            local pax = pan:Add( "DPropertySheet" )
            pax:SetPos( 6, 44 )
            pax:SetSize( 588, 350 )
            pax:SetPadding( 1 )
            function pax:Paint( w, h )
                surface.SetDrawColor( 128, 128, 128 )
                surface.DrawRect( 0, 20, w, h -20 )
                surface.SetDrawColor( 0, 0, 0 )
                surface.DrawOutlinedRect( 0, 20, w, h -20, 2 )
                surface.SetDrawColor( 255, 255, 255 )
                surface.DrawOutlinedRect( 0, 20, w, h -20, 1 )
            end
            local function AddASheetAM( tit, ico )
                local pae = vgui.Create( "DPanel" )
                pae.T_Items = {}
                function pae:Paint( w, h )
                    surface.SetDrawColor( 255, 255, 255, 100 )
                    surface.SetMaterial( xdesc.mat4 )
                    surface.DrawTexturedRectRotated( w/2, h/2, w, h, 0 )
                    surface.DrawTexturedRectRotated( w/2, h/2, w, h, 180 )
                end
                local ttt = pax:AddSheet( tit, pae, ico )
                function ttt.Tab:Paint( w, h )
                    local alp = ttt.Tab:IsActive() and 1 or 0.5
                    draw.RoundedBoxEx( 0, 0, 0, w, 20, Color( 255, 255,255 ), true, true, false, false )
                    draw.RoundedBoxEx( 0, 1, 1, w -2, 20, Color( 0, 0, 0 ), true, true, false, false )
                    draw.RoundedBoxEx( 0, 2, 2, w -4, 20, Color( 128*alp, 128*alp, 128*alp, 255 ), true, true, false, false )
                end
                pae.P_Scroll = ttt.Panel:Add( "DScrollPanel" )
                pae.P_Scroll:SetPos( 2, 2 )
                pae.P_Scroll:SetSize( 582, 324 )
                local vba = pae.P_Scroll:GetVBar()
                vba:SetHideButtons( true )
                vba:SetSize( 0, 0 )
                pae.P_Hold = pae.P_Scroll:Add( "DIconLayout" )
                pae.P_Hold:Dock( FILL )
                pae.P_Hold:SetSpaceX( 1 )
                pae.P_Hold:SetSpaceY( 1 )
                return pae
            end
            local cons = {
                { "#xdeshe.SC_C1", "#xdeshe.SC_C11", "#xdeshe.SC_C12", "#xdeshe.SC_C13", "#xdeshe.SC_C14", "#xdeshe.SC_C15", "#xdeshe.SC_C16" },
                { "#xdeshe.SC_C2", "#xdeshe.SC_C21", "#xdeshe.SC_C22", "#xdeshe.SC_C23", "#xdeshe.SC_C24", "#xdeshe.SC_C25", "#xdeshe.SC_C26" },
                { "#xdeshe.SC_C3", "#xdeshe.SC_C31", "#xdeshe.SC_C32", "#xdeshe.SC_C33" },
                { "#xdeshe.SC_C4", "#xdeshe.SC_C41", "#xdeshe.SC_C42", "#xdeshe.SC_C43", "#xdeshe.SC_C44" },
                { "#xdeshe.SC_C5", "#xdeshe.SC_C51", "#xdeshe.SC_C52", "#xdeshe.SC_C53", "#xdeshe.SC_C54" },
                { "#xdeshe.SC_C6", "#xdeshe.SC_C61", "#xdeshe.SC_C62", "#xdeshe.SC_C63", "#xdeshe.SC_C64", "#xdeshe.SC_C65" },
                { "#xdeshe.SC_EType", "#xdeshe.SC_Undead", "#xdeshe.SC_Resistance", "#xdeshe.SC_Enforcer", "#xdeshe.SC_Combine", "#xdeshe.SC_Random", "#xdeshe.SC_Mixed" }
            }
            local p3 = AddASheetAM( "Configs", "icon16/wrench.png" )  local pax = p3.P_Hold
            local pa2 = pax:Add( "DPanel" )  pa2:Dock( TOP ) pa2:SetSize( 0, 152 ) pa2:SetText( "" )
            local fir, sec = { 7, 4, 3, 1 }, { 5, 6, 2 }
            function pa2:Paint( w, h )
                surface.SetDrawColor( 64, 64, 64 ) surface.DrawRect( 2, 2, w -4, h -4 )
                surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4, 2 )
                surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4 )
                if xdesc.mats[ dat[ 4 ][ 7 ] ] then
                    surface.SetMaterial( xdesc.mats[ dat[ 4 ][ 7 ] ] )
                    surface.SetDrawColor( 255, 255, 255 )
                    surface.DrawTexturedRect( 8, 8, 136, 136 )
                    surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 8, 8, 136, 136, 2 )
                    surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 8, 8, 136, 136 )
                end
                for k, v in pairs( fir ) do
                    draw.TextShadow( {
                        text = language.GetPhrase( cons[ v ][ 1 ] ),
                        pos = { 152, 24 +( k-1 )*34 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = "-",
                        pos = { 362, 24+( k-1 )*34 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = language.GetPhrase(  cons[ v ][ dat[ 4 ][ v ]+1 ] ),
                        pos = { 392, 24+( k-1 )*34 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                end
            end
            for k, v in pairs( sec ) do
                local pa2 = pax:Add( "DPanel" )
                pa2:Dock( TOP ) pa2:SetSize( 0, 48 ) pa2:SetText( "" )
                function pa2:Paint( w, h )
                    surface.SetDrawColor( 64, 64, 64 ) surface.DrawRect( 2, 2, w -4, h -4 )
                    surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4, 2 )
                    surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4 )
                    draw.TextShadow( {
                        text = language.GetPhrase( cons[ v ][ 1 ] ),
                        pos = { 16, h/2 +1 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = "-",
                        pos = { w/2, h/2 +1 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = language.GetPhrase( cons[ v ][ dat[ 4 ][ v ]+1 ] ),
                        pos = { w*0.6, h/2 +1 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                end
            end

            local p1 = AddASheetAM( language.GetPhrase( "xdeshe.Summary" ), "icon16/script.png" )
            local res = { "", language.GetPhrase( "#xdeshe.SC_R1" ), language.GetPhrase( "#xdeshe.SC_R2" ),
            language.GetPhrase( "#xdeshe.SC_R3" ), language.GetPhrase( "#xdeshe.SC_R4" ), language.GetPhrase( "#xdeshe.SC_R5" ) }
            for i=0, 5 do local pax = p1.P_Hold
                local pa2 = pax:Add( "DPanel" )
                pa2:Dock( TOP ) pa2:SetSize( 0, 48 ) pa2:SetText( "" )
                function pa2:Paint( w, h )
                    surface.SetDrawColor( 64, 64, 64 ) surface.DrawRect( 2, 2, w -4, h -4 )
                    surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4, 2 )
                    surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4 )
                    if i == 0 then
                        local nam = ( !pan.B_Win and dat[ 3 ][ 1 ] or dat[ 3 ][ 2 ] )
                        local str = language.GetPhrase( "xdeshe."..( !pan.B_Win and "SC_RFail" or "SC_RWin" ) )
                        draw.TextShadow( {
                            text = nam..str,
                            pos = { 16, h/2 +1 },
                            font = "xdeshe_Font2",
                            xalign = TEXT_ALIGN_LEFT,
                            yalign = TEXT_ALIGN_CENTER,
                            color = Color( 255, 255, 255 )
                        }, 1, 255 )
                        return
                    end
                    draw.TextShadow( {
                        text = res[ i +1 ],
                        pos = { 16, h/2 +1 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = "-",
                        pos = { w/2, h/2 +1 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    local str = ""
                    if i == 1 then str = dat[ 1 ][ 1 ]..( dat[ 1 ][ 2 ] == -1 and "" or " / ".. dat[ 1 ][ 2 ] )
                    elseif i == 2 then str = dat[ 1 ][ 3 ] elseif i == 3 then str = dat[ 1 ][ 4 ] elseif i == 4 then str = dat[ 1 ][ 5 ]
                    elseif i == 5 then
                        local tim = ( pan.N_Curt -dat[ 1 ][ 6 ] )  local mii = math.floor( tim/60 )  local sec = ( tim -mii*60 )
                        local mmm = math.floor( sec )  local xxx = math.floor( ( sec -mmm )*100 )
                        str = xdeshe_SNum( mii )..":"..xdeshe_SNum( mmm )..":"..xdeshe_SNum( xxx )
                    end
                    draw.TextShadow( {
                        text = str,
                        pos = { w*0.6, h/2 +1 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                end
            end

            local p2 = AddASheetAM( language.GetPhrase( "xdeshe.SC_Begin3" ), "icon16/group.png" )  local pax = p2.P_Hold
            p2.N_Plys = 0  for k, v in pairs( dat[ 2 ] ) do p2.N_Plys = p2.N_Plys +1 end
            local pa2 = pax:Add( "DPanel" )  pa2:Dock( TOP ) pa2:SetSize( 0, 36 ) pa2:SetText( "" )
            function pa2:Paint( w, h )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Begin3" ).." ("..p2.N_Plys..")",
                    pos = { 4, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_LEFT,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255, 255, 255 )
                }, 1, 255 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Kills" ),
                    pos = { w*0.5, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255, 255, 255 )
                }, 1, 255 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Downs" ),
                    pos = { w*0.7, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255, 255, 255 )
                }, 1, 255 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Items" ),
                    pos = { w*0.9, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = Color( 255, 255, 255 )
                }, 1, 255 )
            end
            for k, v in SortedPairsByMemberValue( dat[ 2 ], 1, true ) do
                local pa2 = pax:Add( "DPanel" )
                pa2:Dock( TOP ) pa2:SetSize( 0, 48 ) pa2:SetText( "" )
                local nam = player.GetBySteamID( k ) --优化暴击
                nam = ( IsValid( nam ) and nam:Nick() or k )
                function pa2:Paint( w, h )
                    surface.SetDrawColor( 64, 64, 64 ) surface.DrawRect( 2, 2, w -4, h -4 )
                    surface.SetDrawColor( 255, 255, 255 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4, 2 )
                    surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 2, 2, w -4, h -4 )
                    draw.TextShadow( {
                        text = nam,
                        pos = { 8, h/2 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_LEFT,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = v[ 1 ],
                        pos = { w*0.5, h/2 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = v[ 2 ],
                        pos = { w*0.7, h/2 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                    draw.TextShadow( {
                        text = v[ 3 ],
                        pos = { w*0.9, h/2 },
                        font = "xdeshe_Font2",
                        xalign = TEXT_ALIGN_CENTER,
                        yalign = TEXT_ALIGN_CENTER,
                        color = Color( 255, 255, 255 )
                    }, 1, 255 )
                end
            end
        end
        return pan
    end )
    xdeshe_MenuRegister( "xdesc5", function( id, ent, dat ) --退出界面
        if IsValid( xdeshe_vguis[ id ] ) then xdeshe_vguis[ id ]:Remove() end local ply = LocalPlayer()
        local pan = vgui.Create( "DFrame" )
        pan:SetSize( 800, 600 )
        pan:SetTitle( "" )
        pan:ShowCloseButton( false )
        pan:SetScreenLock( true )
        pan:SetDeleteOnClose( true )
        pan:Center()
        pan:MakePopup()
        pan:SetAlpha( 1 )
        pan:AlphaTo( 255, 0.5 )
        pan.B_Close = false
        pan.N_Blur = SysTime()
        pan.N_Start = CurTime() +1
        function pan:MenuClose() pan:Remove() end
        function pan:Think()
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) or ent:GetXDE_State() < 2 or ( ent:GetXDE_State() > 2 and ply:Alive() )
            or !ply:GetNWBool( "XDESC" ) then
                if pan.N_Start <= CurTime() then pan:Remove() end
                return
            end
        end
        function pan:Paint( w, h )
            Derma_DrawBackgroundBlur( pan, pan.N_Blur )
            local ent = GetGlobal2Entity( "XDESC" )
            if !IsValid( ent ) or ent:GetXDE_State() < 2 or ( ent:GetXDE_State() > 2 and ply:Alive() )
            or !ply:GetNWBool( "XDESC" ) then
                return
            end
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.SC_Quit1" ),
                pos = { w/2, h*0.25 },
                font = "xdeshe_Font9",
                xalign = TEXT_ALIGN_CENTER,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe."..( ent:GetXDE_Player() == 1 and "SC_Quit2" or "SC_Quit3" ) ),
                pos = { w/2, h*0.35 },
                font = "xdeshe_Font3",
                xalign = TEXT_ALIGN_CENTER,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
        end
        for i=1, 2 do --确定按钮
            pan.B_Quit = pan:Add( "DButton" )  local but = pan.B_Quit
            but:SetPos( 300 +( i == 1 and -200 or 200 ), 400 )
            but:SetSize( 200, 50 )
            but:SetIcon( i == 1 and "icon16/tick.png" or "icon16/cross.png" )
            but:SetText( "" )
            but.B_Hover = false
            but.N_Click = 0
            function but:Paint( w, h )
                local alp = math.Clamp( ( but.N_Click-SysTime() )/0.3, 0, 1 )
                if but.B_Hover then alp = 1-alp end
                surface.SetDrawColor( 128, 128, 128 ) surface.DrawOutlinedRect( 0, 0, w, h, 4 +alp*4 )
                surface.SetDrawColor( 192, 192, 192 ) surface.DrawOutlinedRect( 0, 0, w, h, 1 +alp*4 )
                draw.TextShadow( {
                    text = language.GetPhrase( "xdeshe.SC_Quit"..( i == 1 and "4" or "5" ) ),
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = i == 1 and Color( 255, 255 -alp*255, 255 -alp*255 ) or Color( 255 -alp*255, 255, 255 -alp*255 )
                }, 1, 255 )
            end
            function but:OnCursorEntered() but.B_Hover = true  but.N_Click = SysTime() +0.3 end
            function but:OnCursorExited() but.B_Hover = false  but.N_Click = SysTime() +0.3 end
            function but:DoClick()
                if pan.B_Close then return end pan.B_Close = true
                if i == 1 then
                    net.Start( "xdesc_Leave" ) net.SendToServer()
                    surface.PlaySound( "doors/default_locked.wav" )
                else
                    surface.PlaySound( "ui/buttonclick.wav" )
                end
                pan:MenuClose()
            end
        end
        return pan
    end )
end

hook.Add( "SpawnMenuOpen", "xdesc_nocheat", function() if LocalPlayer():GetNWBool( "XDESC" ) and LocalPlayer():GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "ContextMenuOpen", "xdesc_nocheat", function()
    if LocalPlayer():GetNWBool( "XDESC" ) then local ply, ent = LocalPlayer(), GetGlobal2Entity( "XDESC" )
        if IsValid( ent ) and ( ent:GetXDE_State() == 2 or !ply:Alive() ) then
            xdeshe_MenuOpen( ply, "xdesc5", nil, "_" )
        end
        return false
    end
end )
hook.Add( "CanPlayerSuicide", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerNoClip", "xdesc_nocheat", function( ply, bol ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) and bol then return false end end )
hook.Add( "PlayerSpawnEffect", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnNPC", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnObject", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnProp", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnRagdoll", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnSENT", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnSWEP", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerGiveSWEP", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PlayerSpawnVehicle", "xdesc_nocheat", function( ply ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "CanPlayerUnfreeze", "xdesc_nocheat", function( ply, ent, phy ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "PhysgunPickup", "xdesc_pp", function( ply, ent ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "CanProperty", "xdesc_cp", function( ply, property, ent ) if IsValid( ply ) and ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "CanTool", "xdesc_ct", function( ply, tr, toolname, tool, button ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "AllowPlayerPickup", "xdesc_app", function( ply, ent ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "GravGunPickupAllowed", "xdesc_gpa", function( ply, ent ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "GravGunPunt", "xdesc_ggp", function( ply, ent ) if ply:GetNWBool( "XDESC" ) and ply:GetNWBool( "XDESC_P" ) then return false end end )
hook.Add( "StartCommand", "xdesc_sc", function( ply, cmd )
    if ply:Alive() and ply:GetNWFloat( "XDESC_F" ) > CurTime() then
        local spd = 1 -math.Clamp( ply:GetNWFloat( "XDESC_F" ) -CurTime(), 0, 1 )*0.8
        local vel = ply:GetVelocity()
        ply:SetLocalVelocity( Vector( vel.x*spd, vel.y*spd, vel.z ) )
    end
end )

CreateClientConVar( "xdesc_waves", "2", true, false, "", 1, 6 ) --波数总计
CreateClientConVar( "xdesc_supply", "2", true, false, "", 1, 6 ) --补给几率
CreateClientConVar( "xdesc_gamemode", "1", true, false, "", 1, 3 ) --游戏模式
CreateClientConVar( "xdesc_difficulty", "2", true, false, "", 1, 4 ) --敌人难度
CreateClientConVar( "xdesc_movement", "1", true, false, "", 1, 4 ) --敌人行动
CreateClientConVar( "xdesc_amount", "2", true, false, "", 1, 5 ) --敌人数量
CreateClientConVar( "xdesc_enemy", "1", true, false, "", 1, 6 ) --敌人类型

function xdesc.PickTable( tab ) --挑选组项
    if !istable( tab ) then return tab end
    local ttl, tax = 0, {}
    for k, v in pairs( tab ) do
        ttl = ttl +v
        tax[ ttl ] = k
    end
    local ran = math.random( 1, ttl )
    for k, v in SortedPairs( tax ) do
        if ran <= k then
            return v
        end
    end
    return nil
end
function xdesc.GetState() --当前状态
    local glo = GetGlobal2Entity( "XDESC" )
    return IsValid( glo ) and glo:GetXDE_State() or 0
end
function xdesc.GetSpec() --当前突变
    local ent = GetGlobal2Entity( "XDESC" )
    if !IsValid( ent ) or ent:GetXDE_Spec() == "" then return nil end
    return xdesc.mts[ ent:GetXDE_Spec() ]
end

if SERVER then
	local fil, dir = file.Find( "somehandysents/xdesc_*.lua", "LUA" )
	if !fil or !dir then return end
    for _, out in pairs( fil ) do if out == "xdesc_core.lua" then continue end include( "somehandysents/"..out ) end
end
concommand.Add( "xdesc_throw", function( ply, cmd, var )
    if !IsValid( ply ) or !ply:Alive() or !ply:IsSuperAdmin() or !var[ 1 ] or !xdesc.ths[ var[ 1 ] ] then return end
    xdesc.ThrowSpawn( var[ 1 ], ply:GetEyeTrace().HitPos, Vector( 0, 0, 128 ), 2, Entity( 0 ) )
end )