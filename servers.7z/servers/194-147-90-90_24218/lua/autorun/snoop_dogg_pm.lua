-- "lua\\autorun\\snoop_dogg_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Snopp Dogg", "models/snoopdogg.mdl" )
list.Set( "PlayerOptionsModel", "Snoop Dogg", "models/snoopdogg.mdl" )
