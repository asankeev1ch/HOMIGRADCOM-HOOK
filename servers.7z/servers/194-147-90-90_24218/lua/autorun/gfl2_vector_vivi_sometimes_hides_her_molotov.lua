-- "lua\\autorun\\gfl2_vector_vivi_sometimes_hides_her_molotov.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Girls Frontline 2 Vector Vivi Sometimes Hides her Molotov (KRISS Vector)", "models/player/gfl2_vector_vivi_sometimes_hides_her_molotov.mdl" )
player_manager.AddValidHands( "Girls Frontline 2 Vector Vivi Sometimes Hides her Molotov (KRISS Vector)", "models/arms/gfl2_vector_vivi_sometimes_hides_her_molotov_arms.mdl", 0, "00000000" )

local Category = "Girls Frontline 2"

local NPC =
{
	Name = "Vector Vivi Sometimes Hides her Molotov (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/gfl2_vector_vivi_sometimes_hides_her_molotov_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_vector_vivi_sometimes_hides_her_molotov_friendly", NPC )

local NPC =
{
	Name = "Vector Vivi Sometimes Hides her Molotov (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/gfl2_vector_vivi_sometimes_hides_her_molotov_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_vector_vivi_sometimes_hides_her_molotov_enemy", NPC )
