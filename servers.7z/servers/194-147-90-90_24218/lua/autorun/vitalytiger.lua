-- "lua\\autorun\\vitalytiger.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
/*
	Addon by Voikanaa	
*/

player_manager.AddValidModel( "Vitaly the tiger", 		"models/player/vitaly PM.mdl" );
list.Set( "PlayerOptionsModel", "Vitaly the tiger", 	"models/player/vitaly PM.mdl" );