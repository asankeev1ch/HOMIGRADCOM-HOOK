-- "lua\\autorun\\rabbitholemiku_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Rabbit Hole Miku", "models/drm/vrc/Rabbit_Hole_Miku.mdl" )
list.Set( "PlayerOptionsModel", "Rabbit Hole Miku", "models/drm/vrc/Rabbit_Hole_Miku.mdl" )
player_manager.AddValidHands( "Rabbit Hole Miku", "models/c_hands/vrc/c_hands_Rabbit_Hole_Miku.mdl", 0, "00000000" )