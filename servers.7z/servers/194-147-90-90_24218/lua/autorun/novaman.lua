-- "lua\\autorun\\novaman.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "galaxyman_yellow", "models/player/galaxyman/galaxyman_yellow.mdl" )
player_manager.AddValidHands( "galaxyman_yellow", "models/player/galaxyman/galaxyman_hands_yellow.mdl", 0, "00000000", true )
list.Set( "PlayerOptionsModel", "Nova Man", "models/player/galaxyman/galaxyman_yellow.mdl" )
