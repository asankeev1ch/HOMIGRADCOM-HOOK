-- "lua\\autorun\\player_lappland_refined_horrormare.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Lappland_Refined_Horrormare","models/dih/Lappland_Refined_Horrormare.mdl" )
player_manager.AddValidHands( "Lappland_Refined_Horrormare", "models/dih/v_arms_Lappland_Refined_Horrormare.mdl", 0, "00000000" )