-- "lua\\autorun\\wagner.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Wagner", "models/wagner/wagner_soldier.mdl" )
player_manager.AddValidHands( "Wagner", "models/wagner/hands.mdl", 0, "00000000" )