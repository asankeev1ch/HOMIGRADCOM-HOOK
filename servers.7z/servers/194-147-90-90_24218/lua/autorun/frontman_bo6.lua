-- "lua\\autorun\\frontman_bo6.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile()
end

player_manager.AddValidModel( "frontman_bo6", "models/bo6/frontman/frontman_pm.mdl" )
player_manager.AddValidHands( "frontman_bo6", "models/bo6/frontman/frontman_chands.mdl", 0, "00000000" )
