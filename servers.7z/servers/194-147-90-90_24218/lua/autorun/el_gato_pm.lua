-- "lua\\autorun\\el_gato_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "El Gato", "models/player/rim/el_gato_01_pm.mdl" );
list.Set( "PlayerOptionsModel", "El Gato", "models/player/rim/el_gato_01_pm.mdl" );