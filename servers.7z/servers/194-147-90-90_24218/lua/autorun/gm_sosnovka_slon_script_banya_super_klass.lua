-- "lua\\autorun\\gm_sosnovka_slon_script_banya_super_klass.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Конфиги. Здесь менять можно.

local MAP_NAMES = {
	"gm_sosnovka2",
	"gm_sosnovka2_foggy",
	"gm_sosnovka2_night",
	"gm_sosnovka2_snowfall",
	"gm_sosnovka2_snowfall2",
	"gm_sosnovka2_sunset"
}
local FIREPIT_FIRST_STAGE_TIME = 10.0
local FIREPIT_SECOND_STAGE_TIME = 100.0
local FIREPIT_ENDING_STAGE_TIME = 320.0

local BANYA_DOOR_OPEN_ANGLE = -90

-- Дальше опасная зона, которую трогать не стоит.

local correctMap = false

for _, mapName in pairs(MAP_NAMES) do 
	if game.GetMap() == mapName then
		correctMap = true
	end
end

if SERVER and correctMap then

	local firepit = {}
	local fireStarted = false
	local fireCanBeRefilled = false
	local firepitEntity = nil
	local isFireActive = false

	firepit.NamedEntities = nil

	function firepit.InitializeNamedEntities() 
	    firepit.NamedEntities = {}
	    local namedEnts = firepit.NamedEntities
	    for index = 1, 65535 do 
	        local ent = Entity(index)
	        if IsValid(ent) then
	        	if ent.GetName == nil then
	        		continue
	        	end
	            local name = ent:GetName()
	            if name ~= nil then
	                if namedEnts[name] == nil then
	                    namedEnts[name] = {}
	                end
	                table.Add(namedEnts[name], { ent })
	            end
	        end
	    end
	end

	function firepit.GetNamedEnts(name) 
	    if not firepit.NamedEntities then
	        firepit.InitializeNamedEntities()
	    end
	    return firepit.NamedEntities[name]
	end

	function InitializePolenoFire(polenoProp, polenoFireSmoke, polenoFire, polenoFireSound)
		local polenoFireAlpha = 0.0

		local ent = ents.Create("base_gmodentity")
		ent:SetModel(polenoProp:GetModel())
		ent:PhysicsInit(SOLID_VPHYSICS)
		ent:SetSolid(SOLID_VPHYSICS)
		ent:SetMoveType(MOVETYPE_VPHYSICS)
		ent:GetPhysicsObject():EnableMotion(false)
		ent:SetPos(polenoProp:GetPos())
		ent:SetAngles(polenoProp:GetAngles())
		ent:SetName("FirepitEntity")
		firepitEntity = ent

		function ent:Use(ply) 
			if fireStarted then
				return 
			end
			fireStarted = true
			fireCanBeRefilled = false

			polenoFireSmoke:Fire("Start")

			timer.Create("SlonFirepit.PolenoFireAlphaTransition", 0.01, 100, function()
				if not IsValid(polenoFire) then
					return
				end
				polenoFireAlpha = Lerp(0.03, polenoFireAlpha, 255)
				polenoFire:Fire("ColorRedValue", polenoFireAlpha)
				polenoFire:Fire("ColorGreenValue", polenoFireAlpha)
				polenoFire:Fire("ColorBlueValue", polenoFireAlpha)
				polenoFire:Fire("Alpha", polenoFireAlpha) 
				polenoFireSound:Fire("Volume", polenoFireAlpha * 0.01)
			end)

			timer.Simple(FIREPIT_FIRST_STAGE_TIME, function() 
				if not IsValid(self) then
					return
				end
				isFireActive = true
				self:SetModel("models/les2/brevna2.mdl")
				timer.Simple(FIREPIT_SECOND_STAGE_TIME, function() 
					if not IsValid(self) then
						return
					end
					self:SetModel("models/les2/brevna3.mdl")
					timer.Simple(FIREPIT_ENDING_STAGE_TIME, function() 
						if not IsValid(self) then
							return
						end
						self:SetModel("models/les2/brevna4.mdl")
						polenoFireSmoke:Fire("Stop")
						isFireActive = false
						timer.Create("SlonFirepit.PolenoFireAlphaTransition", 0.01, 1000, function()
							if not IsValid(polenoFire) then
								return
							end
							polenoFireAlpha = Lerp(0.003, polenoFireAlpha, 0)
							polenoFire:Fire("ColorRedValue", polenoFireAlpha)
							polenoFire:Fire("ColorGreenValue", polenoFireAlpha)
							polenoFire:Fire("ColorBlueValue", polenoFireAlpha)
							polenoFire:Fire("Alpha", polenoFireAlpha)
							polenoFireSound:Fire("Volume", polenoFireAlpha * 0.01)
							fireCanBeRefilled = true
						end)
					end)
				end)
			end)
		end

		function ent:Touch(ent)
			if fireStarted and fireCanBeRefilled then
				if ent:GetName() == "banya_poleno_refill" then
					self:SetModel("models/les2/brevna.mdl")
					ent:Remove()
					fireCanBeRefilled = false
					fireStarted = false
				end
			end
		end

		function ent:Draw() 
			self:DrawModel()
		end

		ent:Spawn()

		polenoProp:Remove()
	end

	function InitializeBanyaDoor(
			banyaDoor
		)
		local ent = ents.Create("base_gmodentity")
		ent:SetModel(banyaDoor:GetModel())
		ent:PhysicsInit(SOLID_VPHYSICS)
		ent:SetSolid(SOLID_VPHYSICS)
		ent:SetMoveType(MOVETYPE_VPHYSICS)
		ent:GetPhysicsObject():EnableMotion(false)
		ent:SetPos(banyaDoor:GetPos())
		ent:SetAngles(banyaDoor:GetAngles())
		ent:SetName("BanyaDoor")
		ent.IsOpen = false
		ent.CanBeToggled = true
		ent.InitialAngles = ent:GetAngles()
		ent.CurrentOffsetAngle = Angle()

		function ent:ToggleDoor(ply)
			if not ent.CanBeToggled then
				return
			end
			self.CanBeToggled = false
			if self.IsOpen then
				self.IsOpen = false
			else
				self.IsOpen = true
			end
			timer.Simple(1.0, function() 
				self.CanBeToggled = true
			end)
			if ply and isFireActive then
				local dmginfo = DamageInfo()
				dmginfo:SetDamage(10)
				dmginfo:SetDamageType(DMG_BURN)
				ply:TakeDamageInfo(dmginfo)
			end
		end

		function ent:Use(ply)
			self:ToggleDoor(ply)
		end

		function ent:Touch(ent)
			if ent:GetName() == "banya_opener" then
				self:ToggleDoor()
			end
		end

		function ent:Initialize()
			timer.Create("SlonFirepit.BanyaDoorOpening", 0.01, 0, function() 
				if not IsValid(self) then
					return
				end
				local offsetAngle
				if self.IsOpen then
					offsetAngle = Angle(
						0, 
						BANYA_DOOR_OPEN_ANGLE, 
						0
					)
				else
					offsetAngle = Angle()
				end
				self.CurrentOffsetAngle = Lerp(0.01 * 5.0, self.CurrentOffsetAngle, offsetAngle)
				self:SetAngles(self.InitialAngles + self.CurrentOffsetAngle)
			end)
		end

		--[[function ent:Think()
			local offsetAngle
			if self.IsOpen then
				offsetAngle = Angle(
					0, 
					BANYA_DOOR_OPEN_ANGLE, 
					0
				)
			else
				offsetAngle = Angle()
			end
			self.CurrentOffsetAngle = Lerp(FrameTime() * 12.0, self.CurrentOffsetAngle, offsetAngle)
			self:SetAngles(self.InitialAngles + self.CurrentOffsetAngle)
		end]]

		function ent:Draw() 
			self:DrawModel()
		end

		ent:Spawn()

		banyaDoor:Remove()
	end

	function firepit.Initialize() 
		fireStarted = false
		fireCanBeRefilled = false
		firepitEntity = nil
		isFireActive = false

		local props = firepit.GetNamedEnts("banya_poleno")
		local fires = firepit.GetNamedEnts("poleno_fire")
		local smokes = firepit.GetNamedEnts("poleno_fire_smoke")
		local sounds = firepit.GetNamedEnts("poleno_fire_sound")
		local doors = firepit.GetNamedEnts("banya_door")

		if not props or not fires or not smokes or not sounds or not doors then
			Entity(1):ChatPrint("Error occured, check console")
			print("SLON SCRIPT")
			print("ERROR: No props/fires/smokes/sounds/doors")
			print("Props: " .. tostring(props))
			print("Fires: " .. tostring(fires))
			print("Smokes: " .. tostring(smokes))
			print("Sounds: " .. tostring(sounds))
			print("Doors: " .. tostring(doors))
		end

		local polenoProp = props[1]

		local polenoFire = fires[1]
		polenoFire:Fire("ColorRedValue", 0.0)
		polenoFire:Fire("ColorGreenValue", 0.0)
		polenoFire:Fire("ColorBlueValue", 0.0)
		polenoFire:Fire("Alpha", 0.0)

		local polenoFireSmoke = smokes[1]

		local polenoFireSound = sounds[1]
		polenoFireSound:Fire("Volume", 0.0)

		local banyaDoor = doors[1]

		InitializePolenoFire(polenoProp, polenoFireSmoke, polenoFire, polenoFireSound)
		InitializeBanyaDoor(banyaDoor)
	end

	hook.Add("PreCleanupMap", "SlonFirepit.NamedEntitiesOnMapCleanup", function() 
	    firepit.NamedEntities = nil
	    timer.Simple(0.1, function()
	    	firepit.Initialize()
	    end)
	end)

	hook.Add("InitPostEntity", "SlonFirepit.Initialize", function() 
		firepit.Initialize()
	end)

	hook.Add("PhysgunPickup", "SlonFirepit.OverridePhysgunForMapEntities", function(ply, ent) 
        if ent:GetName() == "FirepitEntity" or ent:GetName() == "BanyaDoor" then
            return false
        end
	end)

end