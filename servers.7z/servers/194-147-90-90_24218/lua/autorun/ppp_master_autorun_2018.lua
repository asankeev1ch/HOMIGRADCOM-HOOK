-- "lua\\autorun\\ppp_master_autorun_2018.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
AddCSLuaFile()

-- Sooner or later the entire damn addon will be launched from here.
