-- "lua\\autorun\\kuhnya.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "fedya", "models/kuhnya/fedya.mdl" )
player_manager.AddValidModel( "fedya", "models/kuhnya/fedya.mdl" )
list.Set( "PlayerOptionsModel", "senya", "models/kuhnya/senya.mdl" )
player_manager.AddValidModel( "senya", "models/kuhnya/senya.mdl" )