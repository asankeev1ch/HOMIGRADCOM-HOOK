-- "lua\\autorun\\artemius_guard_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Guard Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/human/guard/guard.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Guard Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Guard Angry", 
				Class = "npc_combine",
				Model = "models/artemius/human/guard/guard.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Guard Angry", NPC )

local Category = "SCP:CB NPC's"