-- "lua\\autorun\\ukon.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "ukon", "models/vrc/ukon.mdl" )                         --PM模型
player_manager.AddValidHands( "ukon", "models/arms/ukon_arms.mdl", 0, "00000000" )  

local Category = "ukon"         

local NPC =
{
	Name = "ukon (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/vrc/ukon_npc.mdl",
	Category = Category
}

list.Set( "NPC", "ukon_friendly", NPC )

local NPC =
{
	Name = "ukon (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/vrc/ukon_npc_c.mdl",
	Category = Category
}

list.Set( "NPC", "ukon_enemy", NPC )