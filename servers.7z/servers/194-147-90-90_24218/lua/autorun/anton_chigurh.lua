-- "lua\\autorun\\anton_chigurh.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

-- Anton Chigurh No Country for Old Men--
player_manager.AddValidModel( "Anton Chigurh", "models/mug/ncfom/anton_chigurh.mdl" );
player_manager.AddValidHands( "Anton Chigurh", "models/mug/ncfom/anton_chigurh_arms.mdl", 0, "00000000" )