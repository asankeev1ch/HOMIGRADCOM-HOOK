-- "lua\\autorun\\miside.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Mita", "models/MiSide/mita.mdl" );
player_manager.AddValidHands( "Mita", "models/MiSide/mita_arms.mdl", 0, "0000000" )
player_manager.AddValidModel( "Player", "models/MiSide/Player.mdl" );
player_manager.AddValidHands( "Player", "models/MiSide/player_arms.mdl", 0, "0000000" )
player_manager.AddValidModel( "Broken Mita", "models/MiSide/Brokenmita.mdl" );
player_manager.AddValidHands( "Broken Mita", "models/MiSide/brokenmita_arms.mdl", 0, "0000000" )
player_manager.AddValidModel( "Core", "models/MiSide/core.mdl" );
player_manager.AddValidHands( "Core", "models/MiSide/core_arms.mdl", 0, "0000000" )
player_manager.AddValidModel( "Maneken", "models/MiSide/maneken.mdl" );
player_manager.AddValidHands( "Maneken", "models/MiSide/maneken_arms.mdl", 0, "0000000" )
player_manager.AddValidModel( "Chibi", "models/MiSide/chibi.mdl" );
player_manager.AddValidModel( "Creepy Mita", "models/MiSide/creepymita.mdl" );
player_manager.AddValidHands( "Creepy Mita", "models/MiSide/creepymita_arms.mdl", 0, "0000000" )