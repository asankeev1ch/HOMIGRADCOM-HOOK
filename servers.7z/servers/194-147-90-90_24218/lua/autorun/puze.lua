-- "lua\\autorun\\puze.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "Vladimir Putin", "models/characters/puze/pu.mdl" )
player_manager.AddValidModel( "Vladimir Putin", "models/characters/puze/pu.mdl" )

list.Set( "PlayerOptionsModel", "Vladimir Zelenskiy", "models/characters/puze/ze.mdl" )
player_manager.AddValidModel( "Vladimir Zelenskiy", "models/characters/puze/ze.mdl" )