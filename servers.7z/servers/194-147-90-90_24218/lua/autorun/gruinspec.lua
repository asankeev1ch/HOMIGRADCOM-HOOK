-- "lua\\autorun\\gruinspec.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//Replace all the "XXX" with your character name.

//         Put your model folder here vvv
player_manager.AddValidModel( "Gru", "models/hellinspector/gru/gru_pm.mdl" );

list.Set( "PlayerOptionsModel", "Gru", "models/hellinspector/gru/gru_pm.mdl" );


local Category = "Gru"

local NPC = {   
        Name = "Gru Enemy", 
        Class = "npc_combine_s", 
        Model = "models/hellinspector/gru/gru_pm.mdl",              
        Health = "100",                 
        KeyValues = { citizentype = 4 },                 
        Category = Category,
        Squadname = "Gru Enemy"
}

list.Set( "NPC", "npc_Gruenemy", NPC ) 

local NPC = {   
        Name = "Gru Friend", 
        Class = "npc_citizen", 
        Model = "models/hellinspector/gru/gru_pm.mdl",                
        Health = "100",                 
        KeyValues = { citizentype = 4 },                 
        Category = Category,
        Squadname = "Gru Friend"
}

list.Set( "NPC", "npc_GruFriend", NPC ) 


