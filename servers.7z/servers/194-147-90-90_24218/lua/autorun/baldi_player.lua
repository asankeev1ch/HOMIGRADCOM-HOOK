-- "lua\\autorun\\baldi_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Baldi", 					"models/player/baldi/Baldi.mdl" )
list.Set( "PlayerOptionsModel",  "Baldi", 					"models/player/baldi/Baldi.mdl" )
