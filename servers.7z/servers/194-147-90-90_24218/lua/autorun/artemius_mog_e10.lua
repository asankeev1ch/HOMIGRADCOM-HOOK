-- "lua\\autorun\\artemius_mog_e10.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP MOG E - 10", "models/artemius/human/mog_e10/mog_e10.mdl" )
list.Set( "PlayerOptionsModel", "SCP MOD E - 10", "models/artemius/human/mog_e10/mog_e10.mdl" )