-- "lua\\autorun\\scp_527.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP_527", "models/scp_527/scp_527.mdl" )