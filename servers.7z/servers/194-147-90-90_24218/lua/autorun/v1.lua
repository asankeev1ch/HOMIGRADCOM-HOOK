-- "lua\\autorun\\v1.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "V1", "models/Ultrakill/V1_PM.mdl" )
player_manager.AddValidHands("V1","models/Ultrakill/V1_C_HANDS.mdl",0,"00")

