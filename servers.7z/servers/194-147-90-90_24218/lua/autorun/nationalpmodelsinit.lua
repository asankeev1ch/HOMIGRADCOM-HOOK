-- "lua\\autorun\\nationalpmodelsinit.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Guard 1", "models/player/Rusty/NatGuard/male_01.mdl" )
list.Set( "PlayerOptionsModel", "Guard 1", "models/player/Rusty/NatGuard/male_01.mdl" )

player_manager.AddValidModel( "Guard 2", "models/player/Rusty/NatGuard/male_02.mdl" )
list.Set( "PlayerOptionsModel", "Guard 2", "models/player/Rusty/NatGuard/male_02.mdl" )

player_manager.AddValidModel( "Guard 3", "models/player/Rusty/NatGuard/male_03.mdl" )
list.Set( "PlayerOptionsModel", "Guard 3", "models/player/Rusty/NatGuard/male_03.mdl" )

player_manager.AddValidModel( "Guard 4", "models/player/Rusty/NatGuard/male_04.mdl" )
list.Set( "PlayerOptionsModel", "Guard 4", "models/player/Rusty/NatGuard/male_04.mdl" )

player_manager.AddValidModel( "Guard 5", "models/player/Rusty/NatGuard/male_05.mdl" )
list.Set( "PlayerOptionsModel", "Guard 5", "models/player/Rusty/NatGuard/male_05.mdl" )

player_manager.AddValidModel( "Guard 6", "models/player/Rusty/NatGuard/male_06.mdl" )
list.Set( "PlayerOptionsModel", "Guard 6", "models/player/Rusty/NatGuard/male_06.mdl" )

player_manager.AddValidModel( "Guard 7", "models/player/Rusty/NatGuard/male_07.mdl" )
list.Set( "PlayerOptionsModel", "Guard 7", "models/player/Rusty/NatGuard/male_07.mdl" )

player_manager.AddValidModel( "Guard 8", "models/player/Rusty/NatGuard/male_08.mdl" )
list.Set( "PlayerOptionsModel", "Guard 8", "models/player/Rusty/NatGuard/male_08.mdl" )

player_manager.AddValidModel( "Guard 9", "models/player/Rusty/NatGuard/male_09.mdl" )
list.Set( "PlayerOptionsModel", "Guard 9", "models/player/Rusty/NatGuard/male_09.mdl" )