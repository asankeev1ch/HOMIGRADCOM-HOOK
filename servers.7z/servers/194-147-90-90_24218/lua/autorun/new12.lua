-- "lua\\autorun\\new12.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Furry", "models/player/furry/wolfy.mdl" )
player_manager.AddValidHands( "Furry", "models/player/furry/fur_hands.mdl", 0, "00000000"  )

