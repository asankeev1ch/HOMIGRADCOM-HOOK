-- "lua\\autorun\\client\\roll_client.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

net.Receive("RollCommand", function()
    local roller = net.ReadString()
    local rollResult = net.ReadInt(32)
    local rollMax = net.ReadInt(32)

    if not roller then return end

    chat.AddText(
        Color(255, 140, 0), "[Roll] ",
        Color(128, 128, 128), roller .. " ",
        Color(128, 128, 128), "has rolled a ",
        Color(0, 100, 0), tostring(rollResult),
        Color(128, 128, 128), " out of ",
        Color(0, 100, 0), tostring(rollMax)
    )
end)


net.Receive("RollCommandError", function()
    local errorMsg = net.ReadString()

    chat.AddText(Color(255, 0, 0), errorMsg)
end)