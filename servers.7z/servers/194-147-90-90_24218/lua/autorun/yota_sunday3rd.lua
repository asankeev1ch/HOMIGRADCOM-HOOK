-- "lua\\autorun\\yota_sunday3rd.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Sunday 3RD", "models/yota/sunday3rd/yota_sunday3rd.mdl" )
list.Set( "PlayerOptionsModel", "Sunday 3RD", "models/yota/sunday3rd/yota_sunday3rd.mdl" )
player_manager.AddValidHands( "Sunday 3RD", "models/yota/sunday3rd/yota_sunday3rdc_arms.mdl", 0, "00000000" )