-- "lua\\autorun\\artemius_dclass.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP D - Class", "models/artemius/human/dclass/dclass.mdl" );