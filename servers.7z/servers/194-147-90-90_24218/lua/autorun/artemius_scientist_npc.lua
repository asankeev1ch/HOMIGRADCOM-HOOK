-- "lua\\autorun\\artemius_scientist_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Scientist Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/human/scientist/scientist.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Scientist Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Scientist Angry", 
				Class = "npc_combine",
				Model = "models/artemius/human/scientist/scientist.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Scientist Angry", NPC )

local Category = "SCP:CB NPC's"