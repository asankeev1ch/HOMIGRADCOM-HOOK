-- "lua\\autorun\\skins.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

player_manager.AddValidModel( "policeint 1","models/furious/player/policeint/policeint_male_01.mdl" )
list.Set( "PlayerOptionsModel","policeint 1","models/furious/player/policeint/policeint_male_01.mdl" )

player_manager.AddValidModel( "policeint 2","models/furious/player/policeint/policeint_male_02.mdl" )
list.Set( "PlayerOptionsModel","policeint 2","models/furious/player/policeint/policeint_male_02.mdl" )

player_manager.AddValidModel( "policeint 3","models/furious/player/policeint/policeint_male_03.mdl" )
list.Set( "PlayerOptionsModel","policeint 3","models/furious/player/policeint/policeint_male_03.mdl" )

player_manager.AddValidModel( "policeint 4","models/furious/player/policeint/policeint_male_04.mdl" )
list.Set( "PlayerOptionsModel","policeint 4","models/furious/player/policeint/policeint_male_04.mdl" )

player_manager.AddValidModel( "policeint 5","models/furious/player/policeint/policeint_male_05.mdl" )
list.Set( "PlayerOptionsModel","policeint 5","models/furious/player/policeint/policeint_male_05.mdl" )

player_manager.AddValidModel( "policeint 6","models/furious/player/policeint/policeint_male_06.mdl" )
list.Set( "PlayerOptionsModel","policeint 6","models/furious/player/policeint/policeint_male_06.mdl" )

player_manager.AddValidModel( "policeint 7","models/furious/player/policeint/policeint_male_07.mdl" )
list.Set( "PlayerOptionsModel","policeint 7","models/furious/player/policeint/policeint_male_07.mdl" )

player_manager.AddValidModel( "policeint 8","models/furious/player/policeint/policeint_male_08.mdl" )
list.Set( "PlayerOptionsModel","policeint 8","models/furious/player/policeint/policeint_male_08.mdl" )

player_manager.AddValidModel( "policeint 9","models/furious/player/policeint/policeint_male_09.mdl" )
list.Set( "PlayerOptionsModel","policeint 9","models/furious/player/policeint/policeint_male_09.mdl" )

