-- "lua\\autorun\\playermodel_sam.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "Jetstream_Sam", "models/ninja/sam.mdl" ) // "models/ninja/mgs4_Haven_trooper.mdl" )
player_manager.AddValidModel( "Jetstream_Sam", "models/ninja/sam.mdl" )   // "models/ninja/mgs4_Haven_trooper.mdl" )
player_manager.AddValidHands( "Jetstream_Sam", "models/Ninja/sam_v.mdl", 0, "00000000" ) // "models/Ninja/Haven_trooper_v.mdl", 0, "00000000" )
