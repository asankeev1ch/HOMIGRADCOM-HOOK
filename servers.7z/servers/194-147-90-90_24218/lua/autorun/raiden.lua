-- "lua\\autorun\\raiden.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Raiden", "models/raiden/raiden.mdl" )
player_manager.AddValidHands( "Raiden", "models/raiden/raiden_hands.mdl", 0, "00000000" )

