-- "lua\\autorun\\artemius_zombie_guard_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Zombie Guard Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/scp/zombie_guard/zombie_guard.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Zombie Guard Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Zombie Guard Angry", 
				Class = "npc_combine",
				Model = "models/artemius/scp/zombie_guard/zombie_guard.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Zombie Guard Angry", NPC )

local Category = "SCP:CB NPC's"