-- "lua\\autorun\\v2.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "V2", "models/Ultrakill/V2.mdl" )
player_manager.AddValidHands("V2","models/Ultrakill/V2_C_HANDS.mdl",0,"00")