-- "lua\\autorun\\motel_particles.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
game.AddParticles("particles/environmental_fixed.pcf")
game.AddParticles("particles/insect_fixed.pcf")
game.AddParticles("particles/rain_storm_fx.pcf")