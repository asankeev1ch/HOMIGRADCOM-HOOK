-- "lua\\autorun\\galaxyman.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "galaxyman", "models/player/galaxyman/galaxyman.mdl" )
player_manager.AddValidHands( "galaxyman", "models/player/galaxyman/galaxyman_hands.mdl", 0, "00000000", true )
list.Set( "PlayerOptionsModel", "Galaxy Man", "models/player/galaxyman/galaxyman.mdl" )
