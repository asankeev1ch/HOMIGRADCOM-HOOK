-- "lua\\autorun\\cj.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
/*
	Addon by Voikanaa	
*/

player_manager.AddValidModel( "Carl Johnson", 		"models/player/cj.mdl" );
list.Set( "PlayerOptionsModel", "Carl Johnson", 	"models/player/cj.mdl" );