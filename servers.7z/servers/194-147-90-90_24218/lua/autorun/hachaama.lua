-- "lua\\autorun\\hachaama.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Haachaama", 	"models/hololive/Hachaama-PM.mdl" );
list.Set( "PlayerOptionsModel", "Haachaama", 	"models/hololive/Hachaama-PM.mdl" );
player_manager.AddValidHands( "Haachaama", "models/hololive/Hachaama-arms.mdl", 0, "00000000" )

local NPC = { 	Name = "Haachama(friendly)", 
				Class = "npc_citizen",
				Weapons = { "weapon_smg1" },
				Model = "models/hololive/Hachaama-f.mdl",
				Health = "400",
				KeyValues = { citizentype = 4 },
                Category = "Hololive"    }

list.Set( "NPC", "npc_Hachaama-f", NPC )

local NPC = { 	Name = "Haachaama(Hostile)", 
				Class = "npc_combine_s",
				Weapons = { "weapon_smg1" },
				Model = "models/hololive/Hachaama-e.mdl",
				Health = "150",
				Numgrenades = "4",
                Category = "Hololive"    }

list.Set( "NPC", "npc_Hachaama-e", NPC )

