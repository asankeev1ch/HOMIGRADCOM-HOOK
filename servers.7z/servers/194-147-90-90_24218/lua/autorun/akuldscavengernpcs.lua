-- "lua\\autorun\\akuldscavengernpcs.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local CategoryName = "AKuld NPCs"

local NPC = { 	
				Name = "Scavenger Friendly", 
				Class = "npc_citizen",
				Model = "models/akuld/lcscavenger/scavenger_pm.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
                Category = CategoryName
			}

list.Set( "NPC", "Scavenger", NPC )

local NPC = { 	
				Name = "Scavenger Enemy", 
				Class = "npc_combine_s",
				Model = "models/akuld/lcscavenger/scavenger_pm.mdl",
				Health = "100",
				Weapons = { "weapon_smg1", "weapon_ar2" },
				KeyValues = { SquadName = "LC_Scavengers", Numgrenades = 5 },
				Category = CategoryName
			}

list.Set( "NPC", "Scavenger_enemy", NPC )
