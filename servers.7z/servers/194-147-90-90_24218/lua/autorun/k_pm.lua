-- "lua\\autorun\\k_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Joe", "models/player/joe/k_pm.mdl" )
player_manager.AddValidHands( "Joe", "models/weapons/joe/k_pm_arms.mdl", 0, "10000000" )
list.Set( "PlayerOptionsModel", "Joe", "models/player/joe/k_pm.mdl" )