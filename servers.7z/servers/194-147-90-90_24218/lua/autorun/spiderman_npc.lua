-- "lua\\autorun\\spiderman_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local Category = "Vinrax NPCS"
local NPC = {
		 		Name = "Spiderman", 
				Class = "npc_citizen",
				KeyValues = { citizentype = 4 },
				Model = "models/vinrax/player/spiderman.mdl",
				Health = "250",
				Category = Category	
		}
list.Set( "NPC", "npc_mcocspiderman", NPC )