-- "lua\\autorun\\drocheslav.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "drocheslav", "models/player/drocheslav.mdl" );
player_manager.AddValidModel( "drocheslav", "models/player/drocheslav.mdl" );