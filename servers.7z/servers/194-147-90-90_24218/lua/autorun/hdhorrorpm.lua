-- "lua\\autorun\\hdhorrorpm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Horror (HD)", "models/duskhd/horror/horrorhd_pm.mdl" );
