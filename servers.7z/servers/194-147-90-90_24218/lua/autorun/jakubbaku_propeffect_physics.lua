-- "lua\\autorun\\jakubbaku_propeffect_physics.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
properties.Add("prop_dephysicize", {
	MenuLabel = "Dephysicize (remove physics)",
	Order = 420 + 69 + 510, //weed and shrecks
	MenuIcon = "icon16/shape_square_delete.png",

	Filter = function(self, ent, ply)
		if(!IsValid(ent)) then return false end

		return ent:GetClass() == "prop_physicseffect_geiger21"
	end,

	Action = function(self, ent)
		self:MsgStart()
			net.WriteEntity(ent)
		self:MsgEnd()
	end,
	Receive = function(self, len, ply)
		local _ent = net.ReadEntity()

		if(!self:Filter(_ent, ply)) then return false end

		local ent = ents.Create("prop_effect")
		ent:SetPos(_ent:GetPos())
		ent:SetAngles(_ent:GetAngles())
		ent:SetModel(_ent:GetModel())
		ent:Spawn()

		_ent:Remove()

		undo.Create("Dephysicized effect")
			undo.AddEntity(ent)
			undo.SetPlayer(ply)
		undo.Finish()
	end
})

properties.Add("prop_physicseffect", {
	MenuLabel = "Physicize (add physics)",
	Order = 420 + 69 + 510, //weed and shrecks
	MenuIcon = "icon16/shape_square_add.png",

	Filter = function(self, ent, ply)
		if(!IsValid(ent)) then return false end

		return ent:GetClass() == "prop_effect"
	end,

	Action = function(self, ent)
		self:MsgStart()
			net.WriteEntity(ent)
		self:MsgEnd()
	end,
	Receive = function(self, len, ply)
		local _ent = net.ReadEntity()

		if(!self:Filter(_ent, ply)) then return false end

		local ent = ents.Create("prop_physicseffect_geiger21")
		ent:SetPos(_ent:GetPos())
		ent:SetAngles(_ent:GetAngles())
		ent:SetModel(_ent.AttachedEntity:GetModel())
		ent:Spawn()

		_ent:Remove()

		undo.Create("prop_physicseffect")
			undo.SetPlayer(ply)
			undo.AddEntity(ent)
		undo.Finish()
	end
})

if(SERVER) then
	function OnSpawnEffectGeiger21(ply, mdl, ent)
		if(ply:GetInfoNum("geiger21_physicsspawn", 0) == 0) then return false end

		local mins, maxs = ent.AttachedEntity:GetModelBounds()
		local size = mins:DistToSqr(maxs)

		local bigprop = GetConVar("geiger21_bigprop"):GetInt()
		if(ply:GetInfoNum("geiger21_physicsspawn", 0) == 1 && size > bigprop * bigprop) then return false end

		local _ent = ents.Create("prop_physicseffect_geiger21")
		_ent:SetPos(ent.AttachedEntity:GetPos())
		_ent:GetAngles(ent.AttachedEntity:GetAngles())
		_ent:SetModel(mdl)
		_ent:Spawn()

		ent:Remove()

		undo.Create("prop_physicseffect")
			undo.SetPlayer(ply)
			undo.AddEntity(_ent)
		undo.Finish()
	end

	hook.Add("PlayerSpawnedEffect", "Geiger21propphysicseffect", OnSpawnEffectGeiger21)
else
	CreateConVar( "geiger21_preventbig", "0", FCVAR_USERINFO )
	CreateConVar( "geiger21_physicsspawn", "0", FCVAR_USERINFO )
	CreateConVar( "geiger21_bigprop", "310", FCVAR_USERINFO )
	CreateClientConVar("geiger21_drawbounds", "0")

	function PopulateMenuBarGeiger21(menubar)
		local m = menubar:AddOrGetMenu("Effect spawning")

		m:AddCVar("Physicize effects on spawn", "geiger21_physicsspawn", "1", "0")
		m:AddCVar("Don't physicize big props", "geiger21_preventbig", "1", "0")
		m:AddSpacer()
		m:AddCVar("Draw physics bounds", "geiger21_drawbounds", "1", "0")
	end

	cvars.AddChangeCallback("geiger21_drawbounds", function(name, old, new)
		if(new == "1" && old == "0") then
			local _ents = ents.FindByClass("prop_physicseffect_geiger21")

			for k, v in pairs(_ents) do
				v.DrawTranslucent = v.DrawWithBounds
			end
		elseif(new == "0" && old == "1") then
			local _ents = ents.FindByClass("prop_physicseffect_geiger21")

			for k, v in pairs(_ents) do
				v.DrawTranslucent = v.DrawWithoutBounds
			end
		end
	end, "geiger21idiot")

	hook.Add("PopulateMenuBar", "Geiger21propphysicseffectProperties", PopulateMenuBarGeiger21)
end