-- "lua\\autorun\\borat_cosplayer.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

local function AddPlayerModel( name, model )

	list.Set( "PlayerOptionsModel", name, model )
	player_manager.AddValidModel( name, model )
	
end

list.Set( "PlayerOptionsModel", "Borat Cosplayer", "models/panman/borat_cosplayer_09.mdl" )
player_manager.AddValidModel( "Borat Cosplayer", "models/panman/borat_cosplayer_09.mdl" )
player_manager.AddValidHands( "Borat Cosplayer", "models/panman/borat_vm.mdl", 0, "00000000" )



