-- "lua\\autorun\\gspace_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "GalaxySpace","models/player/gspace.mdl" )
player_manager.AddValidHands( "GalaxySpace","models/player/gspacea.mdl", 0, "0000000",true)

