-- "lua\\autorun\\artemius_scp106.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP 106", "models/artemius/scp/106/scp106.mdl" );
list.Set( "PlayerOptionsModel",  "SCP 106", 					"models/artemius/scp/106/scp106.mdl" )