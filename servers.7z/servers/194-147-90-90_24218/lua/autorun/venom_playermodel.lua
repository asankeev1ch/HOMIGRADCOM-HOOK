-- "lua\\autorun\\venom_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "Venom", "models/player/venom.mdl" )
player_manager.AddValidModel( "Venom", "models/player/venom.mdl" )
player_manager.AddValidHands( "Venom", "models/player/venom_hands.mdl",0 ,"00000000" )