-- "lua\\autorun\\detroitconnor.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile()
end

player_manager.AddValidModel("Detroit - Connor", "models/konnie/isa/detroit/connor.mdl")
player_manager.AddValidHands( "Detroit - Connor", "models/weapons/arms/v_arms_connor.mdl", 0, "00000000" )

local Category = "Detroit: Become Human"

local function AddNPC( t, class )
list.Set( "NPC", class or t.Class, t )
end

AddNPC( {
Name = "Connor",
Class = "npc_citizen",
Category = Category,
Model = "models/konnie/isa/detroit/connor_f.mdl",
KeyValues = { citizentype = CT_UNIQUE, SquadName = "detroitconnor_f" }
}, "npc_detroitconnornpc_f" )