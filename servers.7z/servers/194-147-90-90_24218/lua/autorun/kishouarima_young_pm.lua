-- "lua\\autorun\\kishouarima_young_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel("Young Arima Kisho","models/starnix/kishouarimayoung/kishouarima_young.mdl")
list.Set("PlayerOptionsModel","Young Arima Kisho","models/starnix/kishouarimayoung/kishouarima_young.mdl")