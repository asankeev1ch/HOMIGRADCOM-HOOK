-- "lua\\autorun\\artemius_janitor_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Janitor Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/human/janitor/janitor.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Janitor Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "Janitor Angry", 
				Class = "npc_combine",
				Model = "models/artemius/human/janitor/janitor.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Janitor Angry", NPC )

local Category = "SCP:CB NPC's"