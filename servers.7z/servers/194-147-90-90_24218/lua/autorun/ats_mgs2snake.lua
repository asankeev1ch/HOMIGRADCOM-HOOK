-- "lua\\autorun\\ats_mgs2snake.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Solid Snake (MGS2)", 		"models/ats/mgs2snake/mgs2snake.mdl" );
player_manager.AddValidHands( "Solid Snake (MGS2)", 	"models/ats/mgs2snake/mgs2snakearms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "Solid Snake (MGS2)", 	"models/ats/mgs2snake/mgs2snake.mdl" );