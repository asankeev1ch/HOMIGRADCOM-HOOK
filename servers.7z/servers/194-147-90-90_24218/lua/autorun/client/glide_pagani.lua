-- "lua\\autorun\\client\\glide_pagani.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "GlideCategories", "Slothvole", {
    name = "Slothvole",
	icon = "materials/glide/icons/car.png"
} )