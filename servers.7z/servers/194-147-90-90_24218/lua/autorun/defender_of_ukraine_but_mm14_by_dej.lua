-- "lua\\autorun\\defender_of_ukraine_but_mm14_by_dej.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "AFU Soldier MM14", "models/dejtriyev/mm14/ukrainian_soldier.mdl" )
player_manager.AddValidHands( "AFU Soldier MM14", "models/dejtriyev/mm14/ukrainian_soldier_hands.mdl", 0, "0000000" )

player_manager.AddValidModel( "AZOV Soldier MM14", "models/dejtriyev/mm14/side_groups/azov_soldier.mdl" )
player_manager.AddValidHands( "AZOV Soldier MM14", "models/dejtriyev/mm14/ukrainian_soldier_hands.mdl", 0, "0000000" )
