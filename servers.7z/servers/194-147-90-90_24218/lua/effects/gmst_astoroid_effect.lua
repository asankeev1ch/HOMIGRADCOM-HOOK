-- "lua\\effects\\gmst_astoroid_effect.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

	local loadedeffectrender = false
	local destroyallcurrenteffects = false
	local effects = {}
	local RandModels = {"models/props_wasteland/rockcliff01b.mdl","models/props_wasteland/rockcliff01c.mdl","models/props_wasteland/rockcliff01e.mdl","models/props_wasteland/rockcliff01f.mdl","models/props_wasteland/rockcliff01g.mdl","models/props_wasteland/rockcliff01j.mdl","models/props_wasteland/rockcliff01k.mdl","models/props_wasteland/rockgranite01a.mdl","models/props_wasteland/rockcliff05a.mdl","models/props_wasteland/rockcliff05b.mdl","models/props_wasteland/rockcliff05e.mdl","models/props_wasteland/rockcliff05f.mdl",}
	
function EFFECT:Init( data )
if loadedeffectrender == false then
	loadedeffectrender = true
hook.Add( "PostDrawTranslucentRenderables", "ee_rendercore_"..tostring( math.random( -99999999, 99999999 ) ), function( depth, skybox )
if skybox == true then return false end
for k,v in pairs( effects ) do if v.NewRender ~= nil then v:NewRender() end end
   end)
end

	self.Pos = data:GetStart()

while(Vector(self.Pos.x, self.Pos.y, 0):DistToSqr( Vector(data:GetStart().x, data:GetStart().y, 0) ) <= (data:GetRadius() *data:GetRadius()) and data:GetRadius() < data:GetScale()) do
	self.Pos = data:GetStart() +Vector( math.Rand( -(data:GetScale() /2), (data:GetScale() /2) ), math.Rand( -(data:GetScale() /2), (data:GetScale() /2) ), math.Rand( -(data:GetScale() /2), (data:GetScale() /2) ) )
end

	self.Velocity = Vector( math.floor(data:GetOrigin().x +0.5), math.floor(data:GetOrigin().y +0.5), math.floor(data:GetOrigin().z +0.5) ) *20
	self.AngVelocity = Angle( math.Rand( -360, 360 ), math.Rand( -360, 360 ), math.Rand( -360, 360 ) ) *math.Rand(0.0002, 0.002)
	self.Tint = math.random( 0, 80 ) /255
	self.Mdl = ClientsideModel( RandModels[math.random( 1, #RandModels )] )
	self.Ang = Angle( math.Rand( -360, 360 ), math.Rand( -360, 360 ), math.Rand( -360, 360 ) )
	
	self.CloseEffectIn = CurTime() +math.Rand( 12, 18 )
	self.StartEffectIn = CurTime()
	
	effects[tostring( math.Rand( -99999999, 99999999 ) )] = self
	
	self.Mdl:SetPos( self.Pos )
	self.Mdl:SetRenderMode( RENDERMODE_TRANSCOLOR )

end

function EFFECT:Think()
if ( CurTime() > self.CloseEffectIn ) or IsValid( self.Mdl ) == false or self.Pos == Vector( 0, 0, 0 ) then
if IsValid( self.Mdl ) == true then self.Mdl:Remove() end
return false
end	

	self.Pos = self.Pos +self.Velocity
	self.Ang = self.Ang +self.AngVelocity

self:NextThink( CurTime() +0.001 )
self:SetNextClientThink( CurTime() +0.001 )
return true
end

function EFFECT:Render() end
function EFFECT:NewRender()
if IsValid( self.Mdl ) == false then return end

	local lifespan = 1 -( ( CurTime() -self.StartEffectIn ) /( self.CloseEffectIn -self.StartEffectIn ) )

self.Mdl:SetPos( self.Pos )
self.Mdl:SetAngles( self.Ang )
self.Mdl:SetColor( Color(self.Tint *255, self.Tint *255, self.Tint *255, lifespan *255) )
render.SetColorModulation( self.Tint, self.Tint, self.Tint )
render.SetBlend( lifespan )
self.Mdl:DrawModel()

end

