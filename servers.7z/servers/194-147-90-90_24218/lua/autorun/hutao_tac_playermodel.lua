-- "lua\\autorun\\hutao_tac_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Hu Tao Tac", "models/animeworld/hutao_tac.mdl" )
player_manager.AddValidHands( "Hu Tao Tac", "models/weapons/c_arms_hutao_tac.mdl", 0, "00000000" )