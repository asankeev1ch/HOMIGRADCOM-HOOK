-- "lua\\autorun\\gfl2_lenna_flying_phantom.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Girls Frontline 2 Lenna Flying Phantom (UMP9)", "models/player/gfl2_lenna_flying_phantom.mdl" )
player_manager.AddValidHands( "Girls Frontline 2 Lenna Flying Phantom (UMP9)", "models/arms/gfl2_lenna_flying_phantom_arms.mdl", 0, "00000000" )

local Category = "Girls Frontline 2"

local NPC =
{
	Name = "Lenna Flying Phantom (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/gfl2_lenna_flying_phantom_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_lenna_flying_phantom_friendly", NPC )

local NPC =
{
	Name = "Lenna Flying Phantom (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/gfl2_lenna_flying_phantom_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_lenna_flying_phantom_enemy", NPC )
