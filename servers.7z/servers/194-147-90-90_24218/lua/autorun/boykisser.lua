-- "lua\\autorun\\boykisser.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Boykisser",			"models/boykisser/boykisser.mdl" )
player_manager.AddValidHands( "Boykisser",			"models/boykisser/arms/boykisser_arms.mdl",0, "0000000" )

local Category = "Boykisser"
 
local NPC = {   Name = "Boykisser Friendly", 
                Class = "npc_citizen",
                Model = "models/boykisser/npc/boykisser_npc.mdl", 
                Health = "100", 
                KeyValues = { citizentype = 4 }, 
                Weapons = { "weapons_smg1" }, 
                Category = Category }
                               
list.Set( "NPC", "npc_boykisser_ally", NPC )

local Category = "Boykisser"
 
local NPC = {   Name = "Boykisser Hostile", 
                Class = "npc_combine",
                Model = "models/boykisser/npc/boykisser_npc.mdl", 
                Health = "100", 
                KeyValues = { citizentype = 4 }, 
                Weapons = { "weapons_smg1" }, 
                Category = Category }
                               
list.Set( "NPC", "npc_boykisser_hostile", NPC )
