-- "lua\\autorun\\hutao_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Hu Tao", "models/animeworld/hutao.mdl" )
player_manager.AddValidHands( "Hu Tao", "models/weapons/c_arms_hutao.mdl", 0, "00000000" )