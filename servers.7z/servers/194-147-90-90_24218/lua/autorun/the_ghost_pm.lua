-- "lua\\autorun\\the_ghost_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Ghostface (The Ghost)", 				"models/error/ghostface/the_ghost_pm.mdl" )
list.Set( "PlayerOptionsModel",  "Ghostface (The Ghost)",				"models/error/ghostface/the_ghost_pm.mdl" )
player_manager.AddValidHands( "Ghostface (The Ghost)", "models/error/ghostface/the_ghost_arms.mdl", 0, "00000000" )




