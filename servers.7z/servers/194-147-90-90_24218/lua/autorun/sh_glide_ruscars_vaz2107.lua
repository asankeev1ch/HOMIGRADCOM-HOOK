-- "lua\\autorun\\sh_glide_ruscars_vaz2107.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if CLIENT then
    list.Set( "GlideCategories", "RUSCARS", {
        name = "Russian Cars",
        icon = "glide/icons/car.png"
    } )
end

if SERVER then
    resource.AddWorkshop( 3389795738 )
end

hook.Add( "InitPostEntity", "RUSCARS.GlideCheck", function()
    if Glide then
        return
    end

    timer.Simple( 5, function()

        local BASE_ADDON_NAME = "Glide // Styled's Vehicle Base"
        local SUB_ADDON_NAME = "Glide // Russian Cars: VAZ2107"

        local colorHighlight = Color( 255, 0, 0 )
        local colorText = Color( 255, 200, 200 )

        local function Print( ... )
            if SERVER then MsgC( ..., "\n" ) end
            if CLIENT then chat.AddText( ... ) end
        end

        Print(
            colorHighlight, SUB_ADDON_NAME,
            colorText, " is installed, but ",
            colorHighlight, BASE_ADDON_NAME,
            colorText, " is missing! Please install the base addon."
        )

    end )
end )
