-- "lua\\autorun\\disgustedcat.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
AddCSLuaFile()

--[[
Follow this template to add playermodels to the picker and make the hands work.
You need to make sure that the playermodels are downloaded on the client as well (i.e. FastDL or Workshop Download).
This is the template:
player_manager.AddValidModel( "<name>", "<player model path>" )
player_manager.AddValidHands( "<name>", "models/weapons/c_arms_cstrike.mdl", 0, "10000000" )
]]--

player_manager.AddValidModel( "Disgusted Cat", "models/disgustedcat/disgustedcat.mdl" )
player_manager.AddValidHands( "Disgusted Cat", "models/disgustedcat/disgustedcat_arms.mdl", 0, "10000000" )  