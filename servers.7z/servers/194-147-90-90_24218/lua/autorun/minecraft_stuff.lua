-- "lua\\autorun\\minecraft_stuff.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

-- game.AddParticles( "particles/minecraft.pcf" )

-- PrecacheParticleSystem( "mc_fuse" )
-- PrecacheParticleSystem( "mc_explosion" )
-- PrecacheParticleSystem( "mc_explosion2" )
-- PrecacheParticleSystem( "mc_explosion3" )
-- PrecacheParticleSystem( "mc_torch" )
-- PrecacheParticleSystem( "mc_spawner" )

-- player_manager.AddValidModel( "mob", "models/MCModelPack/mobs/mob.mdl" );

-- list.Set( "EffectType", "splosion", 
-- {
	-- print		= "Minecraft explosion",
	-- material	= "gui/effects/smoke.png",
	-- func		= function( ent, pos, angle )
		-- ParticleEffect( "mc_fuse", pos, Angle(0,0,0), ent )
	-- end
-- })
-- list.Set( "EffectType", "splosion2", 
-- {
	-- print		=	"Minecraft explosion2",
	-- material	=	"gui/effects/smoke.png",
	-- func		=	function( ent, pos, angle )
		-- local effectdata = EffectData()
			-- effectdata:SetOrigin( pos )
		-- util.Effect( "mc-explosion", effectdata, true, true )
		-- ParticleEffect( "mc_explosion3", pos, Angle(0,0,0), ent )
	-- end
-- })

local Category = "Minecraft"

local V = { 	
			Name		= "Minecart", 
			Class		= "prop_vehicle_prisoner_pod",
			Category	= Category,

			Author		= "Dj Lukis.LT",
			Information	= "Sittable Minecart!",
			Model		= "models/MCModelPack/entities/minecart-empty.mdl",
			KeyValues	= {
				vehiclescript	=	"scripts/vehicles/prisoner_pod.txt",
				limitview		=	"0"
			}
}
list.Set( "Vehicles", "mc_minecart", V )
local V = { 	
			Name		= "Boat", 
			Class		= "prop_vehicle_prisoner_pod",
			Category	= Category,

			Author		= "Dj Lukis.LT",
			Information	= "Sittable Boat!",
			Model		= "models/MCModelPack/entities/boat.mdl",
			KeyValues	= {
				vehiclescript	=	"scripts/vehicles/prisoner_pod.txt",
				limitview		=	"0"
			}
}
list.Set( "Vehicles", "mc_boat", V )	

local NPC = {
			Name		= "Steve(rebel AI)",
			Class		= "npc_citizen",
			Model		= "models/MCModelPack/mobs/mob.mdl",
			Category	= "Minecraft",
			Information	= "Steve that uses rebel AI from HL2. Mainly folows you around.",
			KeyValues	= { citizentype = 4 }
}
list.Set( "NPC", "npc_steve", NPC )	
-- local NPC2 = {
			-- Name		= "Steve(combine AI)",
			-- Class		= "npc_combine",
			-- Model		= "models/MCModelPack/mobs/mob.mdl",
			-- Category	= "Minecraft",
-- }
-- list.Set( "NPC", "npc_mob2", NPC2 )	