-- "lua\\autorun\\dokibird.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Dokibird (Chibi)", "models/cypo/dokibird/dokibird_pm.mdl" )
player_manager.AddValidHands( "Dokibird (Chibi)", "models/cypo/dokibird/dokibird_carms.mdl" )