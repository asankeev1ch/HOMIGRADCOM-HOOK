-- "lua\\autorun\\gfl2_vector.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add Playermodel
player_manager.AddValidModel( "Girls Frontline 2 Vector (KRISS Vector)", "models/player/gfl2_vector.mdl" )
player_manager.AddValidHands( "Girls Frontline 2 Vector (KRISS Vector)", "models/arms/gfl2_vector_arms.mdl", 0, "00000000" )

local Category = "Girls Frontline 2"

local NPC =
{
	Name = "Vector (Friendly)",
	Class = "npc_citizen",
	KeyValues = { citizentype = 4 },
	Model = "models/npc/gfl2_vector_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_vector_friendly", NPC )

local NPC =
{
	Name = "Vector (Enemy)",
	Class = "npc_combine_s",
	Numgrenades = "4",
	Model = "models/npc/gfl2_vector_npc.mdl",
	Category = Category
}

list.Set( "NPC", "gfl2_vector_enemy", NPC )
