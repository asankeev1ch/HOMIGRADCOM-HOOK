-- "lua\\autorun\\boog.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal




player_manager.AddValidModel( "boog",     "models/player/open season/boog.mdl" );
list.Set( "PlayerOptionsModel", "boog",   "models/player/open season/boog.mdl" );