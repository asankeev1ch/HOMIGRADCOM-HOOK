-- "lua\\autorun\\santa_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Bad Santa", "models/player/santa/santa.mdl" );
list.Set( "PlayerOptionsModel",  "Bad Santa", 					"models/player/santa/santa.mdl" )
