-- "lua\\autorun\\hank_schrader_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Hank Schrader", "models/breaking_bad/hank_schrader.mdl" )
list.Set( "PlayerOptionsModel",  "Hank Schrader", "models/breaking_bad/hank_schrader.mdl" )