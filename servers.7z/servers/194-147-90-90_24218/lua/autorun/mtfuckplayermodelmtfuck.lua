-- "lua\\autorun\\mtfuckplayermodelmtfuck.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

player_manager.AddValidModel( "MT Foxtrot",		"models/player/MT_foxtrot.mdl" )
player_manager.AddValidHands( "MT Foxtrot",		"models/weapons/MT_fuck_c.mdl",		0, "0000000" )

player_manager.AddValidModel( "MT Foxtrot LIFE",		"models/player/MT_foxtrot_life.mdl" )
player_manager.AddValidHands( "MT Foxtrot LIFE",		"models/weapons/MT_fuck_c_life.mdl",		0, "0000000" )