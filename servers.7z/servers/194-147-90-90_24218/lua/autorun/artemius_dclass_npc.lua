-- "lua\\autorun\\artemius_dclass_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "D - Class Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/human/dclass/dclass.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "D - Class Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "D - Class Angry", 
				Class = "npc_combine",
				Model = "models/artemius/human/dclass/dclass.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "D - Class Angry", NPC )

local Category = "SCP:CB NPC's"