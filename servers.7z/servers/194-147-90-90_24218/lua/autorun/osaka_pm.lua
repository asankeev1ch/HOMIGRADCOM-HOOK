-- "lua\\autorun\\osaka_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Osaka", "models/player/Osaka_pm/Osaka_pm.mdl" );
player_manager.AddValidHands( "Osaka", "models/viewmodel/osaka_arms/osaka_arms.mdl", 1, "00000000" )
list.Set( "PlayerOptionsModel", "Osaka", "models/player/Osaka_pm/Osaka_pm.mdl" );