-- "lua\\autorun\\lifesphere_v2.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
game.AddParticles( "particles/ls_lifesphere_v2.pcf" )
game.AddParticles( "particles/mv_starlight2.pcf" )

if SERVER then
  	resource.AddWorkshop( "3491005613" )
end