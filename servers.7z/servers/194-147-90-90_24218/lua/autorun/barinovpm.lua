-- "lua\\autorun\\barinovpm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Barinov", "models/kuhnya/barinov.mdl" )
player_manager.AddValidHands( "Barinov", "models/weapons/c_arms_citizen.mdl", 0, "00000000" )
