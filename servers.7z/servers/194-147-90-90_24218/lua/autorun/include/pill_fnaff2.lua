-- "lua\\autorun\\include\\pill_fnaff2.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
﻿AddCSLuaFile()

shadow_freddyability = CreateConVar( "shadow_fades_shadows", "1", FCVAR_NOTIFY, "Noclip." )

pk_pills.packStart("FUPPR 2 WE","FUPPR 2 WE","icon/fnafur2we.png")

pk_pills.register("pill_wfreddy2",{
	printName="Withered Freddy",
	model="models/speps/pill/oldfreddy.mdl",
	crab="pill_wdefreddy2",
	bodyGroups={0},
	anims={
		default={
			idle="idle",
			crouch="stand",
			crouch_walk="walk2",
			walk="walk",
			run="run",
			cloak="special",
			teleport="zombie_leap_mid",
		},
	},
	moveSpeed={
		walk=150,
		run=400,
		ducked=80,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		laugh={"fnaf2/giggling1.wav",
			   "fnaf2/giggling2.wav",
			   "fnaf2/giggling3.wav"},
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwfreddy_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	
	attack2={
		mode="trigger",
		func = function(ply,ent)
			ent:PillSound("laugh")
		ent:PillAnim("cloak",true)
		end
	},

	noragdoll=true,
	reload=function(ply,ent)
	timer.Simple(0,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,ent.formTable.printName=="Withered Freddy" and "pill_wdefreddy2")
			e:PillAnim("deact",true)
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})










pk_pills.register("pill_wdefreddy2",{
	model="models/speps/pill/oldfreddy.mdl",
	parent="pill_wfreddy2",
	crab="pill_wdefreddy2",
	bodyGroups={},
	anims={
		default={
			idle="idledeactiv",
			deact="deactiv",
			act="activ",
		},
	},
	moveSpeed={
		walk=1,
		run=1,
		ducked=1,
	},

	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
				
	attack2={

	},	
	noragdoll=true,
	reload=function(ply,ent)
		ent:PillAnim("act",true)
	
		timer.Simple(17,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,"pill_wfreddy2")
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,

		
	flashlight=function(ply,ent)
	end,
	jump=function(ply,ent)
	end
	
})












--bonnie









pk_pills.register("pill_wbonnie2",{
	printName="Withered Bonnie",
	model="models/speps/pill/oldbonnie.mdl",
	crab="pill_wdebonnie2",
	anims={
		default={
			idle="idle",
			crouch="crouch",
			crouch_walk="crouchmove",
			walk="walk",
			run="run",
			cloak="special",
			teleport="zombie_leap_mid",
		},
	},
	moveSpeed={
		walk=90,
		run=320,
		ducked=50,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		scream="fnaf2/bonniescream.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwbonnie_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	
	attack2={
		mode="trigger",
		func = function(ply,ent)
			ent:PillSound("scream")
			ent:PillAnim("cloak",true)
		end
	},

	
	noragdoll=true,
	reload=function(ply,ent)
	timer.Simple(0,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,ent.formTable.printName=="Withered Bonnie" and "pill_wdebonnie2")
			e:PillAnim("deact",true)
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})










pk_pills.register("pill_wdebonnie2",{
	model="models/speps/pill/oldbonnie.mdl",
	parent="pill_wbonnie2",
	crab="pill_wdebonnie2",
	anims={
		default={
			idle="idledeactiv",
			deact="deactiv",
			act="activ",
		},
	},
	moveSpeed={
		walk=1,
		run=1,
		ducked=1,
	},

	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
				
	attack2={

	},	
	noragdoll=true,
	reload=function(ply,ent)
		ent:PillAnim("act",true)
	
		timer.Simple(5,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,"pill_wbonnie2")
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
		
	flashlight=function(ply,ent)
	end,
	jump=function(ply,ent)
	end
	
})






--chica





pk_pills.register("pill_wchica2",{
	printName="Withered Chica",
	model="models/speps/pill/oldchica.mdl",
	crab="pill_wdechica2",
	anims={
		default={
			idle="idle",
			crouch="crouch",
			crouch_walk="crouchmove",
			walk="walk",
			run="run",
			cloak="special1",
			teleport="zombie_leap_mid",
		},
	},
	moveSpeed={
		walk=80,
		run=370,
		ducked=50,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
	//	scream="fnaf2/bonniescream.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},
    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
 attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwchica_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	
	attack2={
		mode="trigger",
		func = function(ply,ent)
			ent:PillSound("scream")
			ent:PillAnim("cloak",true)
		end
	},
	
	noragdoll=true,
	reload=function(ply,ent)
	timer.Simple(0,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,ent.formTable.printName=="Withered Chica" and "pill_wdechica2")
			e:PillAnim("deact",true)
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})

















pk_pills.register("pill_wdechica2",{
	model="models/speps/pill/oldchica.mdl",
	parent="pill_wchica2",
	crab="pill_wdechica2",
	anims={
		default={
			idle="idledeactiv",
			deact="deactiv",
			act="activ",
		},
	},
	moveSpeed={
		walk=1,
		run=1,
		ducked=1,
	},

	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
				
	attack2={

	},	
	noragdoll=true,
	reload=function(ply,ent)
		ent:PillAnim("act",true)
	
		timer.Simple(7.2,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,"pill_wchica2")
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
		
	flashlight=function(ply,ent)
	end,
	jump=function(ply,ent)
	end
	
})









--foxy








pk_pills.register("pill_wfoxy2",{
	printName="Withered Foxy",
	model="models/speps/pill/oldfoxy.mdl",
	crab="pill_wdefoxy2",
	bodyGroups={0},
	anims={
		default={
			idle="idle",
			crouch="idle2",
			crouch_walk="walk2",
			walk="walk",
			jump="jump",
			glide="air",
			run="run",
			cloak="special1",
			teleport="zombie_leap_mid",
		},
	},
	moveSpeed={
		walk=150,
		run=600,
		ducked=70,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/xscream2.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		scream="fnaf2/foxyflashed.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},
    jumpPower=400,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,

	noFallDamage=true,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwfoxy_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	
	attack2={
		mode="trigger",
		func = function(ply,ent)
			ent:PillSound("scream")
			ent:PillAnim("cloak",true)
		end
	},

		
	noragdoll=true,
	reload=function(ply,ent)
	timer.Simple(0,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,ent.formTable.printName=="Withered Foxy" and "pill_wdefoxy2")
			e:PillAnim("deact",true)
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})















pk_pills.register("pill_wdefoxy2",{
	model="models/speps/pill/oldfoxy.mdl",
	parent="pill_wfoxy2",
	crab="pill_wdefoxy2",
	bodyGroups={},
	anims={
		default={
			idle="idledeactiv",
			deact="deactiv",
			act="activ",
		},
	},
	moveSpeed={
		walk=1,
		run=1,
		ducked=1,
	},

	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
		
	attack2={

	},	
	noragdoll=true,
	reload=function(ply,ent)
		ent:PillAnim("act",true)
	
		timer.Simple(5.5,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,"pill_wfoxy2")
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,

		
	flashlight=function(ply,ent)
	end,
	jump=function(ply,ent)
	end
	
})











--goldy












pk_pills.register("pill_wgfreddy2",{
	printName="Withered Golden Freddy",
	model="models/speps/pill/oldgoldenfreddy.mdl",
	crab="pill_wgfreddyhead2",
	bodyGroups={0},
	anims={
		default={
			idle="idle",
			crouch="sit",
			walk="walk",
			run="run",
			out="sdpecial",
			inn="tonormal",
			teleport="zombie_leap_mid",
		},
	},

	moveSpeed={
		walk=130,
		run=500,
		ducked=0,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/wgfreddy_laugh.wav",
		scream="fnaf2/bonniescream.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},
	cloak={
		max=-1
	},
    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,

	noFallDamage=true,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwgfreddy_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },

	attack2={
		mode="trigger",
		func = function(ply,ent)
			if !ply:OnGround() then return end

//			ent:PillAnim("cloak",true)

			timer.Simple(0,function()
				if !IsValid(ent) then return end
				ent:ToggleCloak()
			end)
/*
			if ent.cloaked then
				ent.cloaked=nil

				timer.Simple(1,function()
					if !IsValid(ent) then return end
					ent:PillSound("cloak")
					ent:GetPuppet():SetMaterial()
					ent:GetPuppet():DrawShadow(true)
					pk_pills.setAiTeam(ply,"default")
				end)
			else
				ent.cloaked=true

				timer.Simple(0.88,function()
					if !IsValid(ent) or !IsValid(ent:GetPuppet()) then return end
					ent:PillSound("cloak")
					ent:GetPuppet():SetMaterial("Models/effects/vol_light001")
					ent:GetPuppet():DrawShadow(false)
					pk_pills.setAiTeam(ply,"harmless")
				end)
			end*/
		end
	},

	flashlight=function(ply,ent)
		if !ply:OnGround() then return end
		
	//	ent:PillAnim("teleport",true)

		timer.Simple(.1,function()
			if !IsValid(ent) then return end
			local tracein={}
			tracein.maxs=Vector(16,16,72)
			tracein.mins=Vector(-16,-16,0)
			tracein.start=ply:EyePos()
			tracein.endpos=ply:EyePos()+ply:EyeAngles():Forward()*9999
			tracein.filter = {ply,ent,ent:GetPuppet()}

			local traceout= util.TraceHull(tracein)
			ply:SetPos(traceout.HitPos)
			ent:PillSound("teleport")
		end)
	end,
	
	noragdoll=true,
reload=function(ply,ent)
		ent:PillAnim("out",true)
	
		timer.Simple(0.9,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,ent.formTable.printName=="Withered Golden Freddy" and "pill_wgfreddyhead2")
			e:PillAnim("inn",true)
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,

	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})





































pk_pills.register("pill_wgfreddyhead2",{
	printName="Withered Golden Freddy Head",
	model="models/speps/pill/oldgoldenfreddyhead.mdl",
	crab="pill_wgfreddy2",
	bodyGroups={0},
	anims={
		default={
			idle="idle",
			crouch="crouch",
			walk="walk",
			out="special",
			inn="tohead",
			run="run",
			teleport="zombie_leap_mid",
		},
	},
	modelScale="2.5",
	moveSpeed={
		walk=300,
		run=1000,
		ducked=0,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs={"fnaf2/wgfreddy_glitchsound.wav",
		"fnaf2/wgfreddy_glitchsound2.wav"},
		scream="fnaf2/bonniescream.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},
	cloak={
		max=-1
	},
    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
	noFallDamage=true,	
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwgfreddyhead_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },

	attack2={
		mode="trigger",
		func = function(ply,ent)
			if !ply:OnGround() then return end

//			ent:PillAnim("cloak",true)

			timer.Simple(0,function()
				if !IsValid(ent) then return end
				ent:ToggleCloak()
			end)
/*
			if ent.cloaked then
				ent.cloaked=nil

				timer.Simple(1,function()
					if !IsValid(ent) then return end
					ent:PillSound("cloak")
					ent:GetPuppet():SetMaterial()
					ent:GetPuppet():DrawShadow(true)
					pk_pills.setAiTeam(ply,"default")
				end)
			else
				ent.cloaked=true

				timer.Simple(1,function()
					if !IsValid(ent) or !IsValid(ent:GetPuppet()) then return end
					ent:PillSound("cloak")
					ent:GetPuppet():SetMaterial("Models/effects/vol_light001")
					ent:GetPuppet():DrawShadow(false)
					pk_pills.setAiTeam(ply,"harmless")
				end)
			end*/
		end
	},

	
	noragdoll=true,
reload=function(ply,ent)
		ent:PillAnim("out",true)
	
		timer.Simple(0.6,function()
			if !IsValid(ent) then return end


			pk_pills.apply(ply,ent.formTable.crab)
			local e = pk_pills.apply(ply,ent.formTable.printName=="Withered Golden Freddy Head" and "pill_wgfreddy2")
			e:PillAnim("inn",true)
			if (attach) then
				ply:SetPos(attach.Pos)
			end
		end)
	end,
	

	flashlight=function(ply,ent)
		if !ply:OnGround() then return end
		
	//	ent:PillAnim("teleport",true)

		timer.Simple(.1,function()
			if !IsValid(ent) then return end
			local tracein={}
			tracein.maxs=Vector(16,16,72)
			tracein.mins=Vector(-16,-16,0)
			tracein.start=ply:EyePos()
			tracein.endpos=ply:EyePos()+ply:EyeAngles():Forward()*9999
			tracein.filter = {ply,ent,ent:GetPuppet()}

			local traceout= util.TraceHull(tracein)
			ply:SetPos(traceout.HitPos)
			ent:PillSound("teleport")
		end)
	end,
	
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})














--shadow











pk_pills.register("pill_sfreddy2",{
	printName="Shadow Freddy",
	model="models/speps/pill/oldgoldenfreddy.mdl",

options=function() return {
{skin=1}
}end,
	bodyGroups={12},
	anims={

		default={
			idle="sidle",
			crouch="ssit",
			walk="swalk",
			cloak="sdisappear",
			uncloak="sappear",
			run="srun",
			teleport="zombie_leap_mid",
		},
	},
	moveSpeed={
		walk=80,
		run=420,
		ducked=0,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/shfreddy_laugh.wav",
		stare={"fnaf2/garble1.wav",
		"fnaf2/garble2.wav",
		"fnaf2/garble3.wav"},
	//	scream="fnaf2/bonniescream.wav",
		melee=pk_pills.helpers.makeList("fnaf2/sxscream.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},
	cloak={
		max=-1
	},
    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,

	noFallDamage=true,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penksfreddy_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	 
	attack2={
		mode="trigger",
		func = function(ply,ent)
	//		if !ply:OnGround() then return end

//			ent:PillAnim("cloak",true)

	/*		timer.Simple(1,function()
				if !IsValid(ent) then return end
				ent:ToggleCloak()
			end)*/
			if !ply:KeyDown(IN_USE) then
			
			if ent.cloaked then
			//	ent.cloaked=nil
ent.cloaked=false

ent:ToggleCloak()
					
					timer.Simple(1,function()
					ent:PillSound("teleport")
					end)
					
       timer.Remove("ext")
				timer.Simple(0.1,function()
					if !IsValid(ent) then return end
					timer.Simple(0,function()
	
					
					if shadow_freddyability:GetInt() == 1 then
					timer.Simple(0.4,function()
					ply:SetMoveType( MOVETYPE_WALK )
					end)
					end
					ent:PillAnim("uncloak")
					
					pk_pills.setAiTeam(ply,"default")
					ent:GetPuppet():SetMaterial()
					
					ply:SetNotSolid( false )
	                ent:GetPuppet():SetNotSolid( false )
					ply:SetNoDraw( false )
					ent:GetPuppet():SetNoDraw( false )
					
					ent:GetPuppet():SetModel("models/speps/pill/oldgoldenfreddy.mdl")
					ent:GetPuppet():DrawShadow(true)
					end)
					
					
				end)
			else
				
				timer.Simple(0,function()
					if !IsValid(ent) or !IsValid(ent:GetPuppet()) then return end
					//timer.Simple(0.2,function()
					ent:PillSound("")
					//end)
					ent:PillAnim("cloak")
					timer.Create( "ext", 0.2, 0, function() 
					if ply:Health() < 1000 then ply:SetHealth(ply:Health()+1) end
					if ent:IsOnFire() then ent:Extinguish() end
					if ply:IsOnFire() then ply:Extinguish() end
					end)
					
					if shadow_freddyability:GetInt() == 1 then
					timer.Simple(0.65,function()
				ply:SetMoveType( MOVETYPE_NOCLIP )
					end)
					end
					
					timer.Simple(0.65,function()
					ent.cloaked=true
					ent:GetPuppet():SetMaterial("Models/effects/vol_light001")
					ent:GetPuppet():SetModel("models/Items/AR2_Grenade.mdl")
					ent:GetPuppet():DrawShadow(false)
					ply:SetNotSolid( true )
				    ent:GetPuppet():SetNotSolid( true )
					ply:SetNoDraw( true )
					ent:GetPuppet():SetNoDraw( true )
					
				ent:ToggleCloak()
					end)
					
					pk_pills.setAiTeam(ply,"harmless")
				end)
			end
			
			elseif ent.cloaked then
			
			ply:EmitSound( "" )
			
			end
			
			
			
		end
	},
 
 
	noragdoll=true,
	reload=function(ply,ent)
		if !ply:OnGround() then return end
		
	//	ent:PillAnim("teleport",true)

		timer.Simple(.1,function()
			if !IsValid(ent) then return end
			local tracein={}
			tracein.maxs=Vector(16,16,72)
			tracein.mins=Vector(-16,-16,0)
			tracein.start=ply:EyePos()
			tracein.endpos=ply:EyePos()+ply:EyeAngles():Forward()*9999
			tracein.filter = {ply,ent,ent:GetPuppet()}

			local traceout= util.TraceHull(tracein)
			ply:SetPos(traceout.HitPos)
			ent:PillSound("teleport")
		end)
	end,
	
	flashlight=function(ply,ent)
		ent:PillSound("stare")
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})








--endo








pk_pills.register("pill_endo02",{
	printName="Endo02",
	model="models/speps/pill/endo02.mdl",
	anims={
		default={
			idle="idle",
			crouch="crouch",
			crouch_walk="movecrouch",
			walk="walk",
			run="run",
			cloak="special",
			teleport="zombie_leap_mid",
		},
	},
	moveSpeed={
		walk=120,
		run=600,
		ducked=200,
	},
	sounds={
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
	//	scream="fnaf2/bonniescream.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},
    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkendo02_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	
	attack2={
		mode="trigger",
		func = function(ply,ent)
			ent:PillAnim("cloak",true)
		end
	},

	
	noragdoll=true,

	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})







--withered toys


pk_pills.register("pill_wtfreddy2",{
	printName="Withered Toy Freddy",
	model="models/speps/pill/withered_toy_freddy.mdl",
	bodyGroups={0},
	modelScale="4",
	anims={
		default={
			idle="idle",
			crouch="idle2",
			crouch_walk="walk2",
			walk="walk",
			run="run",
		},
	},
	moveSpeed={
		walk=57,
		run=250,
		ducked=40,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		laugh={"fnaf2/giggling1.wav",
			   "fnaf2/giggling2.wav",
			   "fnaf2/giggling3.wav"},
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwtfreddy_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	


	noragdoll=true,

	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})








pk_pills.register("pill_wtbonnie2",{
	printName="Withered Toy Bonnie",
	model="models/speps/pill/withered_toy_bonnie.mdl",
	modelScale="6.4",
	anims={
		default={
			idle="idle",
			crouch="idle2",
			crouch_walk="walk2",
			walk="walk",
			run="run",
		},
	},
	moveSpeed={
		walk=47,
		run=300,
		ducked=38,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		laugh={"fnaf2/giggling1.wav",
			   "fnaf2/giggling2.wav",
			   "fnaf2/giggling3.wav"},
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
 attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwtbonnie_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	


	noragdoll=true,

	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})








pk_pills.register("pill_wtchica2",{
	printName="Withered Toy Chica",
	model="models/speps/pill/withered_toy_chica.mdl",
	modelScale="4.4",
	anims={
		default={
			idle="idle",
			crouch="idle2",
			crouch_walk="walk2",
			walk="walk",
			run="run",
		},
	},
	moveSpeed={
		walk=110,
		run=400,
		ducked=50,
	},
	sounds={
	//	teleport="legitfreddy/laugh_giggle_girl_1d.wav",
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwtchica_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	


	noragdoll=true,

	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})










pk_pills.register("pill_wpuppet2",{
	printName="Withered Puppet",
	model="models/speps/pill/withered_puppet.mdl",
	bodyGroups={1},
	modelScale="3.2",
	anims={
		default={
			idle="idle",
			crouch="idle2",
			crouch_walk="walk2",
			walk="walk",
			run="run",
		},
	},
	moveSpeed={
		walk=45,
		run=450,
		ducked=43,
	},
	sounds={
		gs="fnaf2/stareshort.wav",
		loop_stare="fnaf2/with_s2_loop2.wav",
		melee=pk_pills.helpers.makeList("fnaf2/xscream2.wav",2),
		step=pk_pills.helpers.makeList("fnaf2/none.wav",1)
	},
	type="ply",
	camera={
		dist=200
	},

    jumpPower=0,
	health=10000,
	movePoseMode="xy",
		aim={
		xPose="aim_yaw",
		yPose="aim_pitch"
	},
	canAim=function(ply,ent)
		return ent.active
	end,
	
attack={
		mode="trigger",
		func=function(ply,ent)
		for k, v in pairs ( ents.FindInSphere( ent:GetPos(), 250 ) ) do
			if v ~= ply and v:Health() > 0 then
				if v:IsPlayer() or v:IsNPC() then
					if !IsValid(v) then return end
					v:TakeDamage(99999, ply)
					ent:PillSound("melee")
					if v:IsNPC() then
						timer.Simple( 1.5, function()
							if !IsValid(ent) then return end
							v:EmitSound( "legitfreddy/static.wav" )
						end)
					return end
					v:ConCommand( "pp_mat_overlay overlays/penkwpuppet_jumpscare" )

					timer.Simple( 1.5, function()
						if !IsValid(v) then return end
						v:EmitSound( "legitfreddy/static.wav" )
						v:ConCommand( "pp_mat_overlay overlays/fivenights_static/static2" )
						timer.Simple( 2, function()
							if !IsValid(v) then return end
							v:ConCommand( "pp_mat_overlay " )
						end)
					end)
				end
			end
		end
	end
    },
	


	noragdoll=true,

	
	flashlight=function(ply,ent)
			if !ent.blades then
				ent:PillLoopSound("stare")
			else
				ent:PillLoopStop("stare")
			end

			ent.blades=!ent.blades	
	end,
	jump=function(ply,ent)
		ent:PillSound("gs")
	end
})
