-- "lua\\autorun\\ukon_nuj02_ori_armsmodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	AddCSLuaFile()
end

player_manager.AddValidHands( "[Tactics] UKON.", "models/nuj02/ori/realistic/tactical anime/arms/[tac]ukon_arms.mdl", 0, "00000000" )

hook.Add("PreDrawPlayerHands", "[Tactics] UKON.", function(hands, vm, ply, wpn)
    if IsValid(hands) 
	and hands:GetModel() == "models/nuj02/ori/realistic/tactical anime/arms/[tac]ukon_arms.mdl" 
	then
        hands:SetBodygroup(1, (ply:GetBodygroup(27)) )
		hands:SetBodygroup(2, (ply:GetBodygroup(28)) )
    end
end)