-- "lua\\weapons\\weapon_dalgonacircle.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
    AddCSLuaFile()
end

SWEP.Base = "weapon_base"
SWEP.Category = "Squid Game"
SWEP.PrintName = "Dalgona: Circle"
SWEP.Author = "Binger"
SWEP.Instructions = "LMB to start cutting"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.UseHands = true

SWEP.ViewModel = "models/squidgame/dalgona/v_circle.mdl"
SWEP.WorldModel = "models/squidgame/dalgona/circle.mdl"
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"
SWEP.ViewModelFOV = 85

function SWEP:Initialize()
	self:SetHoldType( "slam" )
end

local viewangles = Angle(0,0,20)

function SWEP:GetViewModelPosition(pos, ang)
    pos = pos + ang:Up() * 4
    ang = ang + viewangles
    return pos, ang
end

function SWEP:DrawWorldModel()
    local owner = self:GetOwner()
    if IsValid(owner) then
        local boneIndex = owner:LookupBone("ValveBiped.Bip01_R_Hand")
        if boneIndex then
            local pos, ang = owner:GetBonePosition(boneIndex)

            pos = pos + ang:Forward() * 5 -- Вперёд
            pos = pos + ang:Right() * 5 -- Вбок
            pos = pos + ang:Up() * -3 -- Вниз

            -- Поворот модели
            ang:RotateAroundAxis(ang:Right(), 90)
            ang:RotateAroundAxis(ang:Up(), -30)
            ang:RotateAroundAxis(ang:Forward(), 0)

            self:SetRenderOrigin(pos)
            self:SetRenderAngles(ang)
            self:DrawModel()
            return
        end
    end
    self:DrawModel() -- Если игрока нет, рисует стандартную модель
end

function SWEP:PrimaryAttack()
    if CLIENT then return end

    local owner = self:GetOwner()
    if IsValid( owner ) then
        net.Start("Dalgona_Open")
        net.WriteEntity( self )
        net.Send( owner )
    end
    
    self:SetNextPrimaryFire(CurTime() + 1)
end


function SWEP:SecondaryAttack()
    return false
end



local dalgona_classes = {
    ["weapon_dalgonatriangle"] = true,
    ["weapon_dalgonacircle"] = true,
    ["weapon_dalgonastar"] = true,
    ["weapon_dalgonaumbrella"] = true
}

local killOnFail = 0

concommand.Add("dalgona_killonfail", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then return end
    local newValue = tonumber(args[1]) or 0
    killOnFail = newValue
    print("Kill on fail is now set to", killOnFail)
end)


if SERVER then
    util.AddNetworkString("Dalgona_Destroy")
    util.AddNetworkString("Dalgona_Success")
    util.AddNetworkString("Dalgona_Open")
    
    local dalgona_classes = {
        ["weapon_dalgonatriangle"] = true,
        ["weapon_dalgonacircle"] = true,
        ["weapon_dalgonastar"] = true,
        ["weapon_dalgonaumbrella"] = true
    }

    net.Receive("Dalgona_Destroy", function(len, ply)
        if !IsValid( ply ) then return end
        local wep = ply:GetActiveWeapon()

        if !IsValid( wep ) then return end
        local wep_class = wep:GetClass()
        if dalgona_classes[ wep_class ] then
            if killOnFail == 1 then
                sound.Play("physics/flesh/flesh_bloody_break.wav", ply:GetPos(), 75, 100, 1)
                timer.Simple(2, function()
                    if IsValid(ply) then
                        sound.Play("weapons/357/357_fire2.wav", ply:GetPos(), 75, 100, 1)
                        ply:Kill()
                    end
                end)
            else
                sound.Play("physics/flesh/flesh_bloody_break.wav", ply:GetPos(), 75, 100, 1)
                wep:Remove()
            end
        end
    end)
    
    net.Receive("Dalgona_Success", function(len, ply)
        if !IsValid( ply ) then return end
        local wep = ply:GetActiveWeapon()

        if !IsValid( wep ) then return end
        local wep_class = wep:GetClass()
        if dalgona_classes[ wep_class ] then
            ply:StripWeapon( wep_class )
            ply:Give( wep_class.."done" )
        end
    end)
else
    local dalgona_panels = {
        ["weapon_dalgonatriangle"] = "DalgonaPanel_Triangle",
        ["weapon_dalgonastar"] = "DalgonaPanel_Star",
        ["weapon_dalgonacircle"] = "DalgonaPanel",
        ["weapon_dalgonaumbrella"] = "DalgonaPanel_Umbrella"
    }

    local DalgonaPanel
    net.Receive("Dalgona_Open", function()
        local ent = net.ReadEntity()
        if !IsValid( ent ) or !dalgona_panels[ ent:GetClass() ] then return end

        local ply = LocalPlayer()
        if !IsValid( ply ) then return end
        
        local wep = ply:GetActiveWeapon()
        if wep != ent then return end

        if IsValid( DalgonaPanel ) then return end
        DalgonaPanel = vgui.Create( dalgona_panels[ ent:GetClass() ] )
    end)
end


if CLIENT then


    local function DrawThickCutLine(x1, y1, x2, y2, thickness)
        local dx = x2 - x1
        local dy = y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len == 0 then return end
        local nx = dx / len
        local ny = dy / len
        local px = -ny
        local py = nx
        for offset = -thickness/2, thickness/2, 1 do
            local ox = px * offset
            local oy = py * offset
            surface.SetDrawColor(255, 0, 0, 255)
            surface.DrawLine(x1 + ox, y1 + oy, x2 + ox, y2 + oy)
        end
    end

    local PANEL = {}

    function PANEL:Init()
        self:SetSize(ScrW() * 0.9, ScrH() * 0.9)
        self:Center()
        self:MakePopup()

        LocalPlayer():ConCommand("+duck")

        self.cutLine = {}
        self.isCutting = false

        self.center = { x = self:GetWide() / 2, y = self:GetTall() / 2 }
        self.radius = math.min(self:GetWide(), self:GetTall()) / 2 - 100
        self.targetRadius = (self.radius * 0.8) / 1.5

        self.cookieMat = Material("squidgame/dalgona")

        self.distTolerance = 10
        self.totalSegments = 72
        self.angleGapTolerance = 40
    end

    function PANEL:OnRemove()
        if IsValid(LocalPlayer()) then
            LocalPlayer():ConCommand("-duck")
        end
    end

    function PANEL:CreateCircleVertices(cx, cy, radius, seg)
        seg = seg or 36
        local vertices = {}
        for i = 1, seg do
            local a = math.rad((i / seg) * 360)
            table.insert(vertices, {
                x = cx + math.cos(a) * radius,
                y = cy + math.sin(a) * radius,
                u = (math.cos(a) + 1) / 2,
                v = (math.sin(a) + 1) / 2
            })
        end
        return vertices
    end

    function PANEL:GetFilledSegments()
        local segs = self.totalSegments
        local delta = 360 / segs
        local filled = {}
        for i = 1, segs do
            filled[i] = false
        end
        local cx, cy = self.center.x, self.center.y
        for _, point in ipairs(self.cutLine) do
            local dx = point.x - cx
            local dy = point.y - cy
            local angle = math.deg(math.atan2(dy, dx))
            if angle < 0 then angle = angle + 360 end
            local segIndex = math.floor(angle / delta) + 1
            if segIndex < 1 then segIndex = 1 end
            if segIndex > segs then segIndex = segs end
            filled[segIndex] = true
        end
        return filled
    end

    function PANEL:DrawUpdatedContour()
        local segs = self.totalSegments
        local delta = 360 / segs
        local cx, cy = self.center.x, self.center.y
        local thickness = 8
        local filled = self:GetFilledSegments()
        for offset = -thickness/2, thickness/2, 1 do
            for i = 0, segs - 1 do
                local segColor = filled[i + 1] and Color(0, 255, 0, 255) or Color(0, 0, 0, 255)
                local prevX, prevY = nil, nil
                local steps = 10
                for j = 0, steps do
                    local a = math.rad(i * delta + (j / steps) * delta)
                    local r = self.targetRadius + offset
                    local x = cx + math.cos(a) * r
                    local y = cy + math.sin(a) * r
                    if prevX and prevY then
                        surface.SetDrawColor(segColor)
                        surface.DrawLine(prevX, prevY, x, y)
                    end
                    prevX, prevY = x, y
                end
            end
        end
    end

    function PANEL:Paint(w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30,200))
        local cx, cy = self.center.x, self.center.y
        local radius = self.radius

        local circleVerts = self:CreateCircleVertices(cx, cy, radius, 72)
        surface.SetMaterial(self.cookieMat)
        surface.SetDrawColor(255,255,255,255)
        surface.DrawPoly(circleVerts)

        local outlineVerts = self:CreateCircleVertices(cx, cy, radius, 72)
        surface.SetDrawColor(255,255,255,100)
        for i = 2, #outlineVerts do
            surface.DrawLine(outlineVerts[i-1].x, outlineVerts[i-1].y, outlineVerts[i].x, outlineVerts[i].y)
        end
        surface.DrawLine(outlineVerts[#outlineVerts].x, outlineVerts[#outlineVerts].y, outlineVerts[1].x, outlineVerts[1].y)

        self:DrawUpdatedContour()


        return true
    end

    function PANEL:OnMousePressed(mousecode)
        if mousecode == MOUSE_LEFT then
            local x, y = self:CursorPos()
            local cx, cy = self.center.x, self.center.y
            local dx = x - cx
            local dy = y - cy
            local dist = math.sqrt(dx * dx + dy * dy)
            if math.abs(dist - self.targetRadius) > self.distTolerance then
                self.cookieMat = Material("squidgame/dalgonadestroyed")
                net.Start("Dalgona_Destroy")
                net.SendToServer()
                timer.Simple(2, function() if IsValid(self) then self:Remove() end end)
                return
            end
            self.isCutting = true
            table.insert(self.cutLine, { x = x, y = y })
        end
    end

    function PANEL:OnMouseReleased(mousecode)
        if mousecode == MOUSE_LEFT then
            self.isCutting = false
            if #self.cutLine == 1 then
                local point = self.cutLine[1]
                local cx, cy = self.center.x, self.center.y
                local dx = point.x - cx
                local dy = point.y - cy
                local dist = math.sqrt(dx * dx + dy * dy)
                if math.abs(dist - self.targetRadius) > self.distTolerance then
                    self.cookieMat = Material("squidgame/dalgonadestroyed")
                    net.Start("Dalgona_Destroy")
                    net.SendToServer()
                    timer.Simple(2, function() if IsValid(self) then self:Remove() end end)
                end
            end
        end
    end

    function PANEL:OnCursorMoved(x, y)
        if self.isCutting then
            local cx, cy = self:CursorPos()
            local newPoint = { x = cx, y = cy }
            local dx = newPoint.x - self.center.x
            local dy = newPoint.y - self.center.y
            local dist = math.sqrt(dx * dx + dy * dy)
            if math.abs(dist - self.targetRadius) > self.distTolerance then
                self.isCutting = false
                self.cookieMat = Material("squidgame/dalgonadestroyed")
                net.Start("Dalgona_Destroy")
                net.SendToServer()
                timer.Simple(2, function() if IsValid(self) then self:Remove() end end)
                return
            end
            table.insert(self.cutLine, newPoint)
            local filled = self:GetFilledSegments()
            local allFilled = true
            for i = 1, self.totalSegments do
                if not filled[i] then
                    allFilled = false
                    break
                end
            end
            if allFilled then
                self.isCutting = false
                net.Start("Dalgona_Success")
                net.SendToServer()
                timer.Simple(2, function() if IsValid(self) then self:Remove() end end)
            end
        end
    end



    vgui.Register("DalgonaPanel", PANEL, "DPanel")
end