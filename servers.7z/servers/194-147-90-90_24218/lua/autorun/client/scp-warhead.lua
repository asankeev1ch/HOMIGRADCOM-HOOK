-- "lua\\autorun\\client\\scp-warhead.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
CreateClientConVar("scpwarhead_screenflash", "1", true, false, "Should the screen flash white when the warhead detonates")

local globalSound = nil

function SCPWarhead:ResetWarhead()
	if IsValid(globalSound) then globalSound:Stop() end
	timer.Destroy("SCPWARHEAD-COUNTDOWN")
end

function SCPWarhead:CancelDetonation()
	// this HAS to be set right away!
	SetGlobalInt("SCP-WARHEAD-STATUS", ENUM_SCPWARHEAD_CANCEL)
	if IsValid(globalSound) then globalSound:Stop() end
	sound.PlayFile( "sound/warhead-global/cancel.ogg", "mono", function( station )
		if ( IsValid( station ) ) then
			station:Play()
			globalSound = station
		end
	end)
	timer.Simple(0, function() // Allow netvar to get networked...
		timer.Destroy("SCPWARHEAD-COUNTDOWN")
	end)
end

local pSound 
function SCPWarhead:StartCountdown( time, first )
	if IsValid(globalSound) then globalSound:Stop() end
	if first then
		pSound = "sound/warhead-global/warhead-"..time..".ogg"
	else
		pSound = "sound/warhead-global/resume-"..time..".ogg"
	end
	sound.PlayFile( pSound, "mono", function( station )
		if ( IsValid( station ) ) then
			station:Play()
			globalSound = station
		end
	end)

	local offset = 10.85
	if not first then
		offset = 5.85
	end

	timer.Create("SCPWARHEAD-COUNTDOWN", time + offset, 1, function()
		self:DetonateWarhead()
		-- if pSound:IsPlaying() then return end
	end)
end

function SCPWarhead:DetonateWarhead( forced )
	if not GetConVar("scpwarhead_screenflash"):GetBool() then return end
	LocalPlayer():ScreenFade( SCREENFADE.IN, Color( 255, 255, 255, 255 ), 5, 3 )
end

net.Receive("SCPWARHEAD-NETWORKSTATE", function()
	local state = net.ReadInt(32)
	if state == ENUM_SCPWARHEAD_COUNTING then
		SCPWarhead:StartCountdown(net.ReadInt(32), net.ReadBool())
	elseif state == ENUM_SCPWARHEAD_CANCEL then
		SCPWarhead:CancelDetonation()
	elseif state == ENUM_SCPWARHEAD_DETONATED then
		SCPWarhead:DetonateWarhead()
	elseif state == ENUM_SCPWARHEAD_RESET then
		SCPWarhead:ResetWarhead()
	end
end)