-- "lua\\autorun\\artemius_scp096.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP 096", "models/artemius/scp/096/scp096.mdl" )

list.Set( "PlayerOptionsModel",  "SCP 096", "models/artemius/scp/096/scp096.mdl" )