-- "lua\\autorun\\hellmentor_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Hellmentor", "models/player/hellmentor.mdl" )
player_manager.AddValidHands( "Hellmentor", "models/weapons/c_arms_helldude.mdl", 0, "00000000" )