-- "lua\\autorun\\artemius_mog_e10_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "MOG E - 10 Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/human/mog_e10/mog_e10.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "MOG E - 10 Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "MOG E - 10 Angry", 
				Class = "npc_combine",
				Model = "models/artemius/human/mog_e10/mog_e10.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "MOG E - 10 Angry", NPC )

local Category = "SCP:CB NPC's"