-- "lua\\autorun\\splinks_jacket.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "Splinks_Jacket", "models/Splinks/Hotline_Miami/Jacket/Player_jacket.mdl" )
list.Set( "PlayerOptionsAnimations", "Splinks_Jacket", { "idle_suitcase", "pose_standing_01" } )
player_manager.AddValidModel( "Splinks_Jacket", "models/Splinks/Hotline_Miami/Jacket/Player_jacket.mdl" )
player_manager.AddValidHands( "Splinks_Jacket", "models/Splinks/Hotline_Miami/Jacket/Arms_jacket.mdl", 0, "00000000" )



--Add NPC
local Category = "Hotline Miami"

local NPC = { 	Name = "Hostile Jacket", 
				Class = "npc_combine_s",
				Model = "models/Splinks/Hotline_Miami/Jacket/Combine_jacket.mdl",
				Health = "150",
				Squadname = "PLAGUE",
				Numgrenades = "4",
                                Category = Category    }

list.Set( "NPC", "Hostile_Jacket", NPC )

local NPC = { 	Name = "Friendly Jacket", 
				Class = "npc_citizen",
				Model = "models/Splinks/Hotline_Miami/Jacket/Rebel_jacket.mdl",
				Health = "700",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "Friendly_Jacket", NPC )