-- "lua\\autorun\\linq_yangji.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "linq_american_soldier", "models/linqure/yangji/linq_american_soldier_pm.mdl" )
//player_manager.AddValidHands( "Amy (Bunny Suit)", "models/weapons/Amy_Bunny_Arms_New.mdl", 0, "00000000" )

local Category = "Soldier"

local NPC =
{
	Name = "american_soldier",
	Class = "npc_citizen",
	Health = "100",
	KeyValues = { citizentype = 4 },
	Model = "models/linqure/yangji/linq_american_soldier_npc.mdl",
	Category = Category
}

list.Set( "NPC", "linq_american_soldier", NPC )

local NPC =
{
	Name = "american_soldier_hostile",
	Class = "npc_combine_s",
	Health = "100",
	Numgrenades = "4",
	Model = "models/linqure/yangji/linq_american_soldier_npc.mdl",
	Category = Category
}

list.Set( "NPC", "linq_american_soldier_hostile", NPC )