-- "lua\\autorun\\zelenium.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Zelenium", "models/player/zelenium.mdl" )

