-- "lua\\autorun\\billy_herrington_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel",  "Billy Herrington", "models/vinrax/player/Billy_Herrington.mdl" )
player_manager.AddValidModel( "Billy Herrington", "models/vinrax/player/Billy_Herrington.mdl" );