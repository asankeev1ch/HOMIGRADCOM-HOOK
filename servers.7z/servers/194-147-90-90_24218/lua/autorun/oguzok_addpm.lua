-- "lua\\autorun\\oguzok_addpm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Oguzok", "models/player/oguzok.mdl" )