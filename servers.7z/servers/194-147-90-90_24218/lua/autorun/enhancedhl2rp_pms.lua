-- "lua\\autorun\\enhancedhl2rp_pms.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 01 (Van)", "models/player/pandafishizens/male_01.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 01 (Van)", "models/player/pandafishizens/male_01.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 02 (Ted)", "models/player/pandafishizens/male_02.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 02 (Ted)", "models/player/pandafishizens/male_02.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 03 (Joe)", "models/player/pandafishizens/male_03.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 03 (Joe)", "models/player/pandafishizens/male_03.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 04 (Eric)", "models/player/pandafishizens/male_04.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 04 (Eric)", "models/player/pandafishizens/male_04.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 05 (Art)", "models/player/pandafishizens/male_05.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 05 (Art)", "models/player/pandafishizens/male_05.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 06 (Sandro)", "models/player/pandafishizens/male_06.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 06 (Sandro)", "models/player/pandafishizens/male_06.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 07 (Mike)", "models/player/pandafishizens/male_07.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 07 (Mike)", "models/player/pandafishizens/male_07.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 08 (Vance)", "models/player/pandafishizens/male_08.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 08 (Vance)", "models/player/pandafishizens/male_08.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 09 (Erdim)", "models/player/pandafishizens/male_09.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 09 (Erdim)", "models/player/pandafishizens/male_09.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 10 (Cohrt)", "models/player/pandafishizens/male_10.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 10 (Cohrt)", "models/player/pandafishizens/male_10.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 11 (Hank)", "models/player/pandafishizens/male_11.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 11 (Hank)", "models/player/pandafishizens/male_11.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 12 (Gank)", "models/player/pandafishizens/male_12.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 12 (Gank)", "models/player/pandafishizens/male_12.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 15 (John)", "models/player/pandafishizens/male_15.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 15 (John)", "models/player/pandafishizens/male_15.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Male 16 (Fred)", "models/player/pandafishizens/male_16.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Male 16 (Fred)", "models/player/pandafishizens/male_16.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 01 (Joey)", "models/player/pandafishizens/female_01.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 01 (Joey)", "models/player/pandafishizens/female_01.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 02 (Kanisha)", "models/player/pandafishizens/female_02.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 02 (Kanisha)", "models/player/pandafishizens/female_02.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 03 (Kim)", "models/player/pandafishizens/female_03.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 03 (Kim)", "models/player/pandafishizens/female_03.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 04 (Chau)", "models/player/pandafishizens/female_04.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 04 (Chau)", "models/player/pandafishizens/female_04.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 06 (Naomi)", "models/player/pandafishizens/female_06.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 06 (Naomi)", "models/player/pandafishizens/female_06.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 07 (Lakeetra)", "models/player/pandafishizens/female_07.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 07 (Lakeetra)", "models/player/pandafishizens/female_07.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 11 (Jill)", "models/player/pandafishizens/female_11.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 11 (Jill)", "models/player/pandafishizens/female_11.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 17 (Zoey)", "models/player/pandafishizens/female_17.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 17 (Zoey)", "models/player/pandafishizens/female_17.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 18 (Chell)", "models/player/pandafishizens/female_18.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 18 (Chell)", "models/player/pandafishizens/female_18.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 19 (Rochelle)", "models/player/pandafishizens/female_19.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 19 (Rochelle)", "models/player/pandafishizens/female_19.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 24 (Agnes)", "models/player/pandafishizens/female_24.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 24 (Agnes)", "models/player/pandafishizens/female_24.mdl" );

player_manager.AddValidModel( "Enhanced HL2RP Citizens - Female 25 (Bagnes)", "models/player/pandafishizens/female_25.mdl" );
list.Set( "PlayerOptionsModel", "Enhanced HL2RP Citizens - Female 25 (Bagnes)", "models/player/pandafishizens/female_25.mdl" );