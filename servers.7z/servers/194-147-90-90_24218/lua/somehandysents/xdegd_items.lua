-- "lua\\somehandysents\\xdegd_items.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
//种子
if true then local cls = "seed_apple"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_apple"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 255, 0, 0 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.Seed          	= "models/props_foliage/tree_apple01.mdl"
	ITEM.MaxSize       	= 0.5
	ITEM.Growth        	= 700
	ITEM.FruitRate     	= 40
	ITEM.FruitPos      	= {
		Vector( 18, 2, 15 ),
		Vector( -16, 0, 29.5 ),
		Vector( -30, 12, 32 ),
		Vector( -0.5, -24, 26 ),
		Vector( 0.5, 16, 40 ),
		Vector( 20, -13.5, 37.5 ),
		Vector( -21.5, 24, 50 ),
		Vector( 12, -5, 59 ),
	}
	ITEM.FruitName     	= "apple"
	ITEM.WaterNeed     	= { 25, 90 }
	ITEM.FertileNeed   	= { 0, 75 }
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "seed_orange"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_orange"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 255, 165, 0 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.Seed          	= "models/props_foliage/tree_apple01.mdl"
	ITEM.MaxSize       	= 0.5
	ITEM.Growth        	= 650
	ITEM.FruitRate     	= 45
	ITEM.FruitPos      	= {
		Vector( 18, 2, 15.5 ),
		Vector( -16, 0, 30 ),
		Vector( -30, 12, 32.5 ),
		Vector( -0.5, -24, 26.5 ),
		Vector( 0.5, 16, 40.5 ),
		Vector( 20, -13.5, 38 ),
		Vector( -21.5, 24, 50.5 ),
		Vector( 12, -5, 59.5 ),
	}
	ITEM.FruitName     	= "orange"
	ITEM.WaterNeed     	= { 30, 100 }
	ITEM.FertileNeed   	= { 20, 100 }
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "seed_corn"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_corn"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 255, 255, 128 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.FixPos 		= Vector( 0, 0, 4 )
	ITEM.FixAng 		= Angle( 0, 0, 75 )
	ITEM.Seed          	= "models/tysn/tysn_cornstalk_1.mdl"
	ITEM.MaxSize       	= 1
	ITEM.Growth        	= 800
	ITEM.FruitRate     	= 75
	ITEM.FruitPos      	= {
		Vector( -2, 0, 17 ),
		Vector( 0, -2, 34 ),
		Vector( 2, 0, 51 ),
		Vector( 0, 2, 68 ),
	}
	ITEM.FruitName     	= "corn"
	ITEM.WaterNeed     	= { 5, 85 }
	ITEM.FertileNeed   	= { 20, 100 }
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "seed_tomato"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_tomato"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 255, 128, 32 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.FixPos 		= Vector( 0, 0, 4 )
	ITEM.Seed          	= "models/tysn/tysn_tomatoplant_1.mdl"
	ITEM.MaxSize       	= 1
	ITEM.Growth        	= 750
	ITEM.FruitRate     	= 75
	ITEM.FruitPos      	= {
		Vector( -4, 0, 12 ),
		Vector( 0, -4, 24 ),
		Vector( 4, 0, 36 ),
		Vector( 0, 4, 48 ),
	}
	ITEM.FruitName     	= "tomato"
	ITEM.WaterNeed     	= { 10, 90 }
	ITEM.FertileNeed   	= { 15, 95 }
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "seed_banana"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_banana"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 255, 215, 0 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.Seed          	= "models/tysn/tysn_bananatree_1.mdl"
	ITEM.MaxSize       	= 0.5
	ITEM.FixPos 		= Vector( 0, 0, 10 )
	ITEM.FixAng 		= Angle( 0, 0, -60 )
	ITEM.Growth        	= 750
	ITEM.FruitRate     	= 60
	ITEM.FruitPos      	= {
		Vector( 4, 4, 42 ),
		Vector( -4, 4, 39 ),
		Vector( -4, -4, 36 ),
		Vector( 4, -4, 45 ),
	}
	ITEM.FruitName     	= "banana"
	ITEM.WaterNeed     	= { 10, 80 }
	ITEM.FertileNeed   	= { 10, 100 }
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "seed_melon"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_melon"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 34, 139, 34 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.Seed          	= "models/props_foliage/bush2.mdl"
	ITEM.FixPos 		= Vector( 0, 0, 5 )
	ITEM.MaxSize       	= 1
	ITEM.Growth        	= 1000
	ITEM.FruitRate     	= 75
	ITEM.FruitPos      	= {
		Vector( 13, 0, 10 ),
		Vector( -10, 8, 10 ),
		Vector( -3, -10, 10 ),
	}
	ITEM.FruitName     	= "melon"
	ITEM.WaterNeed     	= { 5, 80 }
	ITEM.FertileNeed   	= { 0, 80 }
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "seed_pumpkin"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_seed_pumpkin"
	ITEM.Model 			= "models/props_lab/box01a.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
    ITEM.Category 		= "#xdeshe.GDSeed"
    ITEM.Color        	= Color( 255, 127, 80 )
    ITEM.Physics      	= "Plastic_Box"
	ITEM.FixPos 		= Vector( 0, 0, 4 )
	ITEM.Seed          	= "models/props/de_inferno/largebush01.mdl"
	ITEM.MaxSize       	= 1.2
	ITEM.Growth        	= 1100
	ITEM.FruitRate     	= 80
	ITEM.FruitPos      	= {
		Vector( 13, 0, 4 ),
		Vector( -10, 8, 4 ),
		Vector( -3, -10, 4 ),
	}
	ITEM.FruitName     	= "pumpkin"
	ITEM.WaterNeed     	= { 5, 80 }
	ITEM.FertileNeed   	= { 20, 90 }
	xdegd.ItemRegister( cls, ITEM )
end

//作物
function xdegd.PickFruit( ent, ply )
	if CLIENT or !IsValid( ent ) or !IsValid( ply ) or !ply:IsPlayer() or ent:GetClass() != "sent_she_xdegd" then return end
	if !ent.XDE_Place or !ply:CheckLimit( "sents" ) then return end
	local dat, par = xdegd.ItemGet( ent:GetXDE_DT() ), ent:GetParent()
	if istable( dat ) and IsValid( par ) and par:GetClass() == "sent_she_tray" and par.XDE_FruitEnt[ ent.XDE_Place ] == ent then
		local pos, ang = ent:GetPos(), ent:GetAngles()
		par:DontDeleteOnRemove( ent ) ent:SetParent( nil )
		ent:SetPos( pos ) ent:SetAngles( ang ) ent:GetPhysicsObject():Wake()
		hook.Run( "PlayerSpawnedSENT", ply, ent )
		undo.Create( dat.Name )
		undo.AddEntity( ent )
		undo.SetPlayer( ply )
		undo.Finish()
		par.XDE_FruitEnt[ ent.XDE_Place ] = nil  ent.XDE_Place = nil
		if NADMOD then NADMOD.PlayerMakePropOwner( ply, ent ) end
		ent:EmitSound( "garrysmod/balloon_pop_cute.wav", 70, math.random( 80, 120 ), 0.75, CHAN_ITEM )
	end
end
function xdegd.EatFruit( ent, ply, sec, hp, ap )
	if sec or ent.XDE_Used then return end ent.XDE_Used = true
	ply:EmitSound( "items/meat"..math.random( 1, 2 )..".wav", 65, math.random( 115, 125 ), 0.6, CHAN_VOICE )
	ent:Remove() xdeshe_DoGesture( ply, ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN )
	ply:ViewPunch( Angle( math.Rand( 2, 4 ), math.Rand( -2, 2 ), math.Rand( -1, 1 ) ) )
	if ply:Health() < ply:GetMaxHealth() then ply:SetHealth( math.min( ply:GetMaxHealth(), ply:Health() +hp ) ) end
	if ply:Armor() < ply:GetMaxArmor() then ply:SetArmor( math.min( ply:GetMaxArmor(), ply:Armor() +ap ) ) end
	local dat = xdegd.ItemGet( ent:GetXDE_DT() )
	if istable( dat ) and dat.Color then local col = dat.Color
		xdeshe_BroadEffect( "xdeshe_eatfruit", { Origin = ent:WorldSpaceCenter(), Start = Vector( col.r, col.g, col.b ) } )
	end
end
function xdegd.BreakFruit( ent, dmg, cls )
	if CLIENT or !IsValid( ent ) or ent:GetClass() != "sent_she_xdegd" then return end
	local atk = dmg:GetAttacker()
	if dmg:GetDamage() > 0 and IsValid( atk ) and atk:IsPlayer() and !ent.XDE_Used then
		ent:SetHealth( math.max( 0, ent:Health() -dmg:GetDamage() ) )
		if ent:Health() <= 0 then ent.XDE_Used = true
			ent:EmitSound( "Watermelon.BulletImpact" )
			for i=1, 3 do
				xdegd.ItemSpawn( cls, ent:WorldSpaceCenter() +VectorRand():GetNormalized(), AngleRand(), atk )
			end
			SafeRemoveEntity( ent )
		end
	end
end
if true then local cls = "apple"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_apple"
	ITEM.Model 			= "models/maniasfood/apple/apple.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
    ITEM.Color        	= Color( 255, 0, 0 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 5, 0 ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "orange"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_orange"
	ITEM.Model 			= "models/props/cs_italy/orange.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
    ITEM.Color        	= Color( 255, 165, 0 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 2, 2 ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "corn"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_corn"
	ITEM.Model 			= "models/tysn/tysn_corncob_1.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
    ITEM.Color        	= Color( 255, 255, 128 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 0, 4 ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "tomato"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_tomato"
	ITEM.Model 			= "models/tysn/tysn_tomato_1.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
    ITEM.Color        	= Color( 255, 128, 32 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 2, 5 ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "banana"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_banana"
	ITEM.Model 			= "models/props/cs_italy/bananna_bunch.mdl"
    ITEM.Category 		= "Other"
    ITEM.Color        	= Color( 255, 215, 0 )
	ITEM.NoColor 		= true
	ITEM.Hidden 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.OnInit 		= function( _, self ) self:SetMaxHealth( 5 ) self:SetHealth( self:GetMaxHealth() ) end
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnHurt 		= function( _, self, dmg ) xdegd.BreakFruit( self, dmg, "banana2" ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "banana2"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_banana"
	ITEM.Model 			= "models/props/cs_italy/bananna.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
    ITEM.Color        	= Color( 255, 215, 0 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 2, 4 ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "melon"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_melon"
	ITEM.Model 			= "models/props_junk/watermelon01.mdl"
    ITEM.Category 		= "Other"
    ITEM.Color        	= Color( 255, 128, 128 )
	ITEM.NoColor 		= true
	ITEM.Hidden 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.OnInit 		= function( _, self ) self:SetMaxHealth( 5 ) self:SetHealth( self:GetMaxHealth() ) end
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnHurt 		= function( _, self, dmg ) xdegd.BreakFruit( self, dmg, "melon2" ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "melon2"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_melon2"
	ITEM.Model 			= "models/props_junk/watermelon01_chunk01b.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
	ITEM.CarryAng 		= Angle( 0, 90, 0 )
    ITEM.Color        	= Color( 255, 128, 128 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 3, 3 ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "pumpkin"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_pumpkin"
	ITEM.Model 			= "models/props_outland/pumpkin01.mdl"
    ITEM.Category 		= "Other"
    ITEM.Color        	= Color( 255, 127, 80 )
	ITEM.NoColor 		= true
	ITEM.Hidden 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.OnInit 		= function( _, self ) self:SetMaxHealth( 5 ) self:SetHealth( self:GetMaxHealth() ) end
	ITEM.OnPickup 		= function( _, self, ent ) xdegd.PickFruit( self, ent ) end
	ITEM.OnHurt 		= function( _, self, dmg ) xdegd.BreakFruit( self, dmg, "pumpkin2" ) end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "pumpkin2"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_pumpkin2"
	ITEM.Model 			= "models/props_outland/pumpkin01_chunk01b.mdl"
    ITEM.Category 		= "#xdeshe.GDFood"
    ITEM.Color        	= Color( 255, 127, 80 )
	ITEM.NoColor 		= true
    ITEM.Physics      	= "Flesh"
	ITEM.InterTxt 		= { "#xdeshe.GDConsume" }
	ITEM.OnInter 		= function( _, self, act, sec ) xdegd.EatFruit( self, act, sec, 5, 2 ) end
	xdegd.ItemRegister( cls, ITEM )
end

//工具
if true then local cls = "watercan"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_watercan"
	ITEM.Model 			= "models/props/misc/cb_watercan.mdl"
	ITEM.CarryAng 		= Angle( 0, 90, 0 )
	ITEM.InterTxt 		= { "#xdeshe.GDPour" }
    ITEM.Category 		= "#xdeshe.GDTool"
	ITEM.Helper 		= "#xdeshe.GH_watercan"
    ITEM.Physics      	= "Plastic_Box"
	ITEM.OnInit 		= function( _, self )
		self:SetNWFloat( "XDE_Water", 0 ) self.XDE_Pour = 0  self.XDE_Snd = nil
		self.XDE_PAng = false
	end
	ITEM.OnRemove 		= function( _, self )
		if self.XDE_Snd then self.XDE_Snd:Stop() self.XDE_Snd = nil end
	end
	ITEM.OnInter 		= function( _, self, act, sec )
		if sec then return end self.XDE_PAng = !self.XDE_PAng
		local ang = Angle( 0, act:EyeAngles().yaw +90, self.XDE_PAng and 45 or 0 )
		self:GetPhysicsObject():EnableMotion( false )
		timer.Simple( 0.1, function()
			if IsValid( self ) and IsValid( act ) then
				self:GetPhysicsObject():EnableMotion( true )
				self:SetAngles( ang )
				act:PickupObject( self )
				act.XDEGD = self
			end
		end )
	end
	ITEM.OnPickup 		= function( _, self, act )
		self.XDE_PAng = false
	end
	ITEM.OnThink 		= function( _, self )
		local down = ( math.Round( math.sqrt( self:GetAngles().pitch^2 + math.Round( self:GetAngles().roll )^2 ) ) >= 45 )
		if down and self:GetNWFloat( "XDE_Water" ) > 0 and self:WaterLevel() < 3 then
			if self.XDE_Pour != 1 then
				if self.XDE_Snd then self.XDE_Snd:Stop() self.XDE_Snd = nil end
				self.XDE_Snd = CreateSound( self, Sound( "ambient/water/water_flow_loop1.wav" ) )
				self.XDE_Snd:Play()
				self.XDE_Snd:ChangeVolume( 0.75 )
				self.XDE_Snd:ChangePitch( 200 -math.Clamp( self:GetNWFloat( "XDE_Water" )/100, 0, 1 )*40, 0 )
				self.XDE_Pour = 1
			end
		elseif self:WaterLevel() >= 3 and self:GetNWFloat( "XDE_Water" ) < 100 then
			if self.XDE_Pour != 2 then
				if self.XDE_Snd then self.XDE_Snd:Stop() self.XDE_Snd = nil end
				self.XDE_Snd = CreateSound( self, Sound( "ambient/water/leak_1.wav" ) )
				self.XDE_Snd:Play()
				self.XDE_Snd:ChangeVolume( 0.75 )
				self.XDE_Snd:ChangePitch( 120 -math.Clamp( self:GetNWFloat( "XDE_Water" )/100, 0, 1 )*40, 0 )
				self.XDE_Pour = 2
			end
		elseif self.XDE_Pour > 0 then
			if self.XDE_Snd then self.XDE_Snd:FadeOut( 0.5 ) end self.XDE_Pour = 0
		end
		if self.XDE_Pour > 0 then
			self:SetNWFloat( "XDE_Water", math.Clamp( self:GetNWFloat( "XDE_Water" ) +( self.XDE_Pour == 1 and -0.5 or 1 ), 0, 100 ) )
			if self.XDE_Pour == 1 then
				self.XDE_Snd:ChangePitch( 200 -math.Clamp( self:GetNWFloat( "XDE_Water" )/100, 0, 1 )*40, 0.25 )
				local pos = self:GetPos() + self:GetAngles():Up()*8 + self:GetAngles():Right()*16
				local water = ents.Create( "sent_she_water" )
				water:SetPos( pos )
				water:SetAngles( VectorRand():Angle() )
				water:SetOwner( self )
				water:Spawn()
				water:Activate()
				water:GetPhysicsObject():SetVelocity( self:GetAngles():Up()*math.random( 128, 256 ) +VectorRand():GetNormalized()*8 )
				SafeRemoveEntityDelayed( water, 5 )
			else
				self.XDE_Snd:ChangePitch( 120 -math.Clamp( self:GetNWFloat( "XDE_Water" )/100, 0, 1 )*40, 0.25 )
			end
		end
	end
	if CLIENT then
		local Mat = xdeshe_OnceMat( "models/shadertest/predator" )
		ITEM.OnDraw 	= function( _, self )
			local pp, aa = LocalToWorld( Vector( 0, 5, -2 ), Angle( 0, 180, 90 ), self:GetPos(), self:GetAngles() )
			local str = math.Clamp( math.ceil( self:GetNWFloat( "XDE_Water" ) ), 0, 100 ).."%"
			cam.Start3D2D( pp, aa, 0.1 )
				draw.TextShadow( {
					text = str,
					pos = { 0, 0 },
					font = "xdeshe_Font2",
					xalign = TEXT_ALIGN_CENTER,
					yalign = TEXT_ALIGN_CENTER,
					color = Color( 255, 255, 255 )
				}, 1, 255 )
			cam.End3D2D()
			local per = math.Clamp( self:GetNWFloat( "XDE_Water" )/100, 0, 1 )
			local pp, aa = LocalToWorld( Vector( 0, 0, -5.6 +11*per ), Angle( 0, 90, 0 ), self:GetPos(), self:GetAngles() )
			if self:WaterLevel() < 2 and self:GetNWFloat( "XDE_Water" ) > 0 then
				cam.Start3D2D( pp, aa, 0.2 )
					surface.SetMaterial( Mat ) xdeshe_Circle( 0, 0, 24, 32, 1 )
					draw.NoTexture() surface.SetDrawColor( 0, 161, 255, 32 ) xdeshe_Circle( 0, 0, 24, 32, 1 )
				cam.End3D2D()
			end
		end
	end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "bucket"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_bucket"
	ITEM.CarryAng 		= Angle( 0, 90, 0 )
	ITEM.Model 			= "models/props_junk/MetalBucket01a.mdl"
	ITEM.InterTxt 		= { "#xdeshe.GDPour" }
    ITEM.Category 		= "#xdeshe.GDTool"
	ITEM.Helper 		= "#xdeshe.GH_bucket"
    ITEM.Physics      	= "SolidMetal"
	ITEM.OnInit 		= function( _, self )
		self:SetNWBool( "XDE_Fill", false ) self.XDE_PAng = false
	end
	ITEM.OnTouch 		= function( _, self, ent, typ )
		if ent:GetClass() != "sent_she_tray" or !self:GetNWBool( "XDE_Fill" ) or self:WaterLevel() > 0 then return end
		ent:SetXDE_Water( math.Clamp( ent:GetXDE_Water() +60, 0, 100 ) )
		xdeshe_BroadEffect( "watersplash", { Origin = self:WorldSpaceCenter(), Flags = 0, Scale = 5 } )
		self:SetNWBool( "XDE_Fill", false )
	end
	ITEM.OnInter 		= function( _, self, act, sec )
		if sec then return end self.XDE_PAng = !self.XDE_PAng
		local ang = Angle( 0, act:EyeAngles().yaw +90, self.XDE_PAng and 90 or 0 )
		self:GetPhysicsObject():EnableMotion( false )
		timer.Simple( 0.1, function()
			if IsValid( self ) and IsValid( act ) then
				self:GetPhysicsObject():EnableMotion( true )
				self:SetAngles( ang )
				act:PickupObject( self )
				act.XDEGD = self
			end
		end )
	end
	ITEM.OnPickup 		= function( _, self, act )
		self.XDE_PAng = false
	end
	ITEM.OnThink 		= function( _, self )
		local down = ( math.Round( math.sqrt( self:GetAngles().pitch^2 + math.Round( self:GetAngles().roll )^2 ) ) >= 75 )
		if down and self:GetNWBool( "XDE_Fill" ) and self:WaterLevel() < 3 then
			self:SetNWBool( "XDE_Fill", false )
			local pos = self:WorldSpaceCenter() +self:GetUp()*8
			timer.Simple( 0, function()
				local effect = EffectData()
				effect:SetOrigin( pos )
				effect:SetScale( 5 ) effect:SetFlags( 0 )
				util.Effect( "watersplash", effect )
			end )
			for i=1, 16 do
				local water = ents.Create( "sent_she_water" )
				water:SetPos( pos )
				water:SetAngles( VectorRand():Angle() )
				water:SetOwner( self )
				water:Spawn()
				water:Activate()
				water:GetPhysicsObject():SetVelocity( self:GetAngles():Up()*math.random( 256, 512 ) +VectorRand():GetNormalized()*32 )
				SafeRemoveEntityDelayed( water, 5 )
			end
		elseif self:WaterLevel() >= 3 and !self:GetNWBool( "XDE_Fill" ) then
			self:SetNWBool( "XDE_Fill", true ) self:EmitSound( "Splash.SplashSound" )
		end
	end
	if CLIENT then local Mat = xdeshe_OnceMat( "models/shadertest/predator" )
		ITEM.OnDraw 	= function( _, self )
			local pp, aa = LocalToWorld( Vector( 0, 0, 6 ), Angle( 0, 90, 0 ), self:GetPos(), self:GetAngles() )
			if self:WaterLevel() < 2 and self:GetNWBool( "XDE_Fill" ) then
				cam.Start3D2D( pp, aa, 0.2 )
					surface.SetMaterial( Mat ) xdeshe_Circle( 0, 0, 40, 64, 1 )
					draw.NoTexture() surface.SetDrawColor( 0, 161, 255, 32 ) xdeshe_Circle( 0, 0, 40, 64, 1 )
				cam.End3D2D()
			end
		end
	end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "fertile"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_fertile"
	ITEM.Model 			= "models/props_junk/garbage_bag001a.mdl"
    ITEM.Category 		= "#xdeshe.GDTool"
	ITEM.Helper 		= "#xdeshe.GH_fertile"
    ITEM.Physics      	= "Plastic_Box"
	ITEM.OnTouch 		= function( _, self, ent, typ )
		if ent:GetClass() != "sent_she_tray" or self.XDE_Used then return end
		ent:SetXDE_Fertile( math.Clamp( ent:GetXDE_Fertile() +25, 0, 100 ) )
		xdeshe_BroadEffect( "xdeshe_dirt", { Origin = self:WorldSpaceCenter() } )
		self.XDE_Used = true  self:Remove()
	end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "shovel"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_shovel"
	ITEM.Model 			= "models/weapons/w_spade.mdl"
	ITEM.CarryAng 		= Angle( 0, 90, -90 )
    ITEM.Category 		= "#xdeshe.GDTool"
	ITEM.Helper 		= "#xdeshe.GH_shovel"
    ITEM.Physics      	= "Metal_Box"
	ITEM.OnInit 		= function( _, self ) self:SetTrigger( true ) end
	ITEM.OnTouch 		= function( _, self, ent, typ )
		if !IsValid( self:GetXDE_OW() ) or ent:GetClass() != "sent_she_tray" then return end
		if NADMOD and !NADMOD.PlayerCanTouch( self:GetXDE_OW(), ent ) then return end
		if ent:GetXDE_Type() != "_" then ent:SetXDE_Type( "_" ) self:EmitSound( "MetalGrate.ImpactSoft" ) end
	end
	xdegd.ItemRegister( cls, ITEM )
end
if true then local cls = "waste"
	local ITEM = {}
	ITEM.Name 			= "#xdeshe.GD_waste"
	ITEM.Model 			= "models/props_urban/plastic_bucket001.mdl"
	ITEM.CarryAng 		= Angle( 0, 180, 0 )
	ITEM.Color 			= Color( 128, 112, 64 )
    ITEM.Category 		= "#xdeshe.GDTool"
	ITEM.InterTxt 		= { "#xdeshe.GDDump" }
	ITEM.Helper 		= "#xdeshe.GH_waste"
    ITEM.Physics      	= "Plastic_Box"
	ITEM.OnInit 		= function( _, self ) self:SetNWFloat( "XDE_Waste", 0 ) end
	ITEM.OnTouch 		= function( _, self, ent, typ )
		if ent:GetClass() != "sent_she_xdegd" or self.XDE_Used or ent.XDE_Used then return end
		local dat = xdegd.ItemGet( ent:GetXDE_DT() )  if !istable( dat ) or dat.Category != "#xdeshe.GDFood" then return end
		ent.XDE_Used = true  ent:Remove()  ent:EmitSound( "Watermelon.Impact" )
		if dat.Color then local col = dat.Color
			xdeshe_BroadEffect( "xdeshe_eatfruit", { Origin = self:WorldSpaceCenter() +self:GetUp()*8, Start = Vector( col.r, col.g, col.b ) } )
		end
		self:SetNWFloat( "XDE_Waste", math.Clamp( self:GetNWFloat( "XDE_Waste" ) +20, 0, 100 ) )
		if self:GetNWFloat( "XDE_Waste" ) >= 100 then self:SetNWFloat( "XDE_Waste", 0 )
			self:EmitSound( "Cardboard.Shake" )
			xdegd.ItemSpawn( "fertile", self:WorldSpaceCenter() +self:GetUp()*8, self:GetAngles(), self:GetXDE_OW() )
		end
	end
	ITEM.OnInter 		= function( _, self, act, sec )
		if sec then return end
		local was = self:GetNWFloat( "XDE_Waste" ) if was <= 0 then return end
		self:GetPhysicsObject():EnableMotion( false )
		timer.Simple( 0.1, function()
			if IsValid( self ) and IsValid( act ) then
				self:GetPhysicsObject():EnableMotion( true )
				self:EmitSound( "Watermelon.Impact" )
				xdeshe_BroadEffect( "xdeshe_eatfruit", { Origin = self:WorldSpaceCenter() +self:GetUp()*8, Start = Vector( 64, 56, 32 ) } )
				self:SetNWFloat( "XDE_Waste", 0 )
			end
		end )
	end
	if CLIENT then local Mat = xdeshe_OnceMat( "effects/water_highlight" )
		ITEM.OnDraw 	= function( _, self )
			local was = self:GetNWFloat( "XDE_Waste" )
			local pp, aa = LocalToWorld( Vector( 0, 0, 1 +math.Clamp( was/100, 0, 1 )*18 ), Angle( 0, 90, 0 ), self:GetPos(), self:GetAngles() )
			if was > 0 then
				render.SuppressEngineLighting( true )
				cam.Start3D2D( pp, aa, 0.19 )
					surface.SetMaterial( Mat ) surface.SetDrawColor( 64, 56, 32 ) xdeshe_Circle( 0, 0, 40, 64, 1 )
				cam.End3D2D()
				render.SuppressEngineLighting( false )
			end
		end
	end
	xdegd.ItemRegister( cls, ITEM )
end