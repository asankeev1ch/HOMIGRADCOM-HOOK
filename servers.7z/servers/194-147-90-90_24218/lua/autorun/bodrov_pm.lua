-- "lua\\autorun\\bodrov_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Bodrov", "models/cmbfdr/rashkinsk/bodrov.mdl" )
list.Set( "PlayerOptionsModel", "Bodrov", "models/cmbfdr/rashkinsk/bodrov.mdl" )
