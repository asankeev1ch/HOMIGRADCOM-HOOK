-- "lua\\autorun\\client\\remove_red_death_overlay.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
hook.Add( "HUDShouldDraw", "RemoveRedDeathOverlay", function( name ) 
    if ( name == "CHudDamageIndicator" ) then 
       return false 
    end
end )

-- Yep, it's that shrimple.