-- "lua\\autorun\\wapplecitizen_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Wapple Citizen", "models/panman/wapple_citizen.mdl" )
player_manager.AddValidHands( "Wapple Citizen", "models/panman/weapons/c_arms_wapplecitizen.mdl", 0, "00000000" )
