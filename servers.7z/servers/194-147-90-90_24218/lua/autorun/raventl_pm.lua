-- "lua\\autorun\\raventl_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Raven Team Leader", "models/keepitwilde/raventl/raventl_pm.mdl" )
list.Set( "PlayerOptionsModel", "Raven Team Leader", "models/keepitwilde/raventl/raventl_pm.mdl" )
player_manager.AddValidHands( "Raven Team Leader", "models/keepitwilde/raventl/raventl_c_Arms.mdl", 0, "00000000" )