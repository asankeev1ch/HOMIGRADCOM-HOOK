-- "lua\\autorun\\catalina.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "lizard dude",                     "models/catalina/lizardman.mdl" )
list.Set( "PlayerOptionsModel",  "lizard dude",                     "models/curupira/lizardman.mdl" ) 
