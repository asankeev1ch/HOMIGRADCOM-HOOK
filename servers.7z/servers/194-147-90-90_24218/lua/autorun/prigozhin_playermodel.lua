-- "lua\\autorun\\prigozhin_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Evgeniy Prigozhin", "models/dejtriyev/dreamybuss/prigozhin.mdl" );
player_manager.AddValidHands( "Evgeniy Prigozhin", "models/dejtriyev/weapons/c_arms_prigozhin.mdl", 0, "00000000" )