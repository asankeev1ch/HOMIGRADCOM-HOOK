-- "lua\\autorun\\artemius_scp035.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP 035", "models/artemius/scp/035/scp035.mdl" );