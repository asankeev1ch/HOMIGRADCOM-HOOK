-- "lua\\autorun\\nebulaman.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "galaxyman_red", "models/player/galaxyman/galaxyman_red.mdl" )
player_manager.AddValidHands( "galaxyman_red", "models/player/galaxyman/galaxyman_hands_red.mdl", 0, "00000000", true )
list.Set( "PlayerOptionsModel", "Nebula Man", "models/player/galaxyman/galaxyman_red.mdl" )
