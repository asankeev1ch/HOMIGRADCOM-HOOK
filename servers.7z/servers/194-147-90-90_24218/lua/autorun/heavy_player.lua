-- "lua\\autorun\\heavy_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel("Heavy Weapons Guy", "models/player/heavyplayer/heavy.mdl")
list.Set("PlayerOptionsModel", "Heavy Weapons Guy", "models/player/heavyplayer/heavy.mdl")
player_manager.AddValidHands("Heavy Weapons Guy", "models/player/heavyplayer/heavy_hands.mdl", 0, "00000000")