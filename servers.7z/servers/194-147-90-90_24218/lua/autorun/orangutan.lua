-- "lua\\autorun\\orangutan.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Orangutan","models/vedatys/orangutan.mdl" )
player_manager.AddValidHands( "Orangutan", "models/vedatys/c_arms.mdl", 0, "00000000" )