-- "lua\\autorun\\kenny.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Kenny Mccormick", "models/kenny/kenny.mdl" )

AddCSLuaFile( 'kenny.lua' )

list.Set( "PlayerOptionsModel", "Kenny Mccormick", "models/kenny/kenny.mdl" )