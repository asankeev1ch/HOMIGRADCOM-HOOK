-- "lua\\autorun\\pissbaby.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

player_manager.AddValidModel( "Piss Baby", "models/player/pissbaby.mdl" );
list.Set( "PlayerOptionsModel", "Piss Baby", "models/player/pissbaby.mdl" );
player_manager.AddValidHands("Piss Baby", "models/player/pan/hands/c_arms_pissbaby.mdl",		0, "0000000" )

