-- "lua\\autorun\\artemius_guard.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP Guard", "models/artemius/human/guard/guard.mdl" )
list.Set( "PlayerOptionsModel", "SCP Guard", "models/artemius/human/guard/guard.mdl" )