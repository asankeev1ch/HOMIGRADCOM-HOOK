-- "lua\\autorun\\chuixue_white_sheepylord.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel("Chuixue (White)", "models/sheepylord/kantai_collection/chuixue_white.mdl");
player_manager.AddValidHands("Chuixue (White)", "models/sheepylord/kantai_collection/chuixue_white_arms.mdl" , 0, "000000")

local Category = "ASUS"

local NPC = {
    Name = "Chuixue (White) (Friendly)",
    Class = "npc_citizen",
    Model = "models/sheepylord/kantai_collection/chuixue_white.mdl",
    Health = "100",
    KeyValues = { citizentype = 4 },
    Weapons = { "weapon_smg1" },
    Category = Category
}

list.Set("NPC", "chuixue_white_sheepylord_F", NPC)

local NPC = {
    Name = "Chuixue (White) (Enemy)",
    Class = "npc_combine_s",
    Model = "models/sheepylord/kantai_collection/chuixue_white.mdl",
    Health = "100",
    Numgrenades = "4",
    Weapons = { "weapon_ar2" },
    Category = Category
}

list.Set("NPC", "chuixue_white_sheepylord_E", NPC)

