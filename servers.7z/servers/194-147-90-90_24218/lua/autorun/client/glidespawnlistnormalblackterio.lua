-- "lua\\autorun\\client\\glidespawnlistnormalblackterio.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "GlideCategories", "BlackteriosGLIDE", {
    name = "Blackterio's Glide",
    icon = "glide/icons/car.png"
} )

