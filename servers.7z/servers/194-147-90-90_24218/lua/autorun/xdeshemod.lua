-- "lua\\autorun\\xdeshemod.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--[[
	Some Handy Entities by LemonCola3424(XDE).
	All thirdparty content belongs to their respective owners
--]]

game.AddParticles( "particles/asw/fire_fx.pcf" ) game.AddParticles( "particles/weapon_fx.pcf" )
PrecacheParticleSystem( "asw_flamethrower" ) PrecacheParticleSystem( "explosion_turret_break" )
PrecacheParticleSystem( "mine_fire" ) PrecacheParticleSystem( "mine_fire_burn" ) PrecacheParticleSystem( "vindicator_grenade" )

if SERVER then
	AddCSLuaFile( "somehandysents/languages.lua" )
	xdeshe_actions = {}
	util.AddNetworkString( "xdeshe_S2C_Gesture" ) util.AddNetworkString( "xdeshe_S2C_BroadEffect" )
	util.AddNetworkString( "xdeshe_S2C_MenuOpen" ) util.AddNetworkString( "xdeshe_S2C_MenuUpdate" )
	util.AddNetworkString( "xdeshe_S2C_MenuClose" ) util.AddNetworkString( "xdeshe_S2C_Helper" )
	util.AddNetworkString( "xdeshe_S2C_HintMessage" ) util.AddNetworkString( "xdeshe_S2C_ChatMessage" )
	util.AddNetworkString( "xdeshe_S2C_Pickup" ) util.AddNetworkString( "xdeshe_C2S_MenuAction" ) util.AddNetworkString( "xdeshe_C2S_MenuClose" )

	function xdeshe_MenuClose( ply, id ) --界面关闭
		if !isstring( id ) or !IsValid( ply ) then return end
		if IsValid( ply.XDE_Using ) and ply.XDE_Using.GetXDE_US and ply.XDE_Using:GetXDE_US() == ply then
			ply.XDE_Using:SetXDE_US( nil )
		end
		ply.XDE_Using = nil  ply.XDE_Cool = CurTime() +0.25
		net.Start( "xdeshe_S2C_MenuClose" )
		net.WriteString( id )
		net.Send( ply )
	end
	function xdeshe_ActionRegister( id, func ) --苟使界面登录函数
		xdeshe_actions[ id ] = func
	end
	function xdeshe_CleanPlayer( ply ) --清除关于该模组全部存在玩家身上的数据
		if ply:GetNWFloat( "XDESHE_Inv" ) > 0 then ply:SetNWFloat( "XDESHE_Inv", 0 ) end
		if ply:GetNWFloat( "XDESHE_Rev" ) > 0 then ply:SetNWFloat( "XDESHE_Rev", 0 ) end
		if ply:GetNWFloat( "XDESHE_Hide" ) > 0 then ply:SetNWFloat( "XDESHE_Hide", 0 ) end
		if ply:GetNWFloat( "XDESHE_Found" ) > 0 then ply:SetNWFloat( "XDESHE_Found", 0 ) end
		if ply:GetNWBool( "XDESHE_Fall" ) then ply:SetNWBool( "XDESHE_Fall", false ) end
		if ply.XDE_Hide then
			ply:SetRenderMode( RENDERMODE_NORMAL ) ply:SetColor( Color( 255, 255, 255, 255 ) ) ply:SetNoTarget( false )
			ply.XDE_Hide = false
		end
		if ply:GetNWFloat( "XDESHE_PP" ) > 0 then
			ply:SetNWFloat( "XDESHE_PP", 0 )
			if ply.XDE_PPSnd then ply.XDE_PPSnd:Stop()  ply.XDE_PPSnd = nil end
			if ply.XDE_PPSn2 then ply.XDE_PPSn2:Stop()  ply.XDE_PPSn2 = nil end
		end
		for k, v in pairs( ply:GetChildren() ) do if v.XDE_Stick then v:Remove() end end
		if IsValid( ply:GetNWEntity( "XDE_Sniper" ) ) then
			ply:GetNWEntity( "XDE_Sniper" ):SetActive( false )
			ply:SetNWEntity( "XDE_Sniper", Entity( 0 ) )
		end
        for k, v in pairs( ents.FindByClass( "npc_she_*" ) ) do
            if IsValid( v ) and v:IsNPC() and v:Health() > 0 then
                v:AddEntityRelationship( ply, D_LI, 99 )
            end
        end
		if ply.xdeshield then ply:SetNWInt( "XDEES_Amount", 0 ) ply.xdeshdelay = 0
			net.Start( "xdeshe_S2C_Shield" ) net.WriteString( "_" ) net.Send( ply )
			ply.xdeshield = nil
		end
		if ply.XDE_Lucky then ply.XDE_Lucky = nil
			timer.Remove( "["..ply:EntIndex().."]xdelb" )
		end
	end
    function xdeshe_BecomeRagdoll( tar, ppp, wel ) --变布娃娃(杀死)
		if !IsValid( tar ) then return end
		local rag = ents.Create( "prop_ragdoll" )
        rag:SetModel( tar:GetModel() )
        rag:SetPos( ppp or tar:GetPos() )
        rag:SetAngles( tar:GetAngles() )
		rag.XDE_Immune = true
		rag:Spawn()
        rag:SetCollisionGroup( tar:GetShouldServerRagdoll() and COLLISION_GROUP_NONE or COLLISION_GROUP_DEBRIS )
		local phy = rag:GetPhysicsObjectCount()
		if !IsValid( rag:GetPhysicsObject() ) then
            rag:Remove()
            rag = ents.Create( "prop_physics" )
            rag:SetModel( "models/props_junk/watermelon01.mdl" )
			rag:SetPos( ppp or tar:GetPos() )
            rag:SetAngles( tar:GetAngles() )
            rag:Spawn()
            rag:SetCollisionGroup( tar:GetShouldServerRagdoll() and COLLISION_GROUP_NONE or COLLISION_GROUP_DEBRIS )
            rag:GetPhysicsObject():SetVelocity( IsValid( tar:GetPhysicsObject() ) and tar:GetPhysicsObject():GetVelocity() or tar:GetVelocity() )
		elseif phy <= 1 then
            rag:Remove()
            rag = ents.Create( "prop_physics" )
            rag:SetModel( tar:GetModel() )
			rag:SetPos( ppp or tar:GetPos() )
            rag:SetAngles( tar:GetAngles() )
            rag:Spawn()
            rag:SetCollisionGroup( tar:GetShouldServerRagdoll() and COLLISION_GROUP_NONE or COLLISION_GROUP_DEBRIS )
            rag:GetPhysicsObject():SetVelocity( IsValid( tar:GetPhysicsObject() ) and tar:GetPhysicsObject():GetVelocity() or tar:GetVelocity() )
        else
            for i=0, phy -1 do
                if i < 0 then continue end
                local num = rag:GetPhysicsObjectNum( i )
                if IsValid( num ) then
                    pos, ang = tar:GetBonePosition( tar:TranslatePhysBoneToBone( i ) )
                    if pos == nil or ang == nil then continue end
                    num:SetPos( pos +( ppp and ( ppp-tar:GetPos() ) or Vector( 0, 0, 0 ) ) )
                    num:SetAngles( ang )
					num:AddGameFlag( FVPHYSICS_NO_SELF_COLLISIONS )
                end
                if wel then constraint.Weld( rag, rag, 0, i, 0 ) end
            end
            rag:GetPhysicsObject():SetVelocity( tar:GetVelocity() )
        end
		if tar:GetSkin() != nil then
			rag:SetSkin( tar:GetSkin() )
		end
		if tar:GetNumBodyGroups() != nil then
			for i=0, tar:GetNumBodyGroups() -1 do rag:SetBodygroup( i, tar:GetBodygroup( i ) ) end
		end
        rag:SetColor( tar:GetColor() )
        rag:SetMaterial( tar:GetMaterial() )
       if tar:IsPlayer() then
            tar:KillSilent()
            tar:Spectate( OBS_MODE_CHASE )
            tar:SpectateEntity( rag )
            tar:DeleteOnRemove( rag )
        else tar:Remove() end
        return rag
    end

	hook.Add( "PlayerDeath", "xdeshe_pd", function( ply )
		if ply:GetNWInt( "XDESHE_Hats" ) > 0 then local hats = ply:GetNWInt( "XDESHE_Hats" ) --帽子散落
			for i=1, hats do
				local pp, aa = xdeshe_HatPos( ply, i )
				if pp then
					xdeshe_BroadEffect( "xdeshe_hatfall", { Origin = pp, Angles = aa, Start = ply:GetPlayerColor(), Normal = ( ply:GetVelocity()*3 +VectorRand():GetNormalized()*math.random( 128, 256 ) ), Magnitude = 2 } )
				end
			end ply:EmitSound( "Cardboard.Shake" ) ply:SetNWInt( "XDESHE_Hats", 0 )
		end xdeshe_CleanPlayer( ply )
	end )
	hook.Add( "PlayerSpawn", "xdeshe_ps", xdeshe_CleanPlayer )
	hook.Add( "SetupPlayerVisibility", "xdeshe_SPV", function( ply, view )
        for k, v in pairs( ents.FindByClass( "sent_she_sniper" ) ) do --支援狙击手扩大pvs
            if IsValid( v ) and v:GetXDE_OW() == ply and v:GetActive() then
                AddOriginToPVS( v:WorldSpaceCenter() )
            end
        end
	end )
	hook.Add( "OnPlayerPhysicsPickup", "xdeshe_oppp", function( ply, ent )
		if ent:GetClass() == "sent_she_gascan" then ent.XDE_Pick = true end --油罐判定捡起
	end )
	hook.Add( "OnPlayerPhysicsDrop", "xdeshe_oppd", function ( ply, ent, thr )
		if ent:GetClass() == "sent_she_potion" and !ent.XDE_Thrown and thr then --药水判定投掷
			ent:SetPhysicsAttacker( ply, 30 )
			ent:GetPhysicsObject():SetDamping( 0, 0 )
			ent:GetPhysicsObject():SetVelocity( ply:EyeAngles():Forward()*math.Rand( 512, 768 ) +VectorRand():GetNormalized()*math.Rand( 12, 36 ) )
			ent.XDE_Thrown = true
			ply:EmitSound( "Weapon_SLAM.SatchelThrow" )
			xdeshe_DoGesture( ply, ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE )
		end
		if ent:GetClass() == "sent_she_gascan" then ent.XDE_Pick = false end --油罐判定放下
	end )
	hook.Add( "EntityTakeDamage", "xdeshe_etd", function( tar, dmg )
		local atk, inf = dmg:GetAttacker(), dmg:GetInflictor()
		if IsValid( tar.XDE_Pointer ) then --NPC进攻点npc_bullseye
			dmg:SetInflictor( tar.XDE_Pointer )
			tar.XDE_Pointer:TakeDamageInfo( dmg )
			dmg:ScaleDamage( 0 ) return true
		end
		if IsValid( tar ) and tar:IsPlayer() and tar:Alive() and IsValid( tar:GetVehicle() ) then --睡袋叫醒
			local veh = tar:GetVehicle()
			if IsValid( veh:GetParent() ) and veh:GetParent():GetClass() == "sent_she_sleep" and
			veh:GetVehicleClass() == "Seat_Airboat" and veh:GetNWBool( "XDE_Bag" ) then
				tar:ExitVehicle()
				tar:SetPos( veh:WorldSpaceCenter() )
				tar:SetEyeAngles( Angle( 0, 180 +veh:GetAngles().yaw, 0 ) )
			end
		end
		if xdeshe_HatPos and dmg:GetDamage() > 0 and IsValid( tar ) and tar:IsPlayer() and tar:LastHitGroup() == HITGROUP_HEAD then --帽子击落
			local hats = tar:GetNWInt( "XDESHE_Hats" )
			if dmg:IsBulletDamage() and hats > 0 then
				tar:SetNWInt( "XDESHE_Hats", math.max( 0, hats -1 ) )
				local pp, aa = xdeshe_HatPos( tar, 1 )
				if !pp then pp, aa = tar:WorldSpaceCenter(), tar:EyeAngles() end
				dmg:ScaleDamage( 0 ) tar:EmitSound( "Cardboard.BulletImpact" ) tar:ViewPunch( Angle( -math.random( 2, 4 ), 0, math.random( -3, 3 ) ) )
				xdeshe_BroadEffect( "xdeshe_hatfall", { Origin = pp, Angles = aa, Start = tar:GetPlayerColor(), Normal = dmg:GetDamageForce(), Magnitude = 1 } )
			end
		end

		if tar:GetNWFloat( "XDESHE_Hide" ) > CurTime() and tar:GetNWFloat( "XDESHE_Found" ) < CurTime() +2 then --躲藏时受击暴露
			tar:SetNWFloat( "XDESHE_Found", CurTime() +2 )
		end
		if #tar:GetChildren() > 0 and xdeshe_IsFireDmg( dmg ) or dmg:IsBulletDamage() then --油罐引火
			for k, v in pairs( tar:GetChildren() ) do
				if IsValid( v ) and v:GetClass() == "npc_bullseye" and IsValid( v.XDE_Flame ) then
					v.XDE_Flame:Fire( "StartFire" )  v:Remove()
				end
			end
		end
		if IsValid( inf ) and ( inf:GetClass() == "env_fire" or inf:GetClass() == "info_particle_system" ) and ( inf.XDE_Camp or inf.XDE_Stick ) and !tar:IsOnFire() then --油火点燃
			if tar:GetModel() and util.IsValidModel( tar:GetModel() ) and tar != inf:GetParent() and
			( ( tar:IsPlayer() and tar:Alive() ) or ( tar:IsNPC() and tar:GetNPCState() != NPC_STATE_DEAD ) or ( tar:IsNextBot() and tar:Health() > 0 ) or IsValid( tar:GetPhysicsObject() ) ) then
				tar:Ignite( math.Rand( 4, 8 ) )
			end
		end
		if tar.xdeshield and dmg:GetDamage() > 0 then local dam = dmg:GetDamage() --能量盾受击
			if dmg:IsDamageType( DMG_POISON ) then dmg:SetDamageType( DMG_GENERIC ) end
			tar.xdeshdelay = CurTime() +tar.xdeshield[ 2 ] +0.2
			if tar:GetNWInt( "XDEES_Amount" ) > 0 then
				dmg:SetDamage( dam > tar:GetNWInt( "XDEES_Amount" ) and dam -tar:GetNWInt( "XDEES_Amount" ) or 0 )
				tar:SetNWInt( "XDEES_Amount", ( dam > tar:GetNWInt( "XDEES_Amount" ) and 0 or tar:GetNWInt( "XDEES_Amount" ) -dam ) )
				tar:EmitSound( tar:GetNWInt( "XDEES_Amount" ) <= 0 and "Glass.BulletImpact" or "Glass.Strain" )
				if tar:GetNWInt( "XDEES_Amount" ) > 0 then
					if tar:IsPlayer() then tar:ScreenFade( SCREENFADE.IN, Color( 64, 192, 255, math.random( 16, 48 ) ), math.Rand( 0.1, 0.3 ), 0 ) end
					tar:SetNWFloat( "XDEES_Hit", CurTime() +2 )
					if tar.xdeshfull then
						if tar.xdeshield[ 4 ] == 3 and math.random( 1, 100 ) <= tar.xdeshield[ 5 ]*100 then --尖刺盾
							if !dmg:IsDamageType( DMG_DISSOLVE ) and IsValid( atk ) and atk:WorldSpaceCenter():Distance( tar:WorldSpaceCenter() ) <= 64 and dam > 0
							and !tar.xdeshspike or ( tar.xdeshspike and tar.xdeshspike <= CurTime() ) then
								tar.xdeshspike = CurTime() +0.5
								tar:EmitSound( "xdeshe.ShieldSpike" )
								local ddd = DamageInfo()
								ddd:SetDamage( dam/2 )
								ddd:SetAttacker( tar )
								ddd:SetInflictor( dmg:GetInflictor() )
								ddd:SetDamageType( DMG_DISSOLVE )
								ddd:SetDamageForce( ( atk:WorldSpaceCenter() -tar:WorldSpaceCenter() ):GetNormalized()*8192 )
								ddd:SetDamagePosition( atk:WorldSpaceCenter() )
								atk:TakeDamageInfo( ddd )
								if IsValid( atk:GetPhysicsObject() ) then
									atk:GetPhysicsObject():AddVelocity( ddd:GetDamageForce()/32 )
								end
								atk:SetVelocity( ddd:GetDamageForce()/8 )
								xdeshe_BroadEffect( "xdeshe_spiked", { Origin = tar:WorldSpaceCenter(), Normal = ddd:GetDamageForce():GetNormalized(), Scale = 1 } )
							end
						elseif tar.xdeshield[ 4 ] == 5 and math.random( 1, 100 ) <= tar.xdeshield[ 5 ]*100 then --碎裂盾
							if !tar.xdeshspike or tar.xdeshspike <= CurTime() then
								tar.xdeshspike = CurTime() +5
								local ent = ents.Create( "sent_she_shield" )
								ent:SetPos( tar:WorldSpaceCenter() )
								ent:SetAngles( Angle( math.random( 0, 360 ), math.random( 0, 360 ), 0 ) )
								ent:Spawn()
								ent:Activate()
								ent:GetPhysicsObject():AddVelocity( VectorRand():GetNormalized()*math.random( 256, 512 ) )
								ent:GetPhysicsObject():SetAngleVelocity( VectorRand():GetNormalized()*32 )
								ent:EmitSound( "xdeshe.ShieldScatter" )
							end
						elseif tar.xdeshield[ 4 ] == 7 and math.random( 1, 100 ) <= tar.xdeshield[ 5 ]*100 then
							local amo = dmg:GetAmmoType()
							if atk.GetActiveWeapon and IsValid( atk:GetActiveWeapon() ) and isnumber( atk:GetActiveWeapon():GetPrimaryAmmoType() ) then
								amo = atk:GetActiveWeapon():GetPrimaryAmmoType()
							end
							tar:EmitSound( "Bounce.Shell" ) tar:GiveAmmo( 1, amo )
						end
					end
				else
					if tar.xdeshfull and tar.xdeshield[ 4 ] == 2 and math.random( 1, 100 ) <= tar.xdeshield[ 5 ]*100 then --新星盾
						tar:EmitSound( "Weapon_CombineGuard.Special1" )
						timer.Create( "["..tar:EntIndex().."]xdees_nova", 1, 1, function()
							if IsValid( tar ) and tar:Alive() and tar.xdeshield and tar.xdeshield[ 4 ] == 2 then
								sound.Play( "xdeshe.ShieldNova", tar:GetPos() )
								xdeshe_BroadEffect( "xdeshe_supernova", { Origin = tar:WorldSpaceCenter(), Scale = 2 } )
								util.ScreenShake( tar:WorldSpaceCenter(), 20, 20, 1, 256 )
								for k, v in pairs( ents.FindInSphere( tar:WorldSpaceCenter(), 256 ) ) do
									if IsValid( v ) and v:GetModel() and !v:IsWorld() and v != tar then
										local ddd = DamageInfo()
										ddd:SetDamage( tar.xdeshield[ 1 ] )
										ddd:SetAttacker( tar )
										ddd:SetInflictor( IsValid( tar:GetActiveWeapon() ) and tar:GetActiveWeapon() or tar )
										ddd:SetDamageType( DMG_DISSOLVE )
										ddd:SetDamageForce( ( v:WorldSpaceCenter() -tar:WorldSpaceCenter() ):GetNormalized()*8192 )
										ddd:SetDamagePosition( v:WorldSpaceCenter() )
										v:TakeDamageInfo( ddd )
										if IsValid( v:GetPhysicsObject() ) then
											v:GetPhysicsObject():AddVelocity( ddd:GetDamageForce()/32 )
										end
										v:SetVelocity( ddd:GetDamageForce()/8 )
									end
								end
							end
						end )
					end
					if tar:IsPlayer() then tar:ScreenFade( SCREENFADE.IN, Color( 255, 64, 64, 128 ), 1, 0 ) end
					tar.xdeshfull = nil
				end
			end
		end
		if IsValid( atk ) and atk.xdeshield and atk:GetNWInt( "XDEES_Amount" ) > 0 and atk.xdeshfull then local dam = dmg:GetDamage() --能量盾攻击
			if atk.xdeshield[ 4 ] == 4 and math.random( 1, 100 ) <= atk.xdeshield[ 5 ]*100 then --增幅盾
				if atk:GetNWInt( "XDEES_Amount" ) >= atk.xdeshield[ 1 ] then
					atk.xdeshfull = nil
					atk:SetNWInt( "XDEES_Amount", math.ceil( atk:GetNWInt( "XDEES_Amount" )*0.75 ) )
					atk.xdeshdelay = CurTime() +atk.xdeshield[ 2 ] +0.2
					sound.Play( "xdeshe.ShieldStriker", dmg:GetDamagePosition() )
					xdeshe_BroadEffect( "xdeshe_striker", { Origin = dmg:GetDamagePosition(), Scale = 1 } )
					util.ScreenShake( dmg:GetDamagePosition(), 10, 10, 1, 64 )
					dmg:ScaleDamage( 3 )
					dmg:SetDamageForce( dmg:GetDamageForce()*3 )
				end
			elseif atk.xdeshield[ 4 ] == 6 and math.random( 1, 100 ) <= atk.xdeshield[ 5 ]*100 then --吸血盾
				if atk:GetNWInt( "XDEES_Amount" ) < atk.xdeshield[ 1 ] and dam >= 1 then
					if !dmg:IsDamageType( DMG_DISSOLVE ) and !tar.xdeshspike or tar.xdeshspike <= CurTime() then
						tar.xdeshspike = CurTime() +0.2
						atk:SetNWInt( "XDEES_Amount", math.min( atk.xdeshield[ 1 ], atk:GetNWInt( "XDEES_Amount" ) +math.ceil( dam/4 ) ) )
						atk.xdeshdelay = CurTime() +atk.xdeshield[ 2 ] +0.2
						atk:EmitSound( "xdeshe.ShieldCharge" ) atk:SetNWFloat( "XDEES_Hit", CurTime() +2 )
						dmg:ScaleDamage( 0.75 )
					end
				end
			end
		end
		if tar.XDE_Goat and tar:Health() > 0 then --山羊尸体
			tar:SetHealth( math.max( 0, tar:Health() -dmg:GetDamage() ) )
			if tar:Health() <= 0 then
				timer.Remove( "["..tar:EntIndex().."]xdegoat" )
				tar:StopSound( "xdeshe.GoatB" )
				tar.XDE_Goat = false
				
				local exp = ents.Create( "env_explosion" )
				exp:SetPos( tar:WorldSpaceCenter() )
				exp:SetOwner( atk or tar )
				exp:SetKeyValue( "SpawnFlags", 8 +16 +32 +64 +256 +4096 )
				exp:SetKeyValue( "iMagnitude", 150 )
				exp:SetKeyValue( "iRadiusOverride", 256 )
				util.ScreenShake( tar:WorldSpaceCenter(), 8, 8, 2, 256 )
				exp:Spawn() exp:Activate()
				exp:Fire( "Explode" )
				
				local force = ents.Create( "env_physexplosion" )
				force:SetPos( tar:WorldSpaceCenter() )
				force:SetKeyValue( "SpawnFlags", 2 )
				force:SetKeyValue( "magnitude", 100 )
				force:SetKeyValue( "radius", 256 )
				force:Spawn()
				force:Activate()
				force:Fire( "Explode" )
				sound.Play( "BaseExplosionEffect.Sound", tar:WorldSpaceCenter() )
				
				net.Start( "xdeshe_S2C_CorpseBoom" )
				net.WriteEntity( tar )
				net.Broadcast()
				tar:SetRenderMode( RENDERMODE_NONE )
				tar:DrawShadow( false )
				SafeRemoveEntityDelayed( tar, 1 )
			else
				tar.XDE_NextBaa = CurTime() +math.Rand( 3, 6 )
				tar:EmitSound( "xdeshe.GoatB" )
				if dmg:GetAttacker() != Entity( 0 ) then
					tar:GetPhysicsObject():AddVelocity( dmg:GetDamageForce() )
				end
			end
		end
		if tar:IsPlayer() and tar:GetNWFloat( "XDESHE_Inv" ) > CurTime() then --补给生成器无敌
			if IsValid( atk ) and ( atk:IsNPC() or ( atk:IsPlayer() and atk != tar and tar:GetNWFloat( "XDESHE_Inv" ) <= CurTime() ) ) then
				dmg:SetAttacker( tar )
				atk:TakeDamageInfo( dmg )
				dmg:ScaleDamage( 0 )
				return true
			else
				dmg:ScaleDamage( 0 )
				return true
			end
		end
		if dmg:GetDamage() > 0 and IsValid( atk ) and atk:GetNWFloat( "XDESHE_PP" ) > CurTime() and atk != tar then --力量药加攻
			local mul = math.Round( ( atk:GetNWFloat( "XDESHE_PP" )-CurTime() )/180*4, 1 )
			dmg:ScaleDamage( 1 +mul )
		end
		if dmg:GetDamage() > 1 and tar:GetNWFloat( "XDESHE_PP" ) > CurTime() then --力量药加防
			local mul = math.Clamp( 1 -math.Round( ( tar:GetNWFloat( "XDESHE_PP" )-CurTime() )/360, 1 ), 0, 1 )
			dmg:SetDamage( math.max( 1, dmg:GetDamage()*mul ) )
		end
		if IsValid( atk ) and IsValid( atk:GetNWEntity( "XDEDDC" ) ) and atk:GetNWEntity( "XDEDDC" ):GetXDE_OW() == atk then --龙降日随从标记
			local ent = atk:GetNWEntity( "XDEDDC" )  local mk, mkp, mkh = ent:GetXDE_MK(), ent:GetXDE_MKP(), ent:GetXDE_MKH()
			if IsValid( mk ) and mk == tar and mkp > CurTime() and atk != ent then dmg:ScaleDamage( 1.25 ) end
		end
	end )
	hook.Add( "PostEntityTakeDamage", "xdeshe_petd", function( tar, dmg )
		local atk, inf = dmg:GetAttacker(), dmg:GetInflictor()
		if IsValid( inf ) and ( inf:GetClass() == "npc_she_vgoat" or inf:GetClass() == "npc_she_trigger" ) and IsValid( tar ) and tar != inf:GetXDE_OW() and ( tar:IsNPC() or tar:IsPlayer() ) and tar:Health() > 0 then --龙降日标记
			inf:SetXDE_MK( tar )
			inf:SetXDE_MKP( CurTime() +5 )
			inf:SetXDE_MKH( tar:Health() )
		end
		if IsValid( atk ) and atk:IsPlayer() and IsValid( atk:GetNWEntity( "XDEDDC" ) ) and atk:GetNWEntity( "XDEDDC" ):GetXDE_OW() == atk then --龙降日仇恨
			if IsValid( tar ) and atk != tar and atk:GetNWEntity( "XDEDDC" ):Disposition( tar ) != D_HT then
				atk:GetNWEntity( "XDEDDC" ):AddEntityRelationship( tar, D_HT, 1 )
			end
		end
		if IsValid( tar ) and tar:IsPlayer() and IsValid( tar:GetNWEntity( "XDEDDC" ) ) and tar:GetNWEntity( "XDEDDC" ):GetXDE_OW() == tar then --龙降日仇恨
			if IsValid( atk ) and atk != tar and tar:GetNWEntity( "XDEDDC" ):Disposition( atk ) != D_HT then
				tar:GetNWEntity( "XDEDDC" ):AddEntityRelationship( atk, D_HT, 1 )
			end
		end
	end )
	hook.Add( "Think", "xdeshe_tk", function()
		if xdesh_users and #xdesh_users > 0 then local tem = {}  --能量盾充能
			for k, v in pairs( xdesh_users ) do
				if !IsValid( v ) or ( !v:IsNPC() and !v:IsPlayer() ) or tem[ v:EntIndex() ] then
					table.remove( xdesh_users ) continue
				end
				if ( v:IsNPC() and v:GetNPCState() == NPC_STATE_DEAD ) or ( v:IsPlayer() and !v:Alive() ) then
					table.remove( xdesh_users ) continue
				end
				if v.xdeshield and v.xdeshdelay and v.xdeshdelay <= CurTime() then v.xdeshdelay = CurTime() +0.1
					local maa, amo = v.xdeshield[ 1 ], v:GetNWInt( "XDEES_Amount" )
					if maa > amo then v:SetNWInt( "XDEES_Amount", math.min( maa, amo +v.xdeshield[ 3 ] ) )
					elseif !v.xdeshfull then v.xdeshfull = true end
				end
			end
		end
	end )
	hook.Add( "PlayerUse", "xdeshe_pu", function( ply, ent )
		if IsValid( ent:GetParent() ) and ent:GetParent():GetClass() == "sent_she_manhole" then
			ent:GetParent():Use( ply )
			return false
		end
	end )
	hook.Add( "AcceptInput", "xdeshe_ai", function( ent, name )
		if ent:GetClass() == "env_fire" and ent.XDE_Stick == true and !ent.XDE_Ignited then
			if name == "StartFire" then ent.XDE_Ignited = true
				local hov = ent.XDE_Hover or IsValid( ent:GetParent() )
				local par = ents.Create( "info_particle_system" )
				par:SetKeyValue( "effect_name", hov and "mine_fire_burn" or "mine_fire" )
				par:SetKeyValue( "start_active", "1" )
				par:SetName( "["..par:EntIndex().."]xdemo_explo" )
				par:SetKeyValue( "cpoint10", par:GetName() )
				par:SetKeyValue( "cpoint11", par:GetName() )
				par:SetPos( ent:GetPos() ) par:SetAngles( Angle( 0, math.random( 0, 360 ), 0 ) )
				par:SetOwner( IsValid( ent.Owner ) and ent.Owner or Entity( 0 ) )
				if hov then par:SetParent( ent:GetParent() ) end
				par:Spawn() par:Activate() par.XDE_Stick = true
				par:EmitSound( "ambient/fire/mtov_flame2.wav", 75, math.random( 150, 160 ), 0.6 )
				SafeRemoveEntityDelayed( par, math.random( 20, 30 ) )
				ent:Remove() local tname = "["..par:EntIndex().."]xdeshe_fire"
				timer.Create( tname, 1, 0, function()
					if !IsValid( par ) then timer.Remove( tname ) return end
					if par:WaterLevel() >= 2 then par:Remove() return end
					local own = IsValid( par.Owner ) and par.Owner or Entity( 0 )
					local dmg = DamageInfo()
					dmg:SetDamage( 10 ) dmg:SetDamagePosition( par:GetPos() )
					dmg:SetAttacker( own ) dmg:SetInflictor( par )
					dmg:SetDamageType( DMG_BURN )
					util.BlastDamageInfo( dmg, par:GetPos(), math.random( 64, 96 ) )
				end )
			end
		end
	end )

	net.Receive( "xdeshe_C2S_MenuClose", function( len, ply )
		if IsValid( ply ) and ply.XDE_Using then
			if ply.XDE_Using.GetXDE_US and ply.XDE_Using:GetXDE_US() == ply then
				ply.XDE_Using:SetXDE_US( nil )
			end
			ply.XDE_Using = nil
		end
	end )
	net.Receive( "xdeshe_C2S_MenuAction", function( len, ply )
		if len > 1024 then return end
		xdeshe_MenuAction( ply, net.ReadString(), net.ReadString() )
	end )
else
	if xdeshe_vguis then for k, v in pairs( xdeshe_vguis ) do if v then v:Remove() end end end
	xdeshe_menus = {}  xdeshe_vguis = {}  xdeshe_cam = false  xdeshe_mats = {}  xdeshe_notes = {}
	xdeshe_mark = nil   xdeshe_mtype = nil  xdeshe_delay = 0
	xdeshe_hats = 0  xdeshe_hatlerp = 0  xdeshe_hatchanged = 0  xdeshe_thats = {}
	surface.CreateFont( "xdeshe_Font1", { font = "CSD", size = 96, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font2", { font = "keifont", size = 24, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font3", { font = "keifont", size = 32, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font4", { font = "keifont", size = 16, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font5", { font = "keifont", size = 12, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font6", { font = "keifont", size = 160, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font7", { font = "keifont", size = 120, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font8", { font = "keifont", size = 192, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font9", { font = "keifont", size = 64, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font10", { font = "keifont", size = 48, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font11", { font = "HalfLife2", size = 64, weight = 1, antialias = true } )
	surface.CreateFont( "xdeshe_Font12", { font = "CSD", size = 36, weight = 1, antialias = true } )
	
	xdeshe_langs, xdeshe_lents = {}, {}
	include( "somehandysents/languages.lua" )
	local ln, lg = GetConVar( "gmod_language" ):GetString(), "en"
	if ln != nil and istable( xdeshe_langs[ ln ] ) and istable( xdeshe_lents[ ln ] ) then lg = GetConVar( "gmod_language" ):GetString() end
	for holder, text in pairs( xdeshe_langs[ lg ] ) do language.Add( "xdeshe."..holder, text ) end
	for holder, text in pairs( xdeshe_lents[ lg ] ) do language.Add( "xdeshe."..holder, text ) end
	list.Set( "ContentCategoryIcons", xdeshe_langs[ lg ][ "Category" ], "icon16/lemon.png" )
	local xdeshe_lent = false

	function xdeshe_Circle( x, y, radius, seg, per ) --圆形辅函
		per = isnumber( per ) and per or 1
		local cir = {}
		table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
		for i = 0, seg do
			if i > math.ceil( seg*per ) then break end
			local a = math.rad( ( i/seg )*-360 +180 )
			table.insert( cir, { x = x +math.sin( a )*radius, y = y +math.cos( a )*radius, u = math.sin( a )/2 +0.5, v = math.cos( a )/2 +0.5 } )
		end
		table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
		local a = math.rad( 0 )
		surface.DrawPoly( cir )
	end
	function xdeshe_CutBox( per, x, y, w, h, lu, ru, rd, ld ) --切盒辅函
		per = isnumber( per ) and per or 1
		local box = {}
		table.insert( box, { x = x, y = y +per } )
		if lu then
			table.insert( box, { x = x +per, y = y } )
		else
			table.insert( box, { x = x, y = y } )
		end
		if ru then
			table.insert( box, { x = x +w -per, y = y } )
			table.insert( box, { x = x +w, y = y +per } )
		else
			table.insert( box, { x = x +w, y = y } )
		end
		if rd then
			table.insert( box, { x = x +w, y = y +h -per } )
			table.insert( box, { x = x +w -per, y = y +h } )
		else
			table.insert( box, { x = x +w, y = y +h } )
		end
		if ld then
			table.insert( box, { x = x +per, y = y +h } )
			table.insert( box, { x = x, y = y +h -per } )
		else
			table.insert( box, { x = x, y = y +h } )
		end
		surface.DrawPoly( box )
	end
	function xdeshe_MenuRegister( id, func ) --苟使界面登录
		xdeshe_menus[ id ] = func  xdeshe_vguis[ id ] = nil
	end
	function xdeshe_OnceMat( str ) --Material只跑一次
		if !xdeshe_mats[ str ] then xdeshe_mats[ str ] = Material( str ) end
		return xdeshe_mats[ str ]
	end

	hook.Add( "HUDPaint", "xdeshe_ipe", function()
		if !xdeshe_lent then xdeshe_lent = true
			for holder, text in pairs( xdeshe_lents[ lg ] ) do
				if string.Left( holder, 4 ) == "npc_" then
					language.Add( string.Replace( holder, "npc_", "npc_she_" ), text )
				elseif string.Left( holder, 4 ) == "sent" then
					language.Add( string.Replace( holder, "sent_", "sent_she_" ), text )
				else language.Add( holder, text ) end
			end
		end
	end )
	hook.Add( "PrePlayerDraw", "xdeshe_ppd", function( ply )
		if ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() and ply:Crouching() then --躲藏隐藏玩家
			return true 
		end
		local veh = ply:GetVehicle() --睡袋隐藏玩家
		if ply:Alive() and IsValid( veh ) and IsValid( veh:GetParent() ) and veh:GetParent():GetClass() == "sent_she_sleep" then
			if veh:GetVehicleClass() == "Seat_Airboat" and veh:GetNWBool( "XDE_Bag" ) then
				return true
			end
		end
	end )
	hook.Add( "CalcView", "xdeshe_cv", function( ply, pos, angles, fov )
		if ply:Alive() and IsValid( ply:GetNWEntity( "XDE_Emplace" ) ) and ply:GetNWEntity( "XDE_Emplace" ):GetXDE_US() == ply then --使用炮塔视角
			local sel = ply:GetNWEntity( "XDE_Emplace" )
			local bone = sel:LookupBone( "ValveBiped.UpDown" )
			if bone then
				local mat = sel:GetBoneMatrix( bone )
				local pp, aa = mat:GetTranslation(), mat:GetAngles()
				if sel:GetClass() == "sent_she_turret1" then pp = pp -aa:Right()*12 +aa:Up()*8
				elseif sel:GetClass() == "sent_she_turret2" then pp = pp -aa:Right()*5 +aa:Up()*4 end
				local view = {
					origin = pp,
					angles = angles,
					fov = fov,
					drawviewer = false
				}
				return view
			end
		end
	end )
	hook.Add( "PlayerBindPress", "xdeshe_pbp", function( ply, bind, pressed )
		if IsValid( ply:GetNWEntity( "XDE_Sniper" ) ) and ply:GetNWBool( "XDE_SniperZoom" ) then --支援狙击手键位
			if string.find( bind, "invprev" ) then
				xdesniper_fovinit = math.Clamp( xdesniper_fovinit-5, 5, 95 )
				return true
			elseif string.find( bind, "invnext" ) then
				xdesniper_fovinit = math.Clamp( xdesniper_fovinit+5, 5, 95 )
				return true
			end
			if string.find( bind, "+attack2" ) then
				xdesniper_fovinit = 95
				return true
			end
			if string.find( bind, "+attack" ) then
				net.Start( "xdeshe_C2S_FireSniper" ) net.SendToServer()
				return true
			end
		end
	end )
    hook.Add( "ShouldDrawLocalPlayer", "xdeshe_sdlp", function( ply )
        if xdeshe_cam or xdeshe_mir then return true end --RT界面显示自己
    end )
	hook.Add( "AdjustMouseSensitivity", "xdeshe_ams", function( def )
		local ply, ent = LocalPlayer(), LocalPlayer():GetNWEntity( "XDE_Sniper" )
		if IsValid( ent ) and IsValid( xdeshe_vguis[ "snipercam" ] ) and xdeshe_vguis[ "snipercam" ].E_Entity == ent
		and IsValid( ent:GetWeapon() ) and ent:GetXDE_IJ() <= 0 and ent:GetXDE_OW() == ply and ent.XDE_RT and ply:GetNWBool( "XDE_SniperZoom" ) then --支援狙击手鼠标灵敏调整
			return xdesniper_fovlerp/200
		end
	end )
    hook.Add( "PreRender", "xdeshe_pr", function()
		local ply, ent = LocalPlayer(), LocalPlayer():GetNWEntity( "XDE_Sniper" )
		if IsValid( ent ) and IsValid( xdeshe_vguis[ "snipercam" ] ) and xdeshe_vguis[ "snipercam" ].E_Entity == ent
		and IsValid( ent:GetWeapon() ) and ent:GetXDE_IJ() <= 0 and ent:GetXDE_OW() == ply and ent.XDE_RT then --支援狙击手RT界面
			render.PushRenderTarget( ent.XDE_RT )
				local rec = math.Clamp( ( ent:GetXDE_RC() -CurTime() )/0.5, 0, 1 )
				local pit, yaw = ply:EyeAngles().pitch, ply:EyeAngles().yaw
				if !ent:GetActive() or !ply:GetNWBool( "XDE_SniperZoom" ) then pit, yaw = ent:GetXDE_Pit(), ent:GetXDE_Yaw() end
				local pp, aa = LocalToWorld( Vector( -2, math.Rand( -rec, rec )*( 100 -xdesniper_fovinit/100 ), math.Rand( -rec, rec )*( 100 -xdesniper_fovinit/100 ) )*0.5, Angle( pit, yaw, 0 ), ent:GetShootPos(), Angle( 0, 0, 0 ) )
				local lev = math.cos( -math.pi/2 +math.Clamp( ent:GetXDE_LV() -CurTime(), 0, math.pi/4 )*4 )
				xdeshe_cam = true
				render.OverrideAlphaWriteEnable( true, true )
				ent:SetNoDraw( true )
				if IsValid( ent:GetWeapon() ) then ent:GetWeapon():SetNoDraw( true ) end
				render.RenderView( {
					origin = pp,
					angles = Angle( aa.pitch +lev*3, aa.yaw, lev*9 ),
					x = 0, y = 0, w = 1024, h = 1024,
					drawviewmodel = false,
					bloomtone = false,
					fov = math.Clamp( xdesniper_fovlerp +rec*5, 1, 100 ),
				} )
				if IsValid( ent:GetWeapon() ) then ent:GetWeapon():SetNoDraw( false ) end
				ent:SetNoDraw( false )
				xdeshe_cam = false
			render.PopRenderTarget()
		end
		if IsValid( ply ) and IsValid( xdeshe_vguis[ "mortar" ] ) and !xdeshe_vguis[ "mortar" ].B_Close and xdeshe_mort then --迫击炮RT界面
			render.PushRenderTarget( xdeshe_mort )
				local pp = xdeshe_vguis[ "mortar" ].V_Pos
				xdeshe_cam = true  cam.Start2D()
				render.OverrideAlphaWriteEnable( true, true )
				render.RenderView( {
					origin = pp,
					angles = Angle( 90, 0, 0 ),
					x = 0, y = 0, w = ScrW(), h = ScrH(),
					drawviewmodel = false, bloomtone = false,
					fov = xdeshe_vguis[ "mortar" ].N_FOV,
				} )
				cam.End2D()  xdeshe_cam = false
			render.PopRenderTarget()
		end
    end )
	hook.Add( "Think", "xdeshe_ctk", function()
		local ply = LocalPlayer()
		if #xdeshe_thats > 0 then --帽子回收模型
			for k, v in ipairs( xdeshe_thats ) do
				if !IsValid( v ) then table.remove( xdeshe_thats, k ) continue end
				if !IsValid( v.Owner ) then v:Remove() table.remove( xdeshe_thats, k ) end
			end
		end
		if istable( xdeshe_ghost ) and isvector( xdeshe_ghost.pos ) and isvector( xdeshe_ghost.lpos ) then --赫紫鬼音效
			if !xdeshe_ghost.note then xdeshe_ghost.note = true
				xdeshe_HelperNote( LocalPlayer(), "sent_erchius", { "#xdeshe.Erchius1", "#xdeshe.Erchius2", "#xdeshe.Erchius3", "#xdeshe.Erchius4" } )
			end
			local amo = math.Clamp( ply:GetNWInt( "xdeerchius" ), 0, 512 )/512
			local dist = xdeshe_ghost.pos:Distance( ply:GetPos() )
			if !xdeshe_ghost.snd1 or !xdeshe_ghost.snd1:IsPlaying() or !xdeshe_ghost.snd2 or !xdeshe_ghost.snd2:IsPlaying() then
				if xdeshe_ghost.snd1 then xdeshe_ghost.snd1:Stop() xdeshe_ghost.snd1 = nil end
				if xdeshe_ghost.snd2 then xdeshe_ghost.snd2:Stop() xdeshe_ghost.snd2 = nil end
				xdeshe_ghost.snd1 = CreateSound( Entity( 0 ), "ambient/atmosphere/ambience6.wav", nil )
				xdeshe_ghost.snd1:SetSoundLevel( 0 ) xdeshe_ghost.snd1:Play()
				xdeshe_ghost.snd1:ChangePitch( 80 ) xdeshe_ghost.snd1:ChangeVolume( 0 )
				xdeshe_ghost.snd2 = CreateSound( Entity( 0 ), "ambient/levels/caves/cave_howl_loop1.wav", nil )
				xdeshe_ghost.snd2:SetSoundLevel( 0 ) xdeshe_ghost.snd2:Play()
				xdeshe_ghost.snd2:ChangePitch( 150, 0 ) xdeshe_ghost.snd2:ChangeVolume( 0 )
			else
				xdeshe_ghost.snd1:ChangeVolume( math.Clamp( 3072 -dist, 0, 3072 )/3072*0.75, 0 )
				xdeshe_ghost.snd1:ChangePitch( 100 +amo*50 )

				xdeshe_ghost.snd2:ChangeVolume( math.Clamp( 2048 -dist, 0, 2048 )/2048*0.5, 0 )
				xdeshe_ghost.snd2:ChangePitch( 80 +amo*100 )
			end
			if xdeshe_ghost.nextsnd < SysTime() then xdeshe_ghost.nextsnd = SysTime() +math.Rand( 16, 32 )
				if xdeshe_ghost.snd3 then xdeshe_ghost.snd3:Stop()  xdeshe_ghost.snd3 = nil end
				local tabs = {
					"ambient/levels/citadel/strange_talk1.wav",
					"ambient/levels/citadel/strange_talk3.wav",
					"ambient/levels/citadel/strange_talk4.wav",
					"ambient/levels/citadel/strange_talk5.wav",
					"ambient/levels/citadel/strange_talk6.wav",
					"ambient/levels/citadel/strange_talk7.wav",
					"ambient/levels/citadel/strange_talk8.wav",
					"ambient/levels/citadel/strange_talk9.wav",
					"ambient/levels/citadel/strange_talk10.wav",
					"ambient/levels/citadel/strange_talk11.wav",
					"ambient/atmosphere/cave_hit1.wav",
					"ambient/atmosphere/cave_hit2.wav",
					"ambient/atmosphere/cave_hit3.wav",
					"ambient/atmosphere/cave_hit4.wav",
					"ambient/atmosphere/cave_hit5.wav",
					"ambient/atmosphere/cave_hit6.wav"
				}
				xdeshe_ghost.snd3 = CreateSound( Entity( 0 ), tabs[ math.random( #tabs ) ], nil )
				xdeshe_ghost.snd3:SetSoundLevel( 0 ) xdeshe_ghost.snd3:Play()
				xdeshe_ghost.snd3:ChangeVolume( math.Clamp( 2048 -dist, 0, 2048 )/2048*0.5, 0 )
				xdeshe_ghost.snd3:ChangePitch( 100 -amo*20, 0.25 )
			end
		elseif istable( xdeshe_ghost ) then
			if xdeshe_ghost.snd1 then xdeshe_ghost.snd1:Stop() xdeshe_ghost.snd1 = nil end
			if xdeshe_ghost.snd2 then xdeshe_ghost.snd2:Stop() xdeshe_ghost.snd2 = nil end
			if xdeshe_ghost.snd3 then xdeshe_ghost.snd3:Stop()  xdeshe_ghost.snd3 = nil end
			if xdeshe_ghost.emitter then xdeshe_ghost.emitter:Finish() xdeshe_ghost.emitter = nil end
		end
		if xdesh_update and xdesh_update <= CurTime() and xdesh_users then xdesh_update = CurTime() +0.5 --能量盾低计算查找
			xdesh_users = {}
			for k, v in pairs( ents.GetAll() ) do
				if IsValid( v ) and ( v:IsNPC() or v:IsPlayer() ) and v:GetNWInt( "XDEES_Amount" ) > 0 then
					table.insert( xdesh_users, v )
				end
			end
		end
	end )
	hook.Add( "RenderScreenspaceEffects", "xdeshe_pse", function()
		local ply = LocalPlayer()
		if xdebs_hide and xdebs_hide <= SysTime() then
			if xdebs_o2 != ( ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:Crouching() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() ) then
				xdebs_o2 = ( ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:Crouching() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() )
				xdebs_hide = SysTime() +0.5
			end
		end
		if IsValid( ply ) and xdeshe_ppm2 and isbool( xdeshe_sleep ) then --睡袋黑暗效果
			local veh = ply:GetVehicle()
			local bol = ply:Alive() and IsValid( ply:GetVehicle() ) and ply:GetNWFloat( "XDECP_Disturb" ) <= CurTime() and IsValid( veh:GetParent() )
			and veh:GetParent():GetClass() == "sent_she_sleep" and veh:GetVehicleClass() == "Seat_Airboat" and veh:GetNWBool( "XDE_Bag" )
			if xdeshe_sleep != bol then
				local rem = math.max( 0, xdeshe_slerp -SysTime() )
				xdeshe_sleep, xdeshe_slerp = bol, SysTime() +( bol and 3.3*( 1 -rem/1.1 ) or 1.1*( 1 -rem/3.3 ) )
			end

			if xdeshe_sleep or xdeshe_slerp > SysTime() then
				local ler = math.Clamp( xdeshe_sleep and 1 -( xdeshe_slerp-SysTime() )/3.3 or ( xdeshe_slerp -SysTime() ), 0, 1 )
				draw.NoTexture()
				surface.SetDrawColor( 0, 0, 0, 250*ler )
				surface.DrawRect( 0, 0, ScrW(), ScrH() )
				surface.SetDrawColor( 255, 255, 255, 255*ler )
				surface.SetMaterial( xdeshe_ppm2 )
				surface.DrawTexturedRectRotated( ScrW()*0.25 -1, ScrH()*0.75, ScrW()/2 +2, ScrH()/2, 180 )
				surface.DrawTexturedRectRotated( ScrW()*0.75, ScrH()*0.25 -1, ScrW()/2, ScrH()/2 +2, 0 )
				surface.DrawTexturedRectRotated( ScrW()*0.25 -1, ScrH()*0.25 -1, ScrH()/2 +2, ScrW()/2 +2, 90 )
				surface.DrawTexturedRectRotated( ScrW()*0.75, ScrH()*0.75, ScrH()/2, ScrW()/2, 270 )
			end
		end
		if xdebs_hide and ( xdebs_o2 or xdebs_hide > SysTime() ) and xdeshe_ppm2 and IsValid( ply ) and ply:Alive() then --躲藏效果
			local amo = math.Clamp( ( xdebs_hide -SysTime() )/0.5, 0, 1 )
			if xdebs_o2 then amo = 1-amo end
			surface.SetDrawColor( Color( 255, 255, 255, amo*255 ) )
			surface.SetMaterial( xdeshe_ppm2 )
			surface.DrawTexturedRectRotated( ScrW()*0.25 -1, ScrH()*0.75, ScrW()/2 +2, ScrH()/2, 180 )
			surface.DrawTexturedRectRotated( ScrW()*0.75, ScrH()*0.25 -1, ScrW()/2, ScrH()/2 +2, 0 )
			surface.DrawTexturedRectRotated( ScrW()*0.25 -1, ScrH()*0.25 -1, ScrH()/2 +2, ScrW()/2 +2, 90 )
			surface.DrawTexturedRectRotated( ScrW()*0.75, ScrH()*0.75, ScrH()/2, ScrW()/2, 270 )
		end
		if IsValid( ply ) and ply:Alive() then --赫紫鬼视觉效果
			if istable( xdeshe_ghost ) and isvector( xdeshe_ghost.pos ) and isvector( xdeshe_ghost.lpos ) then
				local dist = ply:GetPos():Distance( xdeshe_ghost.lpos )
				local per = math.Clamp( 768 -dist, 0, 768 )/768
				if per > 0 then
					DrawSharpen( 4, math.Clamp( per, 0, 1 )*4 )
					local ErcG_Screen = {
						["$pp_colour_addr"] = per/2,
						["$pp_colour_addg"] = 0,
						["$pp_colour_addb"] = per/2,
						["$pp_colour_brightness"] = 0,
						["$pp_colour_contrast"] = 1 -per,
						["$pp_colour_colour"] = 1 -per,
						["$pp_colour_mulr"] = 0,
						["$pp_colour_mulg"] = 0,
						["$pp_colour_mulb"] = 0
					}
					DrawColorModify( ErcG_Screen )
				end
			end
			if ply:GetNWFloat( "XDESHE_PP" ) > CurTime() and xdeshe_ppm1 then --力量药视觉
				local amo = math.Clamp( ( ply:GetNWFloat( "XDESHE_PP" ) -CurTime() )/180, 0, 1 )
				surface.SetDrawColor( Color( 255, 255, 255, 255*amo ) )
				surface.SetMaterial( xdeshe_ppm2 )
				surface.DrawTexturedRectRotated( ScrW()*0.25 -1, ScrH()*0.75, ScrW()/2 +2, ScrH()/2, 180 )
				surface.DrawTexturedRectRotated( ScrW()*0.75, ScrH()*0.25 -1, ScrW()/2, ScrH()/2 +2, 0 )
				surface.DrawTexturedRectRotated( ScrW()*0.25 -1, ScrH()*0.25 -1, ScrH()/2 +2, ScrW()/2 +2, 90 )
				surface.DrawTexturedRectRotated( ScrW()*0.75, ScrH()*0.75, ScrH()/2, ScrW()/2, 270 )
				surface.SetDrawColor( Color( 64*amo, 0, 0, 64*amo ) )
				surface.DrawRect( 0, 0, ScrW(), ScrH() )
				surface.SetDrawColor( Color( 0, 0, 0, 128*amo ) )
				surface.SetMaterial( xdeshe_ppm1 )
				surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )
			end
		end
	end )
	hook.Add( "DrawOverlay", "xdeshe_do", function()
		local ply = LocalPlayer()
		if IsValid( ply ) and ply:Alive() and ply:GetNWFloat( "XDESHE_Inv" ) > CurTime() then --无敌彩虹视觉效果
			render.SetColorMaterial()
			local col = HSVToColor( SysTime()%360*100, 1, 1 )
			surface.SetDrawColor( col.r, col.g, col.b, math.Clamp( ply:GetNWFloat( "XDESHE_Inv" )-CurTime(), 0, 1 )*8 )
			surface.DrawRect( 0, 0, ScrW(), ScrH() )
		end
        if xdeshe_mark != nil and xdeshe_mtype != nil and vgui.CursorVisible() then --悬停提示
            if xdeshe_delay <= 0 then xdeshe_delay = SysTime() +0.5 end
            local alp, str = ( 1 -math.Clamp( ( xdeshe_delay -SysTime() )/0.2, 0, 1 ) )*255, ""
            local xx, yy = input.GetCursorPos()
            xx = xx +20  yy = yy +20
			if xdeshe_mtype == "xdegd" and xdegd and istable( xdegd.ItemGet( xdeshe_mark ) ) then
				local tab = xdegd.ItemGet( xdeshe_mark )
				str = xdegd.ItemGet( xdeshe_mark ).Helper
				if tab.Seed then str = str.."\n"
					str = str..language.GetPhrase( "xdeshe.GDDemandW" ).."  -  "..tab.WaterNeed[ 1 ].." ~ "..tab.WaterNeed[ 2 ].."\n"
					str = str..language.GetPhrase( "xdeshe.GDDemandF" ).."  -  "..tab.FertileNeed[ 1 ].." ~ "..tab.FertileNeed[ 2 ].."\n"
					str = str..language.GetPhrase( "xdeshe.GDGTime" ).."  -  "..tab.Growth.."\n"
				end
			elseif xdeshe_mtype == "xdesc" and xdesc then
				str = language.GetPhrase( "xdeshe.SC_I"..xdeshe_mark )
			end
			if str != "" then
				local mark = markup.Parse( "<color=255,255,255,255><font=xdeshe_Font4>"..str.."</color></font>", 256 )
				surface.SetDrawColor( 64, 64, 64, alp )
				surface.DrawRect( xx -8, yy -8, mark:GetWidth() +16, mark:GetHeight() +16 )
				surface.SetDrawColor( 100, 100, 100, alp )
				surface.DrawOutlinedRect( xx -8, yy -8, mark:GetWidth() +16, mark:GetHeight() +16, 2 )
				surface.SetDrawColor( 192, 192, 192, alp )
				surface.DrawOutlinedRect( xx -8, yy -8, mark:GetWidth() +16, mark:GetHeight() +16 )
				mark:Draw( xx, yy, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, alp )
			end
        elseif xdeshe_delay > 0 then xdeshe_delay = 0 end
		if istable( xdeshe_ghost ) and xdeshe_ghost.pos != nil then --赫紫鬼渲染
			local pos = xdeshe_ghost.pos  local dist = ply:GetPos():Distance( pos )
			local alp = math.Clamp( 2048 -dist, 0, 1556 )/2048*255
			if xdeshe_ghost.nextframe <= SysTime() then
				xdeshe_ghost.nextframe = SysTime() +0.1
				xdeshe_ghost.frame = ( xdeshe_ghost.frame >= 12 and 1 or xdeshe_ghost.frame +1 )
			end
			local anger = ( ( dist <= 768 and ply:Health() > 0 ) and 2 or 1 )
			xdeshe_ghost.lpos = xdeshe_ghost.lpos == nil and xdeshe_ghost.pos or Lerp( 0.25, xdeshe_ghost.lpos, pos )
			local ang = ( LocalPlayer():GetPos() -xdeshe_ghost.lpos ):Angle()
			cam.Start3D()
			render.SetMaterial( xdeshe_ghost.anims[ anger ][ xdeshe_ghost.frame ] )
			render.DrawSprite( xdeshe_ghost.lpos, 256, 256, Color( 192, 192, 192, alp ) )
			if xdeshe_ghost.pos:Distance( ply:GetPos() ) <= 768 and ply:GetNWInt( "xdeerchius" ) > 0 and ply:Alive() then
				if !xdeshe_ghost.emitter then xdeshe_ghost.emitter = ParticleEmitter( ply:WorldSpaceCenter() ) else
					xdeshe_ghost.emitter:SetPos( ply:WorldSpaceCenter() )
					if xdeshe_ghost.nextemit <= CurTime() then xdeshe_ghost.nextemit = CurTime() +0.25
						local particle = xdeshe_ghost.emitter:Add( "particle/particle_glow_02", ply:WorldSpaceCenter() )
						if particle then
							particle:SetLifeTime( 0 )
							particle:SetDieTime( 1 )
							particle:SetStartAlpha( 192 )
							particle:SetEndAlpha( 0 )
							local Siz = math.Rand( 28, 36 )
							particle:SetStartSize( 0 )
							particle:SetEndSize( Siz )
							particle:SetRoll( math.random( 0, 360 ) )
							particle:SetRollDelta( math.Rand( -2, 2 ) )
							particle:SetColor( 255, 128, 255 )
							particle:SetAirResistance( 32 )
							particle:SetThinkFunction( function( particle )
								if xdeshe_ghost.lpos then
									particle:SetGravity( ( xdeshe_ghost.lpos -particle:GetPos() ):GetNormalized()*256 )
									particle:SetNextThink( CurTime() +0.1 )
								end
							end ) particle:SetNextThink( CurTime() +0.1 )
						end
					end
				end
			end
			cam.End3D()
		end
	end )
	hook.Add( "PreDrawHalos", "xdeshe_pdh", function()
		local ply = LocalPlayer()
		if IsValid( ply ) and ply:Alive() and ply:GetNWFloat( "XDESHE_Rev" ) > CurTime() then --补给生成器透视
			local ler = math.Clamp( ply:GetNWFloat( "XDESHE_Rev" )-CurTime(), 0, 1 )
			for k, v in pairs( ents.FindInSphere( ply:GetPos(), 2048 ) ) do
				if IsValid( v ) and v != ply and ( v:IsNPC() or v:IsPlayer() or v:IsNextBot() ) and v:Health() > 0 then
					local per = math.Clamp( v:Health()/v:GetMaxHealth(), 0, 1 )
					halo.Add( { v }, Color( 255, per*255, per*255, ler*255 ), 1, 0, 0, true, true )
				end
			end
		end
	end )
	local Hat = xdeshe_OnceMat( "xdeedited/hat.png" )
	hook.Add( "HUDPaint", "xdeshe_hudp", function()
		local ply = LocalPlayer()
		if ply:Alive() and istable( xdeshe_chopper ) and #xdeshe_chopper > 0 then --迷你直升机准星
			for k, v in ipairs( xdeshe_chopper ) do
				if !IsValid( v ) then table.remove( xdeshe_chopper, k ) continue end
				if v:GetXDE_OW() != ply then continue end
				local pos = util.TraceHull( {
					start = v:WorldSpaceCenter(),
					endpos = v:WorldSpaceCenter() +ply:EyeAngles():Forward()*4096,
					filter = v,
					mins = Vector( -1, -1, -1 ),
					maxs = Vector( 1, 1, 1 )
				} ).HitPos:ToScreen()
				surface.SetMaterial( xdeshe_mat )  surface.SetDrawColor( 0, 255, 255 )
				surface.DrawTexturedRect( pos.x -16, pos.y -16, 32, 32 )
			end
		end
		if xdebs_lerp and xdebs_lerp <= SysTime() then
			if xdebs_on != ( ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() ) then
				xdebs_on = ( ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() )
				xdebs_lerp = SysTime() +0.25
			end
		end
		if xdebs_lerp and ( xdebs_on or xdebs_lerp > SysTime() ) then --躲藏提示字
			local alp = math.Clamp( ( xdebs_lerp -SysTime() )/0.25, 0, 1 )
			if xdebs_on then alp = 1-alp end
			if ply:GetNWFloat( "XDESHE_Found" ) > CurTime() then
				draw.SimpleTextOutlined( "#xdeshe.Bush_Exposed", "xdeshe_Font3", ScrW()/2, ScrH()*0.6 +16*alp,
				Color( 255, 0, 0, alp*255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, alp*255 ) )
			else
				if xdebs_o2 then
					draw.SimpleTextOutlined( "#xdeshe.Bush_Hiding", "xdeshe_Font3", ScrW()/2, ScrH()*0.6 +16*alp,
					Color( 255, 255, 255, alp*255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, alp*255 ) )
				else
					local txt = language.GetPhrase( "xdeshe.Bush_Hold1" ).." "
					txt = txt..string.upper( input.LookupBinding( "+duck", true ) or "???" )
					txt = txt.." "..language.GetPhrase( "xdeshe.Bush_Hold2" )
					draw.SimpleTextOutlined( txt, "xdeshe_Font3", ScrW()/2, ScrH()*0.6 +16*alp,
					Color( 255, 255, 255, alp*255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, alp*255 ) )
				end
			end
		end

		if ply:GetNWInt( "XDESHE_Hats" ) > 0 or xdeshe_hats > 0 or xdeshe_hatlerp > SysTime() then --帽子
			local hats = ply:GetNWInt( "XDESHE_Hats" )
			if xdeshe_hats != hats then
				if xdeshe_hats > 0 and hats <= 0 then xdeshe_hatchanged = 1 --帽子用尽
				elseif xdeshe_hats <= 0 and hats > 0 then xdeshe_hatchanged = 2 --帽子初始
				elseif xdeshe_hats > hats then xdeshe_hatchanged = 3 else xdeshe_hatchanged = 4 end --帽子消耗/拾取
				xdeshe_hats, xdeshe_hatlerp = hats, SysTime() +0.5
			end
			local ler, alp = math.Clamp( ( xdeshe_hatlerp-SysTime() )/0.5, 0, 1 ), 255
			if xdeshe_hatchanged == 2 then alp = ( 1-ler )*255 elseif xdeshe_hatchanged == 1 then alp = ler*255 end

			surface.SetMaterial( Hat ) surface.SetDrawColor( 255, 255, 255, alp )
			local xx, yy = ScrW()*0.025, ScrH()*0.78
			surface.DrawTexturedRectRotated( xx, yy, 64, 64, math.sin( SysTime()*40 )*ler*10 )
			local col = Color( 255, 255, 255 )
			if xdeshe_hatchanged == 1 or xdeshe_hatchanged == 3 then col = Color( 255, 255*( 1-ler ), 255*( 1-ler ) )
			else col = Color( 255*( 1-ler ), 255, 255*( 1-ler ), alp ) end
			draw.SimpleTextOutlined( "x"..hats, "xdeshe_Font2", xx, yy, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, alp ) )
		end

		if xdesh_amount and ( ( ply:Alive() and ply.xdeshield ) or xdesh_lerp > SysTime() ) then --能量盾
			local tab, amo = ply.xdeshield, ( ply:GetNWInt( "XDEES_Amount" ) or 0 )
			if !istable( tab ) then tab = { 0, 0, 0, 0 } end xdesh_amount = Lerp( 0.1, xdesh_amount, amo )
			local alp = math.Clamp( ( xdesh_lerp -SysTime() )/0.5, 0, 1 )
			if ply.xdeshield then alp = 1-alp end alp = alp*255
			local pe1, pe2 = math.Clamp( amo/tab[ 1 ], 0, 1 ) or 0, math.Clamp( xdesh_amount/tab[ 1 ], 0, 1 ) or 0
			if amo >= tab[ 1 ] and ply.xdeshield and tab[ 1 ] > 0 and amo > 0 then
				if xdesh_full == 0 then xdesh_full = SysTime() +0.3  surface.PlaySound( "weapons/ar2/ar2_reload_rotate.wav" ) end
			elseif tab[ 1 ] <= 0 or amo <= 0 or !ply.xdeshield then xdesh_full = 0 end
			local sk = ( ply.xdeshield and amo > 0 and xdesh_amount > 0 and tab[ 1 ] > 0 ) and math.max( 0, pe2 -pe1 )*25 or 0
			local sk1, sk2 = math.Round( math.Rand( -sk, sk ), 1 ), math.Round( math.Rand( -sk, sk ), 1 )
			local col = Color( 255, 192, 0 )  if pe1 <= 0 or !ply.xdeshield then col = Color( 255, 0, 0 ) elseif pe1 >= 1 or xdesh_full > 0 then col = Color( 0, 192, 255 ) end
			draw.RoundedBoxEx( 16, ScrW()*0.075 -128 -65 +alp/255*64 +sk1*4, ScrH()*0.88 -73 +sk2*4, 258, 78, Color( col.r, col.g, col.b, alp/2 ), false, true, false, false )
			draw.RoundedBoxEx( 16, ScrW()*0.075 -128 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -72 +sk2*4, 256, 76, Color( 0, 32, 32, alp ), false, true, false, false )
			surface.SetDrawColor( 0, 96, 96, alp ) surface.DrawRect( ScrW()*0.075 -128 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -72 +35 +sk2*4, 256, 16 )
			if pe1 >= pe2 and ply.xdeshield then
				surface.SetDrawColor( 0, 255, 0, alp ) surface.DrawRect( ScrW()*0.075 -128 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -72 +35 +sk2*4, 256*pe1, 16 )
				surface.SetDrawColor( col.r, col.g, col.b, alp ) surface.DrawRect( ScrW()*0.075 -128 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -72 +35 +sk2*4, 256*pe2, 16 )
			else
				surface.SetDrawColor( col.r, col.g, col.b, alp ) surface.DrawRect( ScrW()*0.075 -128 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -72 +35 +sk2*4, 256*pe1, 16 )
				surface.SetDrawColor( 255, 0, 0, alp ) surface.DrawRect( ScrW()*0.075 -128 -64 +alp/255*64 +256*pe1 +sk1*4, ScrH()*0.88 -72 +35 +sk2*4, 256*( pe2 -pe1 ), 16 )
			end
			surface.SetDrawColor( 0, 32, 32, alp ) surface.DrawOutlinedRect( ScrW()*0.075 -128 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -72 +35 +sk2*4, 256, 16, 4 )
			if xdesh_full > SysTime() then
				local al2 = math.Clamp( ( xdesh_full-SysTime() )/0.3, 0, 1 )*255
				draw.RoundedBoxEx( 16, ScrW()*0.075 -128 -65 +alp/255*64 +sk1*4, ScrH()*0.88 -73 +sk2*4, 258, 78, Color( col.r, col.g, col.b, al2 ), false, true, false, false )
			end
			draw.TextShadow( {
				text = "*",
				pos = { ScrW()*0.075 -109 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -64 +sk2*4 },
				font = "xdeshe_Font11",
				xalign = TEXT_ALIGN_CENTER,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( col.r, col.g, col.b, alp )
			}, 1, alp )
			local nam = ( ( tab[ 4 ] and tab[ 4 ] != 0 ) and xdesh_langs[ tab[ 4 ] +1 ] or "" )
			draw.TextShadow( {
				text = nam,
				pos = { ScrW()*0.075 -88 -64 +alp/255*64 +sk1*4, ScrH()*0.88 -54 +sk2*4 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_LEFT,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( col.r, col.g, col.b, alp )
			}, 1, alp )

			draw.TextShadow( {
				text = math.Round( tab[ 1 ]*pe2 ).."%",
				pos = { ScrW()*0.075 +56 +alp/255*64 +sk1*4, ScrH()*0.88 -10 +sk2*4 },
				font = "xdeshe_Font2",
				xalign = TEXT_ALIGN_RIGHT,
				yalign = TEXT_ALIGN_CENTER,
				color = Color( col.r, col.g, col.b, alp )
			}, 1, alp )
		end
		if ply:Alive() and IsValid( ply:GetNWEntity( "XDE_Emplace" ) ) and ply:GetNWEntity( "XDE_Emplace" ):GetXDE_US() == ply then --机枪准星
			local sel = ply:GetNWEntity( "XDE_Emplace" )
			local att = sel:GetAttachment( sel:LookupAttachment( "muzzle_flash" ) )
			if !att then att = sel:GetAttachment( sel:LookupAttachment( "muzzle" ) ) end
			if att then
				local amo = 0
				if sel:GetClass() == "sent_she_turret1" then amo = ply:GetAmmoCount( "Ar2" )
				elseif sel:GetClass() == "sent_she_turret2" then amo = ply:GetAmmoCount( "Smg1" )
				elseif sel:GetClass() == "sent_she_turret3" then amo = 999 end --嘿嘿嘿哈
				local infa = ( sel:GetClass() == "sent_she_turret1" and GetConVar( "she_turretcal_infammo" ):GetInt() > 0 )
				or ( sel:GetClass() == "sent_she_turret2" and GetConVar( "she_turretmg_infammo" ):GetInt() > 0 ) or ( sel:GetClass() != "sent_she_turret3" and sel:GetXDE_InfAmmo() )
				local infh = ( sel:GetClass() != "sent_she_turret3" and sel:GetXDE_InfHeat() )

				local tr = util.TraceHull( {
					start = att.Pos,
					endpos = att.Pos +att.Ang:Forward()*8192,
					filter = { sel, ply },
					mask = MASK_SHOT,
					mins = Vector( -0.5, -0.5, -0.5 ),
					maxs = Vector( 0.5, 0.5, 0.5 )
				} )
				local scr, out = tr.HitPos:ToScreen(), math.max( 0, sel:GetXDE_NShot() -CurTime() )*5
				local col = ( ( infa or amo > 0 ) and ( infh or sel:GetXDE_State() <= 1 ) ) and Color( 255, 255, 255 ) or Color( 255, 0, 0 )
				surface.SetDrawColor( 0, 0, 0, 255 )
				local function MakeItNice( x, y, w, h )
					draw.RoundedBox( 0, x, y, w, h, col )
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawOutlinedRect( x, y, w, h, 1 )
				end
				MakeItNice( scr.x -18 -out*18, scr.y -2, 15, 3 )
				MakeItNice( scr.x +3 +out*18, scr.y -2, 15, 3 )
				MakeItNice( scr.x -2, scr.y -18 -out*18, 3, 15 )
				MakeItNice( scr.x -2, scr.y +3 +out*18, 3, 15 )
				if sel:GetClass() != "sent_she_turret3" then
					if !infa then
						draw.SimpleTextOutlined( language.GetPhrase( "xdeshe.Turret16" )..": "..amo, "xdeshe_Font4", scr.x, scr.y +32 +out*18, amo <= 0 and Color( 255, 0, 0 ) or Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )
					end
					if !infh then
						local per = math.Clamp( ( sel:GetXDE_Heat() -CurTime() )/30, 0, 1 )
						draw.SimpleTextOutlined( language.GetPhrase( "xdeshe.Turret17" )..": "..math.ceil( per*100 ).."%", "xdeshe_Font4", scr.x, scr.y -32 -out*18, sel:GetXDE_State() > 1 and Color( 255, 0, 0 ) or Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )
					end
				end
			end
		end
		if xdeshe_ddcmat then local ent = ply:GetNWEntity( "XDEDDC" ) --龙降日UI
			local bb = ( IsValid( ent ) and ent:GetXDE_OW() == ply and ent:GetXDE_HP() > 0 )
			if xdeshe_ddcav != bb then
				xdeshe_ddcav = bb
				xdeshe_ddchp = 0
				xdeshe_ddcle = SysTime() +0.5
				if bb then
					xdeshe_ddccl = ent:GetClass()
				end
			end
			if bb or xdeshe_ddcle > SysTime() then
				local per = bb and math.Round( math.Clamp( ent:GetXDE_HP()/ent:GetMaxHealth(), 0, 1 )*100 ) or 0
				local ler = math.Clamp( ( xdeshe_ddcle -SysTime() )/0.5, 0, 1 )
				if xdeshe_ddcav then ler = 1-ler end local man = ( xdeshe_ddccl == "npc_she_trigger" and 1 or 3 )
				surface.SetDrawColor( 255, 255, 255, ler*255 )
				surface.SetMaterial( xdeshe_ddcmat[ 1 +man ] )
				surface.DrawTexturedRect( ScrW()*0.075 -128 -ler*32, ScrH()*0.8 -128, 256, 256 )
				render.SetScissorRect( ScrW()*0.075 -128, ScrH()*0.8 -128 +256*( 1 -per/100 ), ScrW()*0.075 +128, ScrH()*0.8 +128, true )
				surface.SetMaterial( xdeshe_ddcmat[ 2 +man ] )
				surface.DrawTexturedRect( ScrW()*0.075 -128 -ler*32, ScrH()*0.8 -128, 256, 256 )
				render.SetScissorRect( 0, 0, 0, 0, false )
				if bb then local mk, mkp, mkh = ent:GetXDE_MK(), ent:GetXDE_MKP(), ent:GetXDE_MKH()
					if IsValid( mk ) and mkh > 0 and mkp > CurTime() then
						local hp = math.Clamp( mkh/mk:GetMaxHealth(), 0, 1 )
						local per = math.Clamp( mkp -CurTime(), 0, 1 )
						surface.SetMaterial( xdeshe_ddcmat[ 1 ] )
						surface.SetDrawColor( 0, 255, 0, per*255 )
						local pos = mk:WorldSpaceCenter():ToScreen()
						local xx, yy = math.Clamp( pos.x, 32, ScrW() -32 ), math.Clamp( pos.y, 32, ScrH() -32 )
						surface.DrawTexturedRect( xx -32, yy -32, 64, 64 )
						render.SetScissorRect( xx -32, yy -32, xx +32, yy +32 -64*hp, true )
						surface.SetDrawColor( 255, 0, 0, per*255 )
						surface.DrawTexturedRect( xx -32, yy -32, 64, 64 )
						render.SetScissorRect( 0, 0, 0, 0, false )
					end
				end
			end
		end
	end )
	hook.Add( "HUDDrawTargetID", "xdeshe_huddtid", function()
		local ent = util.TraceLine( util.GetPlayerTrace( LocalPlayer() ) ).Entity
		if IsValid( ent ) and ent:IsPlayer() and ent:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ent:GetNWFloat( "XDESHE_Found" ) <= CurTime() then
			return false
		end
	end )
	hook.Add( "PreDrawViewModel", "xdeshe_pdvm", function( vm, ply, wep )
		if ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() and ply:Crouching() then --躲藏隐藏手模
			return true 
		end
	end )
	local Mat = xdeshe_OnceMat( "models/shiny" )
	hook.Add( "PostDrawEffects", "xdeshe_pde", function() local ply = LocalPlayer()
		if xdesh_users and #xdesh_users > 0 then
			for k, v in pairs( xdesh_users ) do --能量盾受击特效
				if IsValid( v ) and v:GetNWFloat( "XDEES_Hit" ) > CurTime() and v:GetNWInt( "XDEES_Amount" ) > 0 and ( v != LocalPlayer() or !v:ShouldDrawLocalPlayer() ) then
					local per = math.Clamp( v:GetNWFloat( "XDEES_Hit" ) -CurTime(), 0, 1 )
					cam.Start3D()
					render.SuppressEngineLighting( true )
					render.SetBlend( per ) render.MaterialOverride( Mat )
					render.SetColorModulation( per, per, per )
					v:DrawModel()
					render.SetBlend( 1 ) render.MaterialOverride()
					render.SetColorModulation( 1, 1, 1 )
					render.SuppressEngineLighting( false )
					cam.End3D()
				end
			end
		end
	end )
	hook.Add( "PostPlayerDraw" , "xdeshe_ppd" , function( ply )
		if xdeshe_HatPos and IsValid( ply ) and ply:Alive() and ply:GetNWInt( "XDESHE_Hats" ) > 0 then
			local head = ply:LookupBone( "ValveBiped.Bip01_Head1" )  if !head then return end
			local pp, aa = ply:GetBonePosition( head ) if !head then return end

			if !ply.XDE_Hats then ply.XDE_Hats = {} else local hats = ply:GetNWInt( "XDESHE_Hats" )
				if #ply.XDE_Hats < hats then
					for i=1, hats do
						local mdl = ClientsideModel( "models/player/items/humans/top_hat.mdl" )
						mdl:SetNoDraw( true ) table.insert( ply.XDE_Hats, mdl )
						mdl.XDE_Color = ply:GetPlayerColor()  mdl.Owner = ply
						function mdl:GetPlayerColor() return mdl.XDE_Color end mdl:Spawn()
						table.insert( xdeshe_thats, mdl )
					end
				end
				for k, v in ipairs( ply.XDE_Hats ) do
					if !IsValid( v ) then table.remove( ply.XDE_Hats, k ) continue end
					if k > hats then v:Remove() table.remove( ply.XDE_Hats, k ) continue end
					local fp, fa = xdeshe_HatPos( ply, k )
					v:SetPos( fp ) v:SetAngles( fa )
					v:SetRenderOrigin( fp ) v:SetRenderAngles( fa )
					v:SetupBones() v:DrawModel()
					v:SetRenderOrigin() v:SetRenderAngles()
				end
			end
		elseif IsValid( ply ) and ply.XDE_Hats then
			for k, v in ipairs( ply.XDE_Hats ) do v:Remove() end ply.XDE_Hats = nil
		end
	end )

	net.Receive( "xdeshe_S2C_BroadEffect", function()
		local nam, dat = net.ReadString(), util.JSONToTable( net.ReadString() )
		if !istable( dat ) then return end
        xdeshe_BroadEffect( nam, dat, net.ReadEntity() )
    end )
	net.Receive( "xdeshe_S2C_Gesture", function()
		local ply, act = net.ReadEntity(), net.ReadFloat()
		if IsValid( ply ) and isnumber( act ) and ply:IsPlayer() and ply:Alive() then
			ply:AnimRestartGesture( GESTURE_SLOT_ATTACK_AND_RELOAD, math.Round( act ), true )
		end
	end )
	net.Receive( "xdeshe_S2C_MenuOpen", function()
		local id, ent, dat, onc = net.ReadString(), net.ReadEntity(), util.JSONToTable( net.ReadString() ), net.ReadBool()
		xdeshe_MenuOpen( LocalPlayer(), id, ent, dat, onc )
	end )
	net.Receive( "xdeshe_S2C_MenuClose", function()
		local id = net.ReadString()
		if xdeshe_vguis[ id ] and !xdeshe_vguis[ id ].B_Close and xdeshe_vguis[ id ].MenuClose then xdeshe_vguis[ id ]:MenuClose() end
	end )
	net.Receive( "xdeshe_S2C_HintMessage", function()
		xdeshe_HintMessage( LocalPlayer(), net.ReadString(), math.Round( net.ReadFloat() ), net.ReadString() )
	end )
	net.Receive( "xdeshe_S2C_ChatMessage", function()
		xdeshe_ChatMessage( LocalPlayer(), net.ReadString(), net.ReadString() )
	end )
	net.Receive( "xdeshe_S2C_Pickup", function()
		xdeshe_PickupNote( LocalPlayer(), net.ReadString(), net.ReadVector() )
	end )
	net.Receive( "xdeshe_S2C_Helper", function()
		xdeshe_HelperNote( LocalPlayer(), net.ReadString(), util.JSONToTable( net.ReadString() ) )
	end )
end

xdeshe_hts = {
	[ "normal" ] = { ACT_HL2MP_IDLE, ACT_HL2MP_WALK, ACT_HL2MP_WALK_CROUCH, ACT_HL2MP_RUN_PANICKED, ACT_HL2MP_JUMP_SLAM, ACT_HL2MP_GESTURE_RANGE_ATTACK, ACT_HL2MP_GESTURE_RELOAD },
	[ "melee" ] = { ACT_HL2MP_IDLE_MELEE, ACT_HL2MP_WALK_MELEE, ACT_HL2MP_WALK_CROUCH_MELEE, ACT_HL2MP_RUN_MELEE, ACT_HL2MP_JUMP_MELEE, ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE, ACT_HL2MP_GESTURE_RELOAD_MELEE },
	[ "melee2" ] = { ACT_HL2MP_IDLE_MELEE2, ACT_HL2MP_WALK_MELEE2, ACT_HL2MP_WALK_CROUCH_MELEE2, ACT_HL2MP_RUN_MELEE2, ACT_HL2MP_JUMP_MELEE2, ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE2, ACT_HL2MP_GESTURE_RELOAD_MELEE2 },
	[ "camera" ] = { ACT_HL2MP_IDLE_CAMERA, ACT_HL2MP_WALK_CAMERA, ACT_HL2MP_WALK_CROUCH_CAMERA, ACT_HL2MP_RUN_CAMERA, ACT_HL2MP_GESTURE_RANGE_ATTACK_CAMERA, ACT_HL2MP_JUMP_CAMERA, ACT_HL2MP_GESTURE_RELOAD_CAMERA },
	[ "ar2" ] = { ACT_HL2MP_IDLE_AR2, ACT_HL2MP_WALK_AR2, ACT_HL2MP_WALK_CROUCH_AR2, ACT_HL2MP_RUN_AR2, ACT_HL2MP_JUMP_AR2, ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2, ACT_HL2MP_GESTURE_RELOAD_AR2 },
	[ "crossbow" ] = { ACT_HL2MP_IDLE_CROSSBOW, ACT_HL2MP_WALK_CROSSBOW, ACT_HL2MP_WALK_CROUCH_CROSSBOW, ACT_HL2MP_RUN_CROSSBOW, ACT_HL2MP_JUMP_CROSSBOW, ACT_HL2MP_GESTURE_RANGE_ATTACK_CROSSBOW, ACT_HL2MP_GESTURE_RELOAD_CROSSBOW },
	[ "smg" ] = { ACT_HL2MP_IDLE_SMG1, ACT_HL2MP_WALK_SMG1, ACT_HL2MP_WALK_CROUCH_SMG1, ACT_HL2MP_RUN_SMG1, ACT_HL2MP_JUMP_SMG1, ACT_HL2MP_GESTURE_RANGE_ATTACK_SMG1, ACT_HL2MP_GESTURE_RELOAD_SMG1 },
	[ "shotgun" ] = { ACT_HL2MP_IDLE_SHOTGUN, ACT_HL2MP_WALK_SHOTGUN, ACT_HL2MP_WALK_CROUCH_SHOTGUN, ACT_HL2MP_RUN_SHOTGUN, ACT_HL2MP_JUMP_SHOTGUN, ACT_HL2MP_GESTURE_RANGE_ATTACK_SHOTGUN, ACT_HL2MP_GESTURE_RELOAD_SHOTGUN },
	[ "revolver" ] = { ACT_HL2MP_IDLE_REVOLVER, ACT_HL2MP_WALK_REVOLVER, ACT_HL2MP_WALK_CROUCH_REVOLVER, ACT_HL2MP_RUN_REVOLVER, ACT_HL2MP_JUMP_REVOLVER, ACT_HL2MP_GESTURE_RANGE_ATTACK_REVOLVER, ACT_HL2MP_GESTURE_RELOAD_REVOLVER },
	[ "pistol" ] = { ACT_HL2MP_IDLE_PISTOL, ACT_HL2MP_WALK_PISTOL, ACT_HL2MP_WALK_CROUCH_PISTOL, ACT_HL2MP_RUN_PISTOL, ACT_HL2MP_JUMP_PISTOL, ACT_HL2MP_GESTURE_RANGE_ATTACK_PISTOL, ACT_HL2MP_GESTURE_RELOAD_PISTOL },
	[ "fist" ] = { ACT_HL2MP_IDLE_FIST, ACT_HL2MP_WALK_FIST, ACT_HL2MP_WALK_CROUCH_FIST, ACT_HL2MP_RUN_FIST, ACT_HL2MP_JUMP_FIST, ACT_HL2MP_GESTURE_RANGE_ATTACK_FIST, ACT_HL2MP_GESTURE_RELOAD_FIST },
	[ "knife" ] = { ACT_HL2MP_IDLE_KNIFE, ACT_HL2MP_WALK_KNIFE, ACT_HL2MP_WALK_CROUCH_KNIFE, ACT_HL2MP_RUN_KNIFE, ACT_HL2MP_JUMP_KNIFE, ACT_HL2MP_GESTURE_RANGE_ATTACK_KNIFE, ACT_HL2MP_GESTURE_RELOAD_KNIFE },
	[ "rpg" ] = { ACT_HL2MP_IDLE_RPG, ACT_HL2MP_WALK_RPG, ACT_HL2MP_WALK_CROUCH_RPG, ACT_HL2MP_RUN_RPG, ACT_HL2MP_JUMP_RPG, ACT_HL2MP_GESTURE_RANGE_ATTACK_RPG, ACT_HL2MP_GESTURE_RELOAD_RPG },
	[ "slam" ] = { ACT_HL2MP_IDLE_SLAM, ACT_HL2MP_WALK_SLAM, ACT_HL2MP_WALK_CROUCH_SLAM, ACT_HL2MP_RUN_SLAM, ACT_HL2MP_JUMP_SLAM, ACT_HL2MP_GESTURE_RANGE_ATTACK_SLAM, ACT_HL2MP_GESTURE_RELOAD_SLAM },
	[ "physgun" ] = { ACT_HL2MP_IDLE_PHYSGUN, ACT_HL2MP_WALK_PHYSGUN, ACT_HL2MP_WALK_CROUCH_PHYSGUN, ACT_HL2MP_RUN_PHYSGUN, ACT_HL2MP_JUMP_PHYSGUN, ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN, ACT_HL2MP_GESTURE_RELOAD_PHYSGUN },
	[ "zombie" ] = { ACT_HL2MP_IDLE_ZOMBIE, ACT_HL2MP_RUN_ZOMBIE, ACT_HL2MP_WALK_CROUCH_ZOMBIE, ACT_HL2MP_RUN_ZOMBIE, ACT_HL2MP_JUMP_KNIFE, ACT_GMOD_GESTURE_RANGE_ZOMBIE_SPECIAL, ACT_HL2MP_GESTURE_RELOAD_ZOMBIE },
	[ "zombiefast" ] = { ACT_HL2MP_IDLE_CROUCH_ZOMBIE, ACT_HL2MP_WALK_ZOMBIE, ACT_HL2MP_WALK_CROUCH_ZOMBIE, ACT_HL2MP_RUN_ZOMBIE_FAST, ACT_HL2MP_JUMP_KNIFE, ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE, ACT_HL2MP_GESTURE_RELOAD_ZOMBIE },
	[ "passive" ] = { ACT_HL2MP_IDLE_PASSIVE, ACT_HL2MP_WALK_PASSIVE, ACT_HL2MP_WALK_CROUCH_PASSIVE, ACT_HL2MP_RUN_PASSIVE, ACT_HL2MP_JUMP_PASSIVE, ACT_HL2MP_GESTURE_RANGE_ATTACK_PASSIVE, ACT_HL2MP_GESTURE_RELOAD_PASSIVE },
}

function xdeshe_HelperNote( ply, id, dat ) --实体提示
	if !IsValid( ply ) or !ply:IsPlayer() or ply:IsBot() or !isstring( id ) or dat == nil then return end
	if SERVER then
		net.Start( "xdeshe_S2C_Helper" ) net.WriteString( id )
		net.WriteString( util.TableToJSON( dat ) ) net.Send( ply )
	elseif istable( dat ) and !xdeshe_notes[ id ] then xdeshe_notes[ id ] = true
		surface.PlaySound( "ui/hint.wav" ) local txt = ""
		for k, v in ipairs( dat ) do
			if string.Left( v, 1 ) == "#" then
				txt = txt..language.GetPhrase( v )
			else txt = txt..v end
		end
		notification.AddLegacy( txt, NOTIFY_HINT, 5 )
		MsgC( Color( 255, 255, 255 ), txt.."\n" )
	end
end
function xdeshe_MenuAction( ply, id, dat ) --界面收发指令
	if !isstring( id ) or ( !isnumber( dat ) and !isstring( dat ) ) then return end
	if SERVER then
		if IsValid( ply ) and IsValid( ply.XDE_Using ) and ply.XDE_Using.GetXDE_US
		and ply.XDE_Using:GetXDE_US() == ply and ( !ply.XDE_Cool or ply.XDE_Cool <= CurTime() ) then
			ply.XDE_Cool = CurTime() +0.1  local func = xdeshe_actions[ id ]
			if isfunction( func ) then func( ply, id, ply.XDE_Using, dat ) end
		end
	elseif xdeshe_menus[ id ] then
		net.Start( "xdeshe_C2S_MenuAction" ) net.WriteString( id )
		net.WriteString( tostring( dat ) ) net.SendToServer()
	end
end
function xdeshe_PickupNote( ply, txt, vec ) --拾取提示
	if !ply:IsPlayer() or !isstring( txt ) or txt == "" then return end
	if !isvector( vec ) then vec = Vector( 255, 255, 255 ) end
	if SERVER then
		net.Start( "xdeshe_S2C_Pickup" )
		net.WriteString( txt ) net.WriteVector( vec ) net.Send( ply )
	else
		if txt == "!V" then txt = "" end
		local pickup = {}  pickup.time = CurTime()  pickup.name = ( string.find( txt, "#" ) != nil and language.GetPhrase( txt ) or txt )
		pickup.holdtime = 5  pickup.font = "DermaDefaultBold"
		pickup.fadein = 0.04  pickup.fadeout = 0.3
		local GM = gmod.GetGamemode()  surface.SetFont( pickup.font )
		local w, h = surface.GetTextSize( pickup.name )  if !GM or !istable( GM.PickupHistory ) then return end
		pickup.height = h  pickup.width = w  pickup.color = Color( vec.x, vec.y, vec.z, 255 )
		table.insert( GM.PickupHistory, pickup )  GM.PickupHistoryLast = pickup.time
	end
end
function xdeshe_MenuUpdate( ply, id, dat ) --界面信息发送
	if !isstring( id ) or !IsValid( ply ) or !ply:Alive() then return end
	if isstring( dat ) then dat = { dat } elseif !istable( dat ) then dat = {} end
	if SERVER then
		if !IsValid( ply.XDE_Using ) or !ply.XDE_Using.GetXDE_US or ply.XDE_Using:GetXDE_US() != ply then return end
		net.Start( "xdeshe_S2C_MenuUpdate" )
		net.WriteString( id )
		net.WriteString( util.TableToJSON( dat ) )
		net.Send( ply )
	else
		local pan = xdeshe_vguis[ id ]
		if IsValid( pan ) then pan:MenuUpdate( dat ) end
	end
end
function xdeshe_MenuOpen( ply, id, ent, dat ) --界面打开
	if !isstring( id ) or !IsValid( ply ) or ( ply.XDE_Cool and ply.XDE_Cool > CurTime() ) then return end
	if !IsValid( ent ) then ent = Entity( 0 ) end
	if isstring( dat ) or isnumber( dat ) then dat = { dat } elseif !istable( dat ) then dat = {} end
	if SERVER then
		if IsValid( ent ) and IsValid( ply.XDE_Using ) then return end
		if ent.GetXDE_US then
			if IsValid( ent:GetXDE_US() ) then return end
			ply.XDE_Using = ent  ent:SetXDE_US( ply )
		end
		net.Start( "xdeshe_S2C_MenuOpen" )
		net.WriteString( id )
		net.WriteEntity( IsValid( ent ) and ent or Entity( 0 ) )
		net.WriteString( util.TableToJSON( dat ) ) 
		net.WriteBool( onc )
		net.Send( ply )
		ply.XDE_Cool = CurTime() +0.25
	else
		local func = xdeshe_menus[ id ]
		if isfunction( func ) then
			local pax = func( id, ent, dat )
			if ispanel( pax ) then xdeshe_vguis[ id ] = pax end
		end
	end
end
function xdeshe_SNum( num ) --数字转00字符
	if num == 0 or num >= 100 then return "00" end
	if num < 10 then return "0"..num end
	return tostring( num )
end
function xdeshe_DoGesture( ply, act ) --玩家手势
	if !IsValid( ply ) or !ply:IsPlayer() or !ply:Alive() or !isnumber( act ) then return end
	act = math.Round( act )
	if CLIENT then
		ply:AnimRestartGesture( GESTURE_SLOT_ATTACK_AND_RELOAD, act, true )
	else
		net.Start( "xdeshe_S2C_Gesture" )
		net.WriteEntity( ply )
		net.WriteFloat( act )
		net.Broadcast()
	end
end
function xdeshe_BroadEffect( nam, dat, ent ) --硬核特效过渡,很抽象
	if !isstring( nam ) or !istable( dat ) then return end
	if SERVER then
		net.Start( "xdeshe_S2C_BroadEffect" )
		net.WriteString( nam )
		net.WriteString( util.TableToJSON( dat ) )
		net.WriteEntity( IsEntity( ent ) and ent or Entity( 0 ) )
		net.Broadcast()
	else
		local eff = EffectData()
		if isangle( dat.Angles ) then eff:SetAngles( dat.Angles ) end
		if isnumber( dat.Attachment ) then eff:SetAttachment( dat.Attachment ) end
		if isnumber( dat.Color ) then eff:SetColor( dat.Color ) end
		if isnumber( dat.DamageType ) then eff:SetDamageType( dat.DamageType ) end
		if isnumber( dat.EntIndex ) then eff:SetEntIndex( dat.EntIndex ) end
		if isnumber( dat.Flags ) then eff:SetFlags( dat.Flags ) end
		if isnumber( dat.HitBox ) then eff:SetHitBox( dat.HitBox ) end
		if isnumber( dat.Magnitude ) then eff:SetMagnitude( dat.Magnitude ) end
		if isnumber( dat.Scale ) then eff:SetScale( dat.Scale ) end
		if isnumber( dat.Radius ) then eff:SetRadius( dat.Radius ) end
		if isnumber( dat.MaterialIndex ) then eff:SetMaterialIndex( dat.MaterialIndex ) end
		if isvector( dat.Normal ) then eff:SetNormal( dat.Normal ) end
		if isvector( dat.Origin ) then eff:SetOrigin( dat.Origin ) end
		if isvector( dat.Start ) then eff:SetStart( dat.Start ) end
		if isnumber( dat.SurfaceProp ) then eff:SetSurfaceProp( dat.SurfaceProp ) end
		eff:SetEntity( ent or Entity( 0 ) )
		util.Effect( nam, eff )
	end
end
function xdeshe_NoTool( ent, inv ) --保护一个实体
	if !IsValid( ent ) then return end
	if isbool( inv ) and inv == true then
		ent.xdeshe_NoTool = false
	else
		ent.xdeshe_NoTool = true
	end
	if inv then
		ent:SetUnFreezable( false )
		if IsValid( ent:GetPhysicsObject() ) then
			ent:GetPhysicsObject():ClearGameFlag( FVPHYSICS_NO_PLAYER_PICKUP )
		end
		return
	end
	ent:SetUnFreezable( true )
	if IsValid( ent:GetPhysicsObject() ) then
		ent:GetPhysicsObject():AddGameFlag( FVPHYSICS_NO_PLAYER_PICKUP )
	end
end
function xdeshe_IsFireDmg( dmg ) --油罐专用,检测热伤害
	return ( dmg:IsDamageType( DMG_BLAST ) or dmg:IsDamageType( DMG_BURN ) or dmg:IsDamageType( DMG_SLOWBURN ) or dmg:IsBulletDamage() )
end
function xdeshe_ChatMessage( ply, message, hintsound ) --聊天信息
	if !IsValid( ply ) then return end
	if !isstring( hintsound ) or hintsound == "" then hintsound = "!V" end
	if !isstring( message ) or message == "" then message = "!V" end
	if SERVER then
		net.Start( "xdeshe_S2C_ChatMessage" )
		net.WriteString( message )
		net.WriteString( hintsound )
		net.Send( ply )
	else
		if isstring( message ) and message != "!V" then
			if string.Left( message, 1 ) == "#" then message = language.GetPhrase( message ) end
			chat.AddText( Color( 255, 255, 255 ), message )
		end
		if hintsound != "!V" then surface.PlaySound( hintsound ) end
	end
end
function xdeshe_HintMessage( ply, message, hinttype, hintsound ) --提示信息
	if !isstring( hintsound ) or hintsound == "" then hintsound = "!V" end
	if !isstring( message ) or message == "" then message = "!V" end
	if !isnumber( hinttype ) then hinttype = 0 end
	if SERVER then
		net.Start( "xdeshe_S2C_HintMessage" )
		net.WriteString( message )
		net.WriteFloat( hinttype )
		net.WriteString( hintsound )
		if IsValid( ply ) then net.Send( ply ) else net.Broadcast() end
	else
		if isstring( message ) and message != "!V" then
			if string.Left( message, 1 ) == "#" then message = language.GetPhrase( message ) end
			notification.AddLegacy( message, hinttype, 3 )
		end
		if isstring( hintsound ) and hintsound != "!V" then surface.PlaySound( hintsound ) end
	end
end

hook.Add( "StartCommand", "xdeshe_sc", function( ply, cmd )
	local am2 = math.Clamp( math.ceil( ( ply:GetNWFloat( "XDESHE_PP" )-CurTime() )/90 ), 0, 3 )
	if SERVER then
		if ply.XDE_Hide or ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() then --躲藏隐藏玩家
			if ply.XDE_Hide != ( ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:Crouching() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() ) then --服务端躲藏
				ply.XDE_Hide = ( ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:Crouching() and ply:GetNWFloat( "XDESHE_Found" ) <= CurTime() )
				ply:SetNoTarget( ply.XDE_Hide )
				ply:EmitSound( ply.XDE_Hide and "Grass.StepLeft" or "Grass.StepRight" )
				if ply.XDE_Hide then
					ply:SetRenderMode( RENDERMODE_NONE ) ply:SetColor( Color( 0, 0, 0, 0 ) ) ply:DrawWorldModel( false )
					for k, v in pairs( ents.FindByClass( "npc_*" ) ) do
						if v:IsNPC() and v:GetEnemy() == ply then
							v:ClearEnemyMemory( ply ) v:SetEnemy( nil )
						end
					end
				else
					ply:SetRenderMode( RENDERMODE_NORMAL ) ply:SetColor( Color( 255, 255, 255, 255 ) ) ply:DrawWorldModel( true )
				end
			end
			if ply:GetNWFloat( "XDESHE_Found" ) < CurTime() +1 then --躲藏摸到其他人暴露
				for k, v in pairs( ents.FindInSphere( ply:GetPos(), 28 ) ) do
					if ( v:IsNPC() and v:GetNPCState() != NPC_STATE_DEAD )
					or ( v:IsPlayer() and v:Alive() and v != ply and ( v:GetNWFloat( "XDESHE_Hide" ) <= CurTime() or v:GetNWFloat( "XDESHE_Found" ) > CurTime() ) ) then
						ply:SetNWFloat( "XDESHE_Found", CurTime() +1 ) break
					end
				end
			end
			if ply:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ply:GetNWFloat( "XDESHE_Found" ) < CurTime() +0.5
			and ( ply:InVehicle() or ply:GetMoveType() != MOVETYPE_WALK or ply:GetVelocity():Length() > 72 ) then --未正常躲避暴露
				ply:SetNWFloat( "XDESHE_Found", CurTime() +0.5 )
			end
		end
		if am2 > 0 and ply:WaterLevel() > 0 then --力量药遇水降解
			ply:SetNWFloat( "XDESHE_PP", ply:GetNWFloat( "XDESHE_PP" ) -ply:WaterLevel()/4 )
		end
		if ply:Alive() and IsValid( ply:GetNWEntity( "XDE_Emplace" ) ) and ply:GetNWEntity( "XDE_Emplace" ):GetXDE_US() == ply then --机枪控制
			local sel = ply:GetNWEntity( "XDE_Emplace" )
			local use, at1, at2 = cmd:KeyDown( IN_USE ), cmd:KeyDown( IN_ATTACK ), cmd:KeyDown( IN_ATTACK2 )
			if ( use or at2 ) and sel.XDE_NextUse <= CurTime() then
				ply:SetNWEntity( "XDE_Emplace", nil )
				if IsValid( sel.XDE_Weapon ) and sel.XDE_Weapon.Owner == ply then
					ply:SelectWeapon( sel.XDE_Weapon )  sel.XDE_Weapon = nil
				end
				sel:SetXDE_US( nil )
				ply:CrosshairEnable()
				sel.XDE_NextUse = CurTime() +0.25
				cmd:ClearButtons()
				sel:EmitSound( "xdeshe.TurretOff" )
				if sel.SetFlashlight then sel:SetFlashlight( false ) end
			else
				if at1 then
					if sel:GetClass() == "sent_she_turret3" then sel.XDE_Firing = CurTime() +FrameTime()*2 else sel:FireGun() end
				elseif sel.GetXDE_Spin and sel:GetXDE_Spin() then
					sel:SetXDE_Spin( false )
				end
			end
			cmd:ClearMovement()
		end
		local amo = math.Clamp( ply:GetNWInt( "xdeerchius" ), 0, 1000 )
		if amo > 0 or isvector( ply.xdeshe_Ghost ) then --赫紫鬼移动
			if amo > 0 and ply:Alive() then
				if !isvector( ply.xdeshe_Ghost ) or ply.xdeshe_Ghost:Distance( ply:GetPos() ) > 4096 then
					xdeshe_MoveGhost( ply, ply:GetPos() +VectorRand():GetNormalized()*3072 )
				else
					local dist = ply.xdeshe_Ghost:Distance( ply:GetPos() )
					if dist > 128 then
						local spd = ( 0.5 +ply:GetNWInt( "xdeerchius" )/48 )
						xdeshe_MoveGhost( ply, ply.xdeshe_Ghost +( ply:GetPos() -ply.xdeshe_Ghost +ply:GetVelocity() ):GetNormalized()*spd )
						local timername = "["..ply:EntIndex().."]xdeer_absorb"
						if dist < 768 and !timer.Exists( timername ) then
							timer.Create( timername, 0.1 +dist/2000, 1, function()
								if IsValid( ply ) and ply:Alive() then
									ply:SetHealth( math.max( 0, ply:Health() -1 ) )
									if ply:Health() <= 0 then
										if ply:IsVehicle() then ply:ExitVehicle() end
										ply:SetHealth( 0 )
										ply:SetNWInt( "xdeerchius", 0 )
										local atkr = ents.Create( "sent_she_erchius" )
										atkr:SetNoDraw( true )
										atkr.XDE_Used = true
										atkr:SetPos( Vector( 0, 0, 0 ) )
										atkr:SetOwner( Entity( 0 ) )
										local dmg = DamageInfo()
										dmg:SetDamage( 9999 )
										dmg:SetAttacker( atkr )
										dmg:SetInflictor( atkr )
										dmg:SetDamagePosition( ply:WorldSpaceCenter() )
										dmg:SetDamageForce( ( ply:WorldSpaceCenter() -ply.xdeshe_Ghost ):GetNormalized()*8192 )
										dmg:SetDamageType( DMG_DISSOLVE )
										ply:TakeDamageInfo( dmg )
										ply:KillSilent()
										atkr:Remove()
									end
								end
							end )
						end
					else
						if ply:IsVehicle() then ply:ExitVehicle() end
						ply:SetHealth( 0 )
						ply:SetNWInt( "xdeerchius", 0 )
						local atkr = ents.Create( "sent_she_erchius" )
						atkr:SetNoDraw( true )
						atkr.XDE_Used = true
						atkr:SetPos( Vector( 0, 0, 0 ) )
						atkr:SetOwner( Entity( 0 ) )
						local dmg = DamageInfo()
						dmg:SetDamage( 9999 )
						dmg:SetAttacker( atkr )
						dmg:SetInflictor( atkr )
						dmg:SetDamagePosition( ply:WorldSpaceCenter() )
						dmg:SetDamageForce( ( ply:WorldSpaceCenter() -ply.xdeshe_Ghost ):GetNormalized()*8192 )
						dmg:SetDamageType( DMG_DISSOLVE )
						ply:TakeDamageInfo( dmg )
						ply:KillSilent()
						atkr:Remove()
					end
				end
			elseif ply.xdeshe_Ghost then
				if ply:GetNWInt( "xdeerchius" ) > 0 then ply:SetNWInt( "xdeerchius", 0 ) end
				xdeshe_MoveGhost( ply, ply.xdeshe_Ghost +( ply.xdeshe_Ghost -ply:GetPos() ):GetNormalized()*16 )
				if ply:GetPos():Distance( ply.xdeshe_Ghost ) > 4096 then xdeshe_MoveGhost( ply, nil ) end
			end
		end
	else
		if am2 > 0 and ply.XDE_PP != am2 then --力量药音效,以下几行都是
			ply.XDE_PP = am2
			if ply.XDE_PPSnd then ply.XDE_PPSnd:Stop()  ply.XDE_PPSnd = nil end
			if am2 == 1 then
				ply.XDE_PPSnd = CreateSound( ply, "xdeedited/nh_heartbeat1.wav" )
				ply.XDE_PPSnd:Play()
				ply.XDE_PPSnd:ChangeVolume( 0.2, 0 )
				ply.XDE_PPSnd:SetSoundLevel( 60 )
			elseif am2 == 2 then
				ply.XDE_PPSnd = CreateSound( ply, "xdeedited/nh_heartbeat2.wav" )
				ply.XDE_PPSnd:Play()
				ply.XDE_PPSnd:ChangeVolume( 0.4, 0 )
				ply.XDE_PPSnd:SetSoundLevel( 60 )
			elseif am2 == 3 then
				ply.XDE_PPSnd = CreateSound( ply, "xdeedited/nh_heartbeat3.wav" )
				ply.XDE_PPSnd:Play()
				ply.XDE_PPSnd:ChangeVolume( 0.6, 0 )
				ply.XDE_PPSnd:SetSoundLevel( 60 )
			end
		elseif am2 == 0 and ply.XDE_PP != 0 then ply.XDE_PP = 0
			if ply.XDE_PPSnd then ply.XDE_PPSnd:FadeOut( 1 ) end
		end
		if ply:GetNWFloat( "XDESHE_PP" )-CurTime() > 0 then
			local am3 = math.Clamp( ( ply:GetNWFloat( "XDESHE_PP" )-CurTime() )/180, 0, 1 )
			if !ply.XDE_PPSn2 then
				ply.XDE_PPSn2 = CreateSound( ply, "xdeedited/nh_breath1.wav" )
				ply.XDE_PPSn2:Play()
				ply.XDE_PPSn2:ChangeVolume( 0.25, 0 )
				ply.XDE_PPSn2:ChangePitch( 80, 0 )
				ply.XDE_PPSn2:SetSoundLevel( 60 )
			elseif !ply.XDE_PPSn2:IsPlaying() then ply.XDE_PPSn2 = nil
			else
				ply.XDE_PPSn2:ChangePitch( 80 +40*am3, 0.5 )
			end
		elseif ply.XDE_PPSn2 then ply.XDE_PPSn2:Stop()  ply.XDE_PPSn2 = nil end
	end
	if ply:GetNWBool( "XDE_SniperZoom" ) and IsValid( ply:GetNWEntity( "XDE_Sniper" ) ) and ply:GetNWEntity( "XDE_Sniper" ):GetActive() and ply:Alive() then --支援狙击手拆键
		cmd:ClearMovement()
		if cmd:KeyDown( IN_ATTACK ) then cmd:RemoveKey( IN_ATTACK ) end
		if cmd:KeyDown( IN_ATTACK2 ) then cmd:RemoveKey( IN_ATTACK2 ) end
	end
end )
hook.Add( "EntityFireBullets", "xdeshe_efb", function( ent, tab )
	if SERVER and IsValid( ent ) and ent:IsPlayer() and ent:Alive() then
		if istable( xdeshe_chopper ) and #xdeshe_chopper > 0 then --小直升机射击
			for k, v in pairs( xdeshe_chopper ) do
				if IsValid( v ) then
					if v:GetXDE_OW() != ent then continue end
					v:FireGun()
				else table.remove( xdeshe_chopper, k ) end
			end
		end
		if ent:GetNWFloat( "XDESHE_Hide" ) > CurTime() and ent:GetNWFloat( "XDESHE_Found" ) < CurTime() +2 then --躲藏时开火暴露
			ent:SetNWFloat( "XDESHE_Found", CurTime() +2 )
		end
	end
end )
hook.Add( "PhysgunPickup", "xdeshe_pp", function( ply, ent )
	if ent.xdeshe_NoTool then return false end
end )
hook.Add( "CanProperty", "xdeshe_cp", function( ply, property, ent )
	if ent.xdeshe_NoTool then return false end
end )
hook.Add( "CanTool", "xdeshe_ct", function( ply, tr, toolname, tool, button )
	if IsValid( tr.Entity ) and tr.Entity.xdeshe_NoTool then return false end
end )
hook.Add( "AllowPlayerPickup", "xdeshe_app", function( ply, ent )
	if ent.xdeshe_NoTool then return false end
end )
hook.Add( "GravGunPickupAllowed", "xdeshe_gpa", function( ply, ent )
	if ent.xdeshe_NoTool then return false end
end )
hook.Add( "GravGunPunt", "xdeshe_ggp", function( ply, ent )
	if ent.xdeshe_NoTool then return false end
end )