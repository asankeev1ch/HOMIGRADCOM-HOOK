-- "lua\\autorun\\billvdv.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "NamVet", 				"models/survivor1/survivor_NamVe1.mdl" )
player_manager.AddValidHands( "NamVet", "models/survivor1/c_hands_survivor_NamVe1.mdl" ,0 ,"00000000" );
list.Set( "PlayerOptionsModel",  "NamVet", 				"models/survivor1/survivor_NamVe1.mdl" )