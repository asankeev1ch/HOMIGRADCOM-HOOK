-- "lua\\autorun\\ukon_nuj02_ori_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "[Tactics] UKON.", "models/nuj02/ori/Realistic/Tactical Anime/pm/[tac]ukon_pm.mdl" )
player_manager.AddValidModel("[Tactics] UKON.", "models/nuj02/ori/Realistic/Tactical Anime/pm/[tac]ukon_pm.mdl")