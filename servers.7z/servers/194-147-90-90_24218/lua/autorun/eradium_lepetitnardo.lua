-- "lua\\autorun\\eradium_lepetitnardo.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel("Le Petit Nardo", "models/eradium/nardo/lepetitnardo.mdl");
player_manager.AddValidHands("Le Petit Nardo", "models/eradium/nardo/lepetitnardo_vm.mdl", 0, "00000000");
