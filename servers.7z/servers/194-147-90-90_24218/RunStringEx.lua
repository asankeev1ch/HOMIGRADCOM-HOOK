-- "RunStringEx.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
vapeHelium=0