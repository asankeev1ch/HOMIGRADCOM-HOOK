-- "lua\\autorun\\ricks.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Rick Sanchez C137","models/player/rickality/rick2.mdl" )
player_manager.AddValidHands( "Rick Sanchez C137","models/player/rickality/tinyrick_arms.mdl",0,"00000000" )