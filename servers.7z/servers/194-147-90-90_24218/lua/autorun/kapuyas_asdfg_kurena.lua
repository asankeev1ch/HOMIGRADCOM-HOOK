-- "lua\\autorun\\kapuyas_asdfg_kurena.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "asdfg21 - Kurena", "models/kapuyas/kemono/kurena/asdfg_kurena_pm.mdl" )
list.Set( "PlayerOptionsModel", "asdfg21 - Kurena", "models/kapuyas/kemono/kurena/asdfg_kurena_pm.mdl" )
player_manager.AddValidHands( "asdfg21 - Kurena", "models/kapuyas/kemono/kurena/asdfg_kurena_c_hands.mdl", 0, "00000000" )

hook.Add("PreDrawPlayerHands", "asdfg_kurena_hands", function(hands, vm, ply, wpn)
	if IsValid(hands) and hands:GetModel() == "models/kapuyas/kemono/kurena/asdfg_kurena_c_hands.mdl" then
		hands:SetSkin(ply:GetSkin())
		hands:SetBodygroup(1,(ply:GetBodygroup(4)))
		hands:SetBodygroup(2,(ply:GetBodygroup(5)))
		hands:SetBodygroup(3,(ply:GetBodygroup(7)))
	end
end)