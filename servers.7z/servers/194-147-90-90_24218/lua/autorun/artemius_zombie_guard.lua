-- "lua\\autorun\\artemius_zombie_guard.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP Zombie Guard", "models/artemius/scp/zombie_guard/zombie_guard.mdl" )
list.Set( "PlayerOptionsModel",  "SCP Zombie Guard", "models/artemius/scp/zombie_guard/zombie_guard.mdl" )