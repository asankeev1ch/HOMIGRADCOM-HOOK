-- "lua\\autorun\\artemius_mog_e11_npc.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
--Add NPC
local Category = "SCP:CB NPC's"

local NPC = { 	Name = "MOG E - 11 Friendly", 
				Class = "npc_citizen",
				Model = "models/artemius/human/mog_e11/mog_e11.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "MOG E - 11 Friendly", NPC )

local Category = "SCP:CB NPC's"

local NPC = { 	Name = "MOG E - 11 Angry", 
				Class = "npc_combine",
				Model = "models/artemius/human/mog_e11/mog_e11.mdl",
				Health = "300",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "MOG E - 11 Angry", NPC )

local Category = "SCP:CB NPC's"