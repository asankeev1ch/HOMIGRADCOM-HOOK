-- "lua\\autorun\\artemius_mog_e11.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP MOG E - 11", "models/artemius/human/mog_e11/mog_e11.mdl" )
list.Set( "PlayerOptionsModel", "SCP MOD E - 11", "models/artemius/human/mog_e11/mog_e11.mdl" )