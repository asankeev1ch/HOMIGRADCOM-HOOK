-- "lua\\autorun\\spiderman_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "MCOC Spiderman", "models/vinrax/player/spiderman.mdl" )

list.Set( "PlayerOptionsModel",  "MCOC Spiderman", "models/vinrax/player/spiderman.mdl" )

player_manager.AddValidHands( "MCOC Spiderman", "models/vinrax/weapons/c_arms_spiderman.mdl", 0, "00000000" )