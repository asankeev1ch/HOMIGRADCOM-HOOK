-- "lua\\autorun\\ligeia_pm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Ligeia", "models/Keith3201/Ligeia/Ligeia_pm.mdl" )
list.Set( "PlayerOptionsModel", "Ligeia", "models/Keith3201/Ligeia/Ligeia_pm.mdl" )
player_manager.AddValidHands( "Ligeia", "models/Keith3201/Ligeia/Ligeia_pm_arms.mdl", 0, "00000000" )