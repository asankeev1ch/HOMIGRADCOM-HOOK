-- "lua\\autorun\\ronald_mcdonald.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Ronald McDonald", 	"models/ronald_mcdonald.mdl" );
list.Set( "PlayerOptionsModel", "Ronald McDonald",   "models/ronald_mcdonald.mdl" );