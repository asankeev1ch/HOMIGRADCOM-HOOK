-- "lua\\autorun\\protoman.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "galaxyman_green_blue", "models/player/galaxyman/galaxyman_green_blue.mdl" )
player_manager.AddValidHands( "galaxyman_green_blue", "models/player/galaxyman/galaxyman_hands_green_blue.mdl", 0, "00000000", true )
list.Set( "PlayerOptionsModel", "Proto Man", "models/player/galaxyman/galaxyman_green_blue.mdl" )
