-- "lua\\autorun\\rei_ayanami_b21_playermodel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Rei Ayanami B21", "models/b21/rei_ayanami_edit.mdl" )
player_manager.AddValidHands( "Rei Ayanami B21", "models/weapons/rei_b21_c_arms.mdl", 0, "00000000" )