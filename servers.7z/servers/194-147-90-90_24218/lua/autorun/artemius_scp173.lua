-- "lua\\autorun\\artemius_scp173.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "SCP 173", "models/artemius/scp/173/scp173.mdl" );
list.Set( "PlayerOptionsModel",  "SCP 173", "models/artemius/scp/173/scp173.mdl" )