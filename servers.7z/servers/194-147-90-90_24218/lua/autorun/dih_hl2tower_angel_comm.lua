-- "lua\\autorun\\dih_hl2tower_angel_comm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "TWHL Angel", "models/dih/hl2tower_angel.mdl" )
player_manager.AddValidModel("TWHL Angel", "models/dih/hl2tower_angel.mdl")
player_manager.AddValidHands( "TWHL Angel", "models/dih/arms/hl2tower_angel.mdl", 0, "0000000" ) 