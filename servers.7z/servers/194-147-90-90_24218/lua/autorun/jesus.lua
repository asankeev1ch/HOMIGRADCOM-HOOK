-- "lua\\autorun\\jesus.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
/*
	Addon by Rokay "Rambo"	
*/

player_manager.AddValidModel( "Jesus", 		"models/player/jesus/jesus.mdl" );
list.Set( "PlayerOptionsModel", "Jesus", 	"models/player/jesus/jesus.mdl" );

