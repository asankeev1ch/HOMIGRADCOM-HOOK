-- "lua\\autorun\\toybox_reworked_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then
	local function RegisterNetworkHooks()
		util.AddNetworkString('ToyBoxReworked_ArmyMakerRespond')
		util.AddNetworkString('ToyBoxReworked_ArmyMakerAnswer')
		util.AddNetworkString('ToyBoxReworked_scv_elc')
		util.AddNetworkString('ToyBoxReworked_Quest_NPC')
		util.AddNetworkString('ToyBoxReworked_RaveBreak')
		util.AddNetworkString('ToyBoxReworked_RaveEnd')
		util.AddNetworkString('ToyBoxReworked_RiftScale')
		util.AddNetworkString('ToyBoxReworked_RiftDie')
		util.AddNetworkString('ToyBoxReworked_toybox_629_enablehooks')
		util.AddNetworkString('ToyBoxReworked_toybox_629_disablehooks')
		util.AddNetworkString('ToyBoxReworked_toybox_629_fuelbarspeed')
		util.AddNetworkString('ToyBoxReworked_GoodbyePack')
		util.AddNetworkString('ToyBoxReworked_GoodbyeDie')
		util.AddNetworkString('ToyBoxReworked_GoodbyeDieRemove')
		util.AddNetworkString('ToyBoxReworked_MPMask')
		util.AddNetworkString('ToyBoxReworked_GUNSTRU_CouldShoot')
		util.AddNetworkString('ToyBoxReworked_pixel_weapon_swing')
		util.AddNetworkString('ToyBoxReworked_pixel_weapon_menu')
		util.AddNetworkString('ToyBoxReworked_ExplodeDynamicLight')
		util.AddNetworkString('ToyBoxReworked_gunstrukebox')
		util.AddNetworkString('ToyBoxReworked_rapidrail_PrimaryFire')
		util.AddNetworkString('ToyBoxReworked_rapidrail_SecondaryFire')
	end

	RegisterNetworkHooks()
end