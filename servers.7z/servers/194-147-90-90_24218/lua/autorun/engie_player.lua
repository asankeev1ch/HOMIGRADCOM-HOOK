-- "lua\\autorun\\engie_player.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel("Engineer", "models/player/engieplayer/engie.mdl")
list.Set("PlayerOptionsModel", "Engineer", "models/player/engieplayer/engie.mdl")
player_manager.AddValidHands("Engineer", "models/player/engieplayer/engineer_hands.mdl", 0, "00000000")