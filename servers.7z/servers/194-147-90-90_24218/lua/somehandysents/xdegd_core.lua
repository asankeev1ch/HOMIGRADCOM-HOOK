-- "lua\\somehandysents\\xdegd_core.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
sound.Add( { name = "xdegd.Drink", channel = CHAN_VOICE, volume = 0.75, level = 70, pitch = { 145, 155 }, sound = "vo/taunts/engy/eng_guzzle_03.mp3" } )
sound.Add( { name = "xdegd.Eat", channel = CHAN_VOICE, volume = 0.75, level = 70, pitch = { 145, 155 }, sound = "vo/taunts/engy/eng_guzzle_03.mp3" } )

xdegd = {} --诶嘿又到了咱的拿手绝活物品机制了啦
xdegd.items = {} --所有物品数据存储
xdegd.cates = {} --物品分栏
xdegd.dirts = {  --可种植土壤
    [ 0 ] = 1.25, --种植盆,正常生长
    [ MAT_CONCRETE ] = 0.6, --石头,明显不行
    [ MAT_WOOD ] = 0.8, --木头,也许不行
    [ MAT_FOLIAGE ] = 1, --杂草降低生长速度
    [ MAT_GRASS ] = 1.1, --草坪好一点
    [ MAT_DIRT ] = 1.25, --正常土壤
    [ MAT_SAND ] = 1.4, --沙地,只要有水
    [ MAT_FLESH ] = 1.6, --嘿嘿
}

function xdegd.ItemRegister( CLS, DT ) --物品录入
    if !isstring( CLS ) or !istable( DT ) or CLS == "" or CLS == "_" then return end
    local IT = {}
    IT.Name 		= isstring( DT.Name ) and DT.Name or "" --物品名称
    IT.Category 	= isstring( DT.Category ) and DT.Category or "Other" --物品分栏
    IT.CarryAng     = isangle( DT.CarryAng ) and DT.CarryAng or Angle( 0, 0, 0 ) --捡起时修改角度
    IT.Model        = isstring( DT.Model ) and DT.Model or "" --物品模型
    IT.Color        = DT.Color or nil --物品颜色,不填为白色
    IT.NoColor      = isbool( DT.NoColor ) and DT.NoColor or nil --仅显示效果颜色不改变实体颜色
    IT.Material     = isstring( DT.Material ) and DT.Material or nil --物品颜色,不填为正常
    IT.Class        = CLS --这个不碰
    
    if CLIENT then
        IT.Helper 		 = isstring( DT.Helper ) and DT.Helper or "" --物品注释,仅显示在工具箱里
        IT.Hidden 		 = isbool( DT.Hidden ) and DT.Hidden or nil --隐藏物品
        IT.OnDraw        = isfunction( DT.OnDraw ) and DT.OnDraw or nil --实体渲染
        IT.OnUse         = isfunction( DT.OnUse ) and true or nil --实体是否有互动
    else
        IT.OnInit        = isfunction( DT.OnInit ) and DT.OnInit or nil --放出
        IT.OnRemove      = isfunction( DT.OnRemove ) and DT.OnRemove or nil --删除
        IT.OnThink       = isfunction( DT.OnThink ) and DT.OnThink or nil --运行
        IT.OnTouch       = isfunction( DT.OnTouch ) and DT.OnTouch or nil --触碰
        IT.OnUse         = isfunction( DT.OnUse ) and DT.OnUse or nil --Shift+E互动
        IT.OnInter       = isfunction( DT.OnInter ) and DT.OnInter or nil --捡起互动
        IT.OnPickup      = isfunction( DT.OnPickup ) and DT.OnPickup or nil --捡起
        IT.OnHurt        = isfunction( DT.OnHurt ) and DT.OnHurt or nil --受伤
        IT.Physics       = isstring( DT.Physics ) and DT.Physics or "Default" --碰撞音效
        IT.TickRate 	 = isnumber( DT.TickRate ) and DT.TickRate or nil --Think计算间隔
    end

    if DT.Seed then -- 种子
        IT.Seed          = isstring( DT.Seed ) and DT.Seed or "" --植物模型
        IT.FixPos        = isvector( DT.FixPos ) and DT.FixPos or nil --植物位置修正
        IT.FixAng        = isangle( DT.FixAng ) and DT.FixAng or nil --果实角度修正
        IT.MaxSize       = isnumber( DT.MaxSize ) and math.max( 0.1, DT.MaxSize ) or 0.5 --生长最大大小
        IT.Growth        = isnumber( DT.Growth ) and DT.Growth or 10 --生长到成熟时间(分钟)
        IT.FruitRate     = isnumber( DT.FruitRate ) and DT.FruitRate or 100 --结果频率,一秒一判定
        IT.FruitPos      = istable( DT.FruitPos ) and DT.FruitPos or {} --结果位置集合
        IT.FruitName     = isstring( DT.FruitName ) and DT.FruitName or "_" --结果物品
        IT.WaterNeed     = istable( DT.WaterNeed ) and DT.WaterNeed or { 25, 75} --浇水量标
        IT.FertileNeed   = istable( DT.FertileNeed ) and DT.FertileNeed or { 0, 50 } --施肥量标
        if SERVER and util.IsValidModel( IT.Seed ) then util.PrecacheModel( IT.Seed ) end
    elseif DT.Food then -- 食物
        IT.Food          = isstring( DT.Food ) and DT.Food or ""  --食用音效
        IT.HPAdd         = isnumber( DT.HPAdd ) and DT.HPAdd or 0 --食用加血
        IT.APAdd         = isnumber( DT.APAdd ) and DT.APAdd or 0 --食用加甲
        IT.Total         = isnumber( DT.Total ) and DT.Total or 1 --食用次数
        IT.Meter         = istable( DT.Meter ) and DT.Meter or { 0.6, 0.9 } --半生,熟,糊
    else
        if CLIENT then
            IT.InterTxt      = istable( DT.InterTxt ) and DT.InterTxt or nil --捡起互动左右键注释
        end
    end

    xdegd.items[ CLS ] = IT
    if !istable( xdegd.cates[ IT.Category ] ) then xdegd.cates[ IT.Category ] = {} end
    table.insert( xdegd.cates[ IT.Category ], CLS )
end

function xdegd.ItemGet( CLS ) --物品信息获取
    return isstring( CLS ) and xdegd.items[ CLS ] or nil
end

function xdegd.LoadFiles() --载入相关文件
    xdegd.items = {}  xdegd.cates = {}
    local fil, dir = file.Find( "somehandysents/xdegd_*.lua", "LUA" )
    if !fil or !dir then return end
    for _, out in pairs( fil ) do if out == "xdegd_core.lua" then continue end
        if SERVER then AddCSLuaFile( "somehandysents/"..out ) end
        include( "somehandysents/"..out )
    end
end
xdegd.LoadFiles()

if SERVER then
    util.AddNetworkString( "xdegd_C2S_Pickup" )

    function xdegd.ItemSpawn( nam, pos, ang, own )
        if !isstring( nam ) or !istable( xdegd.items[ nam ] ) then return nil end
        if !isvector( pos ) then pos = Vector( 0, 0, 0 ) end
        if !isangle( ang ) then ang = Angle( 0, 0, 0 ) end
        local dat = xdegd.items[ nam ]
        local ent = ents.Create( "sent_she_xdegd" )
        ent:SetPos( pos )
        ent:SetAngles( ang )
        ent:SetModel( dat.Model )
        ent:SetXDE_DT( nam )
        ent:SetMaterial( dat.Material or nil )
		if !IsValid( own ) or !own:IsPlayer() then own = Entity( 0 )
		elseif NADMOD then NADMOD.PlayerMakePropOwner( own, ent ) end
        ent:Spawn()
        ent:Activate()
        ent:SetXDE_OW( own )
        if !dat.NoColor then ent:SetColor( dat.Color or Color( 255, 255, 255 ) ) end
        ent:SetMaterial( dat.Material or "" )
        if own:IsPlayer() then
            hook.Run( "PlayerSpawnedSENT", own, ent )
            undo.Create( dat.Name )
            undo.AddEntity( ent )
            undo.SetPlayer( own )
            undo.Finish()
        end
        return ent
    end

	xdeshe_ActionRegister( "garden", function( ply, id, ent, dat )
		if ent:GetClass() != "sent_she_garden" or !ply:CheckLimit( "sents" ) then return end
		local pos = ( ent:WorldSpaceCenter() +ent:GetUp()*32 )  if !util.IsInWorld( pos ) then return end
		local ite = xdegd.ItemSpawn( dat, pos, Angle( 0, ent:GetAngles().yaw, 0 ), ply )
		if IsValid( ite ) then ent:EmitSound( "AmmoCrate.Open" ) end
	end )

    hook.Add( "OnPlayerPhysicsPickup", "xdegd_oppp", function( ply, ent )
        if ent:GetClass() == "sent_she_xdegd" then
            ent:SetXDE_US( ply )
        end
    end )

    hook.Add( "OnPlayerPhysicsDrop", "xdegd_oppp", function( ply, ent, typ )
        if ent:GetClass() == "sent_she_xdegd" then
            local user = ent:GetXDE_US()
            if IsValid( user ) and user.XDEGD == ent then
                user.XDEGD = nil
            end
            ent:SetXDE_US( Entity( 0 ) )
        end
    end )

    hook.Add( "KeyPress", "xdegd_kp", function( ply, key )
        local ent = ply.XDEGD
        if IsValid( ent ) and ent:GetXDE_US() == ply then
            if key == IN_ATTACK then
                ent:Interact( ply, false )
                ply.XDEGD_I = CurTime() +0.25
            elseif key == IN_ATTACK2 then
                ent:Interact( ply, true )
                ply.XDEGD_I = CurTime() +0.25
            end
        end
    end )

    hook.Add( "StartCommand", "xdegd_sc", function( ply, cmd )
        if ply.XDEGD_I and ply.XDEGD_I > CurTime() then
            if cmd:KeyDown( IN_ATTACK ) then
                cmd:RemoveKey( IN_ATTACK )
            end
            if key == IN_ATTACK2 then
                cmd:RemoveKey( IN_ATTACK2 )
            end
        end
    end )

    net.Receive( "xdegd_C2S_Pickup", function( len, ply )
        if !IsValid( ply ) or !ply:Alive() then return end
        local act, ent = math.Round( net.ReadFloat() ), net.ReadEntity()
        if !IsValid( ent ) or ent:GetClass() != "sent_she_xdegd" or ent:IsPlayerHolding() then return end
        local dist = ent:GetPos():Distance( ply:GetPos() )  if dist > 128 then return end
        if NADMOD and !NADMOD.PlayerCanTouch( ply, ent ) then return end
        if act == 1 then
            ply:PickupObject( ent )
        elseif act == 2 then
            ent:EmitSound( "Flesh.ImpactSoft" )
            ent:SetAngles( Angle( 0, ent:GetAngles().yaw, 0 ) )
        end
    end )
else
    xdegd.dmenu = nil  xdegd.potmat = xdeshe_OnceMat( "models/shiny" )

    xdeshe_MenuRegister( "garden", function( id, ent, dat )
        local Mat, Ma2, Ma3 = xdesc.mat1, xdesc.mat4, xdesc.mat3
        local now = IsValid( xdeshe_vguis[ id ] )
        local pan = ( IsValid( xdeshe_vguis[ id ] ) and xdeshe_vguis[ id ] or vgui.Create( "DFrame" ) )
        surface.PlaySound( "ui/hint.wav" )
        pan:Show()
        pan:SetKeyboardInputEnabled( true )
        pan:SetMouseInputEnabled( true )
        pan:MakePopup()
        pan:SetAlpha( 1 )
        pan:AlphaTo( 255, 0.25 )
        pan:SetSize( 706, 40 )
        pan:SetPos( ScrW()/2 -353, ScrH()/2 -20 )
        pan:SizeTo( 706, 550, 0.25 )
        pan:MoveTo( ScrW()/2 -353, ScrH()/2 -275, 0.25 )
        pan.E_Entity 	= ent
        pan.B_Close 	= false
        pan.S_Texts 	= ""
        pan.S_Text 		= ""
        xdeshe_mark = nil  xdeshe_mtype = nil  xdeshe_delay = 0
        if now then return end
        pan:SetTitle( "" )
        pan:ShowCloseButton( false )
        pan:SetScreenLock( true )
        pan.P_Select 	= nil
        pan.P_On 		= nil
        pan.T_Mdls = {}
        pan.T_Cats = {}
        function pan:Paint( w, h )
            surface.SetDrawColor( 0, 128, 0 ) surface.DrawRect( 0, 0, w, h )
            surface.SetDrawColor( 0, 128, 0 ) surface.DrawRect( 0, 0, w, 40 )
            surface.SetMaterial( Mat ) surface.SetDrawColor( 0, 128, 255 ) surface.DrawTexturedRect( 0, 0, w, 40 )
            surface.SetMaterial( Ma2 ) surface.SetDrawColor( 0, 0, 0, 128 )
            surface.DrawTexturedRectRotated( w/2, h/2 +20, w, ( h -40 ), 0 )
            surface.DrawTexturedRectRotated( w/2, h/2 +20, w, ( h -40 ), 180 )
            surface.SetDrawColor( 0, 255, 0 ) surface.DrawOutlinedRect( 0, 0, w, h, 2 )
            surface.SetDrawColor( 0, 0, 0 ) surface.DrawOutlinedRect( 0, 0, w, h )
            draw.TextShadow( {
                text = language.GetPhrase( "xdeshe.sent_garden" ),
                pos = { 8, 20 },
                font = "xdeshe_Font2",
                xalign = TEXT_ALIGN_LEFT,
                yalign = TEXT_ALIGN_CENTER,
                color = Color( 255, 255, 255 )
            }, 1, 255 )
        end
        function pan:MenuClose()
            if pan.B_Close then return end pan.B_Close = true  pan:AlphaTo( 1, 0.2 )
            timer.Simple( 0.2, function() if IsValid( pan ) and pan.B_Close then pan:Hide() end end )
            pan:SetMouseInputEnabled( false ) pan:SetKeyboardInputEnabled( false )
            net.Start( "xdeshe_C2S_MenuClose" ) net.SendToServer()
        end
        if true then --关闭按钮
            pan.P_Close = pan:Add( "DButton" )  local pax = pan.P_Close
            pax:SetText( "" )
            pax:SetPos( 670, 6 )
            pax:SetSize( 32, 32 )
            pax.B_Hover = false
            function pax:Paint( w, h )
                draw.TextShadow( {
                    text = "×",
                    pos = { w/2, h/2 },
                    font = "xdeshe_Font2",
                    xalign = TEXT_ALIGN_CENTER,
                    yalign = TEXT_ALIGN_CENTER,
                    color = ( pax.B_Hover and Color( 255, 0, 0 ) or Color( 255, 255, 255 ) )
                }, 1, 255 )
            end
            function pax:DoClick()
                if pan.B_Close then return end
                surface.PlaySound( "ui/buttonclick.wav" )
                pan:MenuClose()
            end
            function pax:OnCursorEntered() pax.B_Hover = true end
            function pax:OnCursorExited() pax.B_Hover = false end
        end
        if true then
            local pax = pan:Add( "DPropertySheet" )
            pax:SetPos( 6, 44 )
            pax:SetSize( 694, 500 )
            pax:SetPadding( 1 )
            function pax:Paint( w, h )
                surface.SetDrawColor( 32, 128, 32 )
                surface.DrawRect( 0, 20, w, h -20 )
                surface.SetDrawColor( 0, 0, 0 )
                surface.DrawOutlinedRect( 0, 20, w, h -20, 2 )
                surface.SetDrawColor( 0, 255, 0 )
                surface.DrawOutlinedRect( 0, 20, w, h -20, 1 )
            end
            local function AddASheetAM( tit, ico )
                local pae = vgui.Create( "DPanel" )
                pae.T_Items = {}
                function pae:Paint( w, h )
                    surface.SetDrawColor( 255, 255, 255, 100 )
                    surface.SetMaterial( Ma2 )
                    surface.DrawTexturedRectRotated( w/2, h/2, w, h, 0 )
                    surface.DrawTexturedRectRotated( w/2, h/2, w, h, 180 )
                end
                local ttt = pax:AddSheet( tit, pae, ico )
                function ttt.Tab:Paint( w, h )
                    local alp = ttt.Tab:IsActive() and 1 or 0.5
                    draw.RoundedBoxEx( 0, 0, 0, w, 20, Color( 0, 192, 0 ), true, true, false, false )
                    draw.RoundedBoxEx( 0, 1, 1, w -2, 20, Color( 0, 0, 0 ), true, true, false, false )
                    draw.RoundedBoxEx( 0, 2, 2, w -4, 20, Color( 32*alp, 128*alp, 32*alp ), true, true, false, false )
                end
                pae.P_Scroll = ttt.Panel:Add( "DScrollPanel" )
                pae.P_Scroll:SetPos( 5, 5 )
                pae.P_Scroll:SetSize( 694, 468 )
                local vba = pae.P_Scroll:GetVBar()
                vba:SetHideButtons( true )
                vba:SetSize( 0, 0 )
                pae.P_Hold = pae.P_Scroll:Add( "DIconLayout" )
                pae.P_Hold:Dock( FILL )
                pae.P_Hold:SetSpaceX( 2 )
                pae.P_Hold:SetSpaceY( 2 )
                function pae:ShowButs()
                    if ttt.B_Init then return end ttt.B_Init = true
                    for k, v in pairs( pae.T_Items ) do
                        local dat = xdegd.items[ v ]
                        local ite = pae.P_Hold:Add( "DButton" )
                        ite:SetSize( 112, 112 )
                        ite:SetText( "" )
                        ite.B_Hover = false
                        ite.N_Lerp = 0
                        function ite:Paint( w, h )
                            local ler = math.Clamp( ( ite.N_Lerp -SysTime() )/0.1, 0, 1 )
                            if ite.B_Hover then ler = 1-ler end
                            surface.SetDrawColor( 0, 96, 0 )
                            surface.DrawRect( 0, 0, w, h )
                            surface.SetDrawColor( 255, 255, 255 )
                            surface.SetMaterial( Ma3 )
                            surface.SetDrawColor( Color( 0, 128 +64*ler, 255*ler ) )
                            surface.DrawTexturedRect( 0, 0, w, h )
                            surface.DrawOutlinedRect( 0, 0, w, h, 3 +ler*2 )
                            surface.SetDrawColor( 0, 0, 0 )
                            surface.DrawOutlinedRect( 0, 0, w, h, 2 )
                            surface.SetDrawColor( Color( 0, 0, 0, 192 ) )
                            surface.DrawRect( 0, h*3/4 +h*1/4*ler, w, h/4 )
                            draw.TextShadow( {
                                text = dat.Name,
                                pos = { w/2, h -14 +h*1/4*ler },
                                font = "xdeshe_Font4",
                                xalign = TEXT_ALIGN_CENTER,
                                yalign = TEXT_ALIGN_CENTER,
                                color = Color( 255, 255, 255, 255 )
                            }, 1, alp )
                        end
                        function ite:OnCursorEntered() ite.B_Hover = true  ite.N_Lerp = SysTime() +0.1
                            xdeshe_mark = v  xdeshe_mtype = "xdegd"  xdeshe_delay = 0
                        end
                        function ite:OnCursorExited() ite.B_Hover = false  ite.N_Lerp = SysTime() +0.1
                            if xdeshe_mark == v and xdeshe_mtype == "xdegd" then
                                xdeshe_mark = nil  xdeshe_mtype = nil
                            end
                        end
                        function ite:DoClick() if pan.B_Close then return end
                            xdeshe_MenuAction( LocalPlayer(), id, v )
                        end
                        local ic2 = ite:Add( "DModelPanel" )
                        ic2:DockMargin( 10, 0, 10, 20 )
                        ic2:Dock( FILL )
                        ic2:SetModel( dat.Model )
                        local mins, maxs = ic2.Entity:GetRenderBounds()
                        ic2:SetFOV( mins:Distance( maxs )*0.75 )
                        ic2:SetLookAt( ( mins +maxs )/2 )
                        ic2:SetMouseInputEnabled( false )
                        ic2:SetKeyBoardInputEnabled( false )
                        ic2.Entity:SetMaterial( dat.Material or nil )
                        if !dat.NoColor then ic2:SetColor( dat.Color or Color( 255, 255, 255 ) ) end
                        ic2:SetDirectionalLight( BOX_TOP, Color( 155, 155, 155 ) )
                        ic2:SetAmbientLight( Color( 255, 255, 255, 255 ) )
                        table.insert( pan.T_Mdls, ic2 )
                    end
                end
                ttt.Tab.xdeshe_DC = ttt.Tab.DoClick
                function ttt.Tab:DoClick()
                    ttt.Tab:xdeshe_DC()
                    pae:ShowButs()
                end
                return pae
            end
            local fir = nil
            for k, v in SortedPairsByMemberValue( xdegd.items, "Name" ) do
                if v.Hidden then continue end
                local she = pan.T_Cats[ v.Category ]
                if !pan.T_Cats[ v.Category ] then
                    she = AddASheetAM( language.GetPhrase( v.Category ), "icon16/plugin.png" )
                end
                if !fir then fir = she end
                table.insert( she.T_Items, k )
                pan.T_Cats[ v.Category ] = she
            end
            if fir then fir:ShowButs() end
        end
        return pan
    end )
end

if true then
	local SENT 			= {}
	SENT.PrintName 		= ""
	SENT.Base 			= "base_gmodentity"
	SENT.Spawnable 		= false
	SENT.RenderGroup 	= RENDERGROUP_TRANSLUCENT
	SENT.XDE_Touch 		= false
	SENT.XDE_Vel 		= Vector( 0, 0, 0 )
	SENT.XDE_NextEmit 	= 0
	function SENT:Initialize()
		if !SERVER then return end
		self:SetModel( "models/props_junk/watermelon01_chunk02a.mdl" )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:DrawShadow( false )
		self:SetCollisionGroup( COLLISION_GROUP_DEBRIS_TRIGGER )
		self:PhysicsInitSphere( 4, "slipperyslime" )
		self:SetTrigger( true )
		local phys = self:GetPhysicsObject()
		phys:AddGameFlag( FVPHYSICS_NO_IMPACT_DMG )
		phys:AddGameFlag( FVPHYSICS_NO_NPC_IMPACT_DMG )
		phys:AddGameFlag( FVPHYSICS_NO_PLAYER_PICKUP )
		phys:AddGameFlag( FVPHYSICS_WAS_THROWN )
		phys:SetMass( 1 )
		phys:Wake()
		self:UseTriggerBounds( true, 4 )
		self:SetTrigger( true )
	end
	function SENT:PhysicsCollide( dat )
		if !self.XDE_Touch and self:WaterLevel() <= 0 then
			if !IsValid( dat.HitEntity ) or ( dat.HitEntity:GetClass() != "sent_she_gas" and dat.HitEntity:GetClass() != "sent_she_water" ) then
				self:PlaceWater( dat.HitPos -dat.HitNormal, dat.HitEntity, -dat.HitNormal )
			end
		end
	end
	function SENT:Think()
		if CLIENT then return true end
		if !self.XDE_Touch and self:WaterLevel() > 0 then
			self.XDE_Touch = true  self:Remove()
		end
		if self:IsOnFire() then self:Extinguish() end
		self:NextThink( CurTime() +0.1 )
		return true
	end
	function SENT:OnTakeDamage( dmg ) self:TakePhysicsDamage( dmg )
		if !self.XDE_Touch and xdeshe_IsFireDmg( dmg ) then self.XDE_Touch = true  self:Remove() end
	end
	function SENT:StartTouch( ent )
		if ent:GetClass() != self:GetClass() and ( !IsValid( self.Owner ) or ent != self.Owner ) and !self.XDE_Touch then
			local tr = util.QuickTrace( self:GetPos() -self.XDE_Vel:GetNormalized(), self:GetPos() +self.XDE_Vel:GetNormalized(), self )
			if tr.Hit and IsValid( tr.Entity ) and tr.Entity == ent then
				self:PlaceWater( tr.HitPos -tr.HitNormal, ent, -tr.HitNormal )
			else
				self:PlaceWater( self:GetPos(), ent, Vector( 0, 0, 0 ) )
			end
		end
	end
	function SENT:OnRemove()
		if self.Emitter then self.Emitter:Finish() end
	end
	function SENT:PlaceWater( pos, ent, nor )
		if !SERVER or self:WaterLevel() > 0 then return end self.XDE_Touch = true
		SafeRemoveEntityDelayed( self, 0.1 )
		timer.Simple( 0, function()
			local effect = EffectData()
			effect:SetOrigin( pos +nor )
			effect:SetScale( 2 )
            effect:SetFlags( 0 )
			util.Effect( "watersplash", effect )
		end )
		for k, v in pairs( ents.FindInSphere( pos, 16 ) ) do
			if v:GetClass() == "env_fire" or v:GetClass() == "sent_she_gas" then v:Remove() continue end
			if v:IsOnFire() then v:Extinguish() end
            if v:GetClass() == "sent_she_tray" then
                v:SetXDE_Water( math.Clamp( v:GetXDE_Water() +math.Rand( 1, 2 ), 0, 100 ) )
            end
		end
	end
	if CLIENT then
		local Mat = xdeshe_OnceMat( "effects/splash4" )
		function SENT:Draw()
			render.SetMaterial( Mat )
			render.DrawSprite( self:GetPos(), 8, 8, Color( 255, 255, 255 ) )
			if !self.Emitter then
				self.Emitter = ParticleEmitter( self:GetPos() )
			elseif self.XDE_NextEmit <= CurTime() then
				self.XDE_NextEmit = CurTime() +0.01
				self.Emitter:SetPos( self:GetPos() )
				local particle = self.Emitter:Add( "effects/splash4", self:GetPos() )
				if particle then
					particle:SetVelocity( VectorRand():GetNormalized()*math.Rand( 4, 16 ) )
					particle:SetLifeTime( 0 )
					particle:SetDieTime( math.Rand( 0.25, 0.5 ) )
					particle:SetStartAlpha( 192 )
					particle:SetEndAlpha( 0 )
					local Siz = math.Rand( 3, 6 )
					particle:SetStartSize( Siz )
					particle:SetEndSize( Siz/2 )
					particle:SetRoll( math.random( 0, 360 ) )
					particle:SetGravity( VectorRand():GetNormalized()*math.random( -16, 16 ) )
					particle:SetColor( 255, 255, 255 )
					particle:SetAirResistance( 32 )
					particle:SetLighting( false )
					particle:SetCollide( true )
					particle:SetBounce( 0.1 )
				end
			end
		end
	end
	scripted_ents.Register( SENT, "sent_she_water" )
end
if true then
    local SENT          = {}
    SENT.PrintName 		= ""
    SENT.Base 			= "base_gmodentity"
    SENT.Spawnable 		= false
    SENT.RenderGroup 	= RENDERGROUP_BOTH
    SENT.XDE_NextUse 	= 0
    SENT.XDE_Used       = false
    if CLIENT then
        SENT.XDE_CMdl       = nil
        SENT.XDE_Emitter    = nil
        SENT.XDE_NextEmit   = 0
        SENT.XDE_AimStat    = false
        SENT.XDE_AimLerp    = 0
    end

    function SENT:SetupDataTables()
        self:NetworkVar( "String", 0, "XDE_DT" )
        self:NetworkVar( "Entity", 0, "XDE_OW" )
        self:NetworkVar( "Entity", 1, "XDE_US" )
    end

    function SENT:Initialize()
        if CLIENT then return end
        if !isstring( self:GetXDE_DT() ) or self:GetXDE_DT() == "" or self:GetXDE_DT() == "_" then
            self:Remove()
            return
        end
        self:PhysicsInit( SOLID_VPHYSICS )
        self:SetMoveType( MOVETYPE_VPHYSICS )
        self:SetSolid( SOLID_VPHYSICS )
        self:SetUseType( SIMPLE_USE )
        self:GetPhysicsObject():AddGameFlag( FVPHYSICS_NO_IMPACT_DMG )
        self:GetPhysicsObject():AddGameFlag( FVPHYSICS_NO_NPC_IMPACT_DMG )
        self:GetPhysicsObject():Wake()
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if istable( dat ) and isfunction( dat.OnInit ) then dat:OnInit( self ) end
        if dat.Food then
            self:SetNWInt( "XDE_Total", dat.Total )
            self:SetNWFloat( "XDE_Hot", CurTime() +30 )
            self:SetNWFloat( "XDE_Cool", 0.5 )
        end
    end

    function SENT:StartTouch( ent ) if ent == self then return end
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if istable( dat ) and isfunction( dat.OnTouch ) then dat:OnTouch( self, ent, 1 ) end
    end

    function SENT:Touch( ent ) if ent == self then return end
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if istable( dat ) and isfunction( dat.OnTouch ) then dat:OnTouch( self, ent, 0 ) end
    end

    function SENT:EndTouch( ent ) if ent == self then return end
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if istable( dat ) and isfunction( dat.OnTouch ) then dat:OnTouch( self, ent, -1 ) end
    end

    function SENT:OnDuplicated() SafeRemoveEntity( self ) end
    function SENT:OnRestore() if SERVER then SafeRemoveEntity( self ) end end

    function SENT:Use( act )
        if self.XDE_NextUse > CurTime() then return end self.XDE_NextUse = CurTime() +0.25
        if !act:IsPlayer() or !act:Alive() then return end
        if NADMOD and NADMOD.PlayerCanTouch( act, self ) and !IsValid( self:GetXDE_OW() ) then
            self:SetXDE_OW( act )
        end
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if ( !IsValid( self:GetXDE_US() ) or !self:GetXDE_US():IsPlayer() ) and !IsValid( act.XDEGD ) then
            if act:KeyDown( IN_SPEED ) and dat.OnUse then
                dat:OnUse( self, act )
            else
                local pick = isfunction( dat.OnPickup ) and dat:OnPickup( self, act ) or true
                if pick != false and !self:IsPlayerHolding() and !constraint.FindConstraint( self, "Weld" )
                and self:GetPhysicsObject():IsMotionEnabled() and !IsValid( self:GetParent() ) then
                    local _, ang = LocalToWorld( Vector(), Angle( 0, act:EyeAngles().yaw, 0 ), Vector(), dat.CarryAng )
                    self:SetAngles( ang )
                    act:PickupObject( self )
                    act.XDEGD = self
                end
            end
        end
    end

    function SENT:Interact( act, sec )
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if !istable( dat ) then return end
        if dat.Seed and !sec then
            local tr = util.TraceLine( {
                start = self:GetPos(),
                endpos = self:GetPos() -Vector( 0, 0, 8 ),
                filter = self,
                mask = MASK_SHOT_HULL,
            } )
            local ang, mat = ( tr.HitNormal:Angle() +Angle( 90, 0, 0 ) ), tr.MatType
            local no = ( !tr.HitWorld or ang.pitch -360 > 20 or !xdegd.dirts[ mat ] )
            if no then
                self:EmitSound( "HL2Player.UseDeny" )
                self:GetPhysicsObject():SetVelocity( Vector( 0, 0, 0 ) )
            else
                xdeshe_BroadEffect( "xdeshe_dirt", { Origin = tr.HitPos } )
                local try = ents.Create( "sent_she_tray" )
                try:SetPos( tr.HitPos -Vector( 0, 0, 2 ) ) try:SetAngles( Angle( ang.pitch, self:GetAngles().yaw, ang.roll ) )
                try:SetModel( "models/notsavedqaq/dirt.mdl" ) try:Spawn() try:Activate() try:SetMoveType( MOVETYPE_NONE )
                try:SetXDE_Ground( mat ) try:SetXDE_Type( dat.Class )
                try.XDE_FixPos = Vector( 0, 0, -4 )  try:SetXDE_Health( 100 )
                local grd = xdegd.dirts[ mat ] or xdegd.dirts[ 0 ]
                try:SetXDE_Water( 50*grd ) try:SetXDE_Fertile( 25*grd )
                local pla = ents.Create( "base_anim" )  try:SetXDE_Plant( pla )
                pla:SetModel( dat.Seed ) pla:DrawShadow( false )
                pla:SetAngles( try:WorldToLocalAngles( Angle( 0, math.random( 0, 360 ), 0 ) ) )
                pla:SetOwner( try ) pla:SetParent( try ) pla:Spawn() pla:Activate() pla:SetRenderMode( RENDERMODE_NONE )
                pla:SetModelScale( 0.01 )
                pla:SetPos( try:LocalToWorld( try.XDE_FixPos +( dat.FixPos or Vector( 0, 0, 0 ) )*0.01 ) )
                try:SetCollisionGroup( COLLISION_GROUP_WEAPON )
                timer.Simple( 0.1, function() if IsValid( try ) and IsValid( pla ) then
                    pla:SetRenderMode( RENDERMODE_TRANSADD )
                end end )
                undo.ReplaceEntity( self, try ) cleanup.ReplaceEntity( self, try )
                self.XDE_Used = true  self:Remove()
            end
            return
        end

        if dat.OnInter then
            dat:OnInter( self, act, sec )
        end
    end

    function SENT:OnRemove()
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if IsValid( self.XDE_CMdl ) then self.XDE_CMdl:Remove() end
        if istable( dat ) and isfunction( dat.OnRemove ) then dat:OnRemove( self ) end
    end

    function SENT:Think()
        self:NextThink( CurTime() +0.1 )
        if SERVER then
            local dat = xdegd.items[ self:GetXDE_DT() ]
            if istable( dat ) and isfunction( dat.OnThink ) then dat:OnThink( self ) end
        else
            if !istable( xdegd.items[ self:GetXDE_DT() ] ) then return end
            if self.XDE_AimStat != self:BeingLookedAtByLocalPlayer() then
                self.XDE_AimStat = self:BeingLookedAtByLocalPlayer()
                self.XDE_AimLerp = SysTime() +0.2
            end
            if self.XDE_AimStat then
                local dat = xdegd.items[ self:GetXDE_DT() ]
                halo.Add( { self }, dat.Color or Color( 255, 255, 255 ), 1, 1, 1 )
            end
        end
        return true
    end

    function SENT:OnTakeDamage( dmg ) self:TakePhysicsDamage( dmg )
        local dat = xdegd.items[ self:GetXDE_DT() ]
        if istable( dat ) and isfunction( dat.OnHurt ) then dat:OnHurt( self, dmg ) end
    end

    function SENT:PhysicsCollide( dat, phy )
        local xxx = xdegd.items[ self:GetXDE_DT() ]
        if !istable( xxx ) then return end
        if dat.Speed >= 60 and dat.DeltaTime > 0.2 then
            self:EmitSound( xxx.Physics..( dat.Speed >= 300 and ".ImpactHard" or ".ImpactSoft" ) )
        end
    end

    function SENT:BindHint( info, binds, height, deny )
        local alp = math.Clamp( ( self.XDE_AimLerp -SysTime() )/0.2, 0, 1 )
        if self.XDE_AimStat then alp = 1-alp end
        local pp = self:WorldSpaceCenter():ToScreen()
        local xx, yy = pp.x, pp.y +32 +height
        surface.SetFont( "xdeshe_Font4" )
        local s1x = surface.GetTextSize( "[ " )

        local tx1, tx2, dow = "", info, #binds
        for k, v in pairs( binds ) do
            local bi = input.LookupBinding( v, true )
            if !bi then tx1 = "???" break end
            tx1 = tx1..string.upper( bi )
            if binds[ k+1 ] then tx1 = tx1.."+" end
            if input.GetKeyCode( bi ) and input.IsKeyDown( input.GetKeyCode( bi ) ) then
                dow = dow-1
            end
        end
        local s2x, s3x = surface.GetTextSize( tx1 ), surface.GetTextSize( tx2 )
        local sx = s1x+s2x+s1x+s3x

        cam.Start2D()
        draw.SimpleTextOutlined( "[", "xdeshe_Font4", xx -sx/2, yy +height +12*( 1-alp ), Color( 255, 255, 255, alp*255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 64*alp, 64*alp, 64*alp, 255*alp ) )
        draw.SimpleTextOutlined( tx1, "xdeshe_Font4", xx -sx/2 +s1x, yy +height +12*( 1-alp ), Color( 0, 255, 0, alp*255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 64*alp, 64*alp, 64*alp, 255*alp ) )
        draw.SimpleTextOutlined( "]", "xdeshe_Font4", xx -sx/2 +s1x*1.5 +s2x, yy +height +12*( 1-alp ), Color( 255, 255, 255, alp*255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 64*alp, 64*alp, 64*alp, 255*alp ) )
        local col = deny and Color( 255, 64, 64 ) or ( ( #binds > 0 and dow <= 0 ) and Color( 0, 255, 0 ) or Color( 255, 255, 255 ) )
        draw.SimpleTextOutlined( tx2, "xdeshe_Font4", xx -sx/2 +s1x*2 +s2x +4, yy +height +12*( 1-alp ), Color( col.r, col.g, col.b, alp*255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 64*alp, 64*alp, 64*alp, 255*alp ) )
        cam.End2D()
    end
    
    local Mat = Material( "models/shiny" )
    function SENT:Draw()
        self:DrawModel()
        local dat, deny, user = xdegd.items[ self:GetXDE_DT() ], false, self:GetXDE_US()
        if halo.RenderedEntity() == self or !istable( dat ) then return end
        if isfunction( dat.OnDraw ) then dat:OnDraw( self ) end
        if dat.Food then
            if self:GetNWFloat( "XDE_Hot" ) > CurTime() then
                if !self.XDE_Emitter then
                    self.XDE_Emitter = ParticleEmitter( self:GetPos() )
                elseif self.XDE_NextEmit <= CurTime() then self.XDE_Emitter:SetPos( self:GetPos() )
                    self.XDE_NextEmit = CurTime() +0.1
                    local vel = self:OBBMaxs()
                    local particle = self.XDE_Emitter:Add( "particle/smokestack", self:WorldSpaceCenter() +Vector( math.Rand( -vel.x, vel.x ), math.Rand( -vel.y, vel.y ), 0 )/2 )
                    if particle then
                        particle:SetVelocity( self:GetUp()*math.Rand( 4, 8 ) +VectorRand():GetNormalized()*4 )
                        particle:SetLifeTime( 0 )
                        particle:SetDieTime( math.Rand( 0.75, 3 ) )
                        particle:SetStartAlpha( 128 )
                        particle:SetEndAlpha( 0 )
                        local Siz = math.Rand( 2, 6 )
                        particle:SetStartSize( Siz/2 )
                        particle:SetEndSize( Siz )
                        particle:SetRoll( math.random( 0, 360 ) )
                        particle:SetGravity( Vector( 0, 0, 25 ) )
                        particle:SetColor( 255, 255, 255 )
                        particle:SetAirResistance( 100 )
                    end
                end
            end
        end
        if !IsValid( self:GetParent() ) and user == LocalPlayer() then
            if dat.Seed then
                local tr = util.TraceLine( {
                    start = self:GetPos(),
                    endpos = self:GetPos() -Vector( 0, 0, 8 ),
                    filter = self,
                    mask = MASK_SHOT_HULL,
                } )
                if tr.Hit then
                    if !IsValid( self.XDE_CMdl ) then local sel = self
                        self.XDE_CMdl = ClientsideModel( dat.Seed, RENDERGROUP_BOTH )  local mdl = self.XDE_CMdl
                        mdl:SetPos( tr.HitPos )
                        mdl:SetAngles( tr.HitNormal:Angle() -Angle( 90, 0, 0 ) )
                        mdl:SetModelScale( dat.MaxSize )
                        mdl:Spawn() mdl:SetColor( Color( 0, 0, 0 ) )
                        mdl:SetRenderMode( RENDERMODE_TRANSCOLOR )
                        mdl:SetMaterial( "debug/debugdrawflat" )
                        function mdl:RenderOverride()
                            if !IsValid( sel ) then return end
                            render.SuppressEngineLighting( true )
                            mdl:DrawModel()
                            render.SuppressEngineLighting( false )
                            render.DrawWireframeBox( mdl:GetPos(), mdl:GetAngles(), mdl:OBBMins(), mdl:OBBMaxs(), Color( mdl:GetColor().r, mdl:GetColor().g, mdl:GetColor().b ) )
                        end
                    else local mdl = self.XDE_CMdl
                        local ang, mat = ( tr.HitNormal:Angle() +Angle( 90, 0, 0 ) ), tr.MatType
                        mdl:SetNoDraw( false )
                        mdl:SetPos( tr.HitPos -tr.HitNormal*4 +( dat.FixPos or Vector( 0, 0, 0 ) ) )
                        mdl:SetAngles( ang )
                        local no = ( !tr.HitWorld or ang.pitch -360 > 20 or !xdegd.dirts[ mat ] )  deny = no
                        local sys = math.abs( math.sin( SysTime()*2 ) )
                        mdl:SetColor( no and Color( 255, 0, 0, 32*sys ) or Color( ( 1-math.min( xdegd.dirts[ mat ], 1 ) )*255, 255, 0, 32*sys ) )
                    end
                else
                    deny = true
                    if IsValid( self.XDE_CMdl ) and !self.XDE_CMdl:GetNoDraw() then
                        self.XDE_CMdl:SetNoDraw( true )
                    end
                end
            end
        else
            if IsValid( self.XDE_CMdl ) and !self.XDE_CMdl:GetNoDraw() then
                self.XDE_CMdl:SetNoDraw( true )
            end
        end
        if ( self.XDE_AimStat or self.XDE_AimLerp > SysTime() ) and ( !IsValid( user ) or !user:IsPlayer() or user == LocalPlayer() ) then
            local alp = math.Clamp( ( self.XDE_AimLerp -SysTime() )/0.2, 0, 1 )
            if self.XDE_AimStat then alp = 1-alp end

            local alp = math.Clamp( ( self.XDE_AimLerp -SysTime() )/0.2, 0, 1 )
            if self.XDE_AimStat then alp = 1-alp end
            local pp = self:WorldSpaceCenter():ToScreen()
            cam.Start2D()
            draw.SimpleTextOutlined( dat.Name, "xdeshe_Font2", pp.x, pp.y +8 +12*( 1-alp ), Color( 255, 255, 255, alp*255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 64*alp, 64*alp, 64*alp, 255*alp ) )
            cam.End2D()

            local height = 0
            if !IsValid( user ) or !user:IsPlayer() or user != LocalPlayer() then
                self:BindHint( "#xdeshe.GDPickup", { "+use" }, height )
                height = height +12
                if dat.OnUse then
                    self:BindHint( "#xdeshe.GDInteract", { "+speed", "+use" }, height )
                    height = height +12
                end
            else
                self:BindHint( "#xdeshe.GDDrop", { "+use" }, height )
                height = height +12
                if dat.Seed then
                    self:BindHint( "#xdeshe.GDPlant", { "+attack" }, height, deny )
                    height = height +12
                elseif istable( dat.InterTxt ) then
                    local txs = dat.InterTxt
                    if txs[ 1 ] then
                        self:BindHint( txs[ 1 ], { "+attack" }, height )
                        height = height +12
                    end
                    if txs[ 2 ] then
                        self:BindHint( txs[ 2 ], { "+attack2" }, height )
                        height = height +12
                    end
                end
            end
        end
    end
    scripted_ents.Register( SENT, "sent_she_xdegd" )
end

if CLIENT then local nam = "xdeshe_dirt"
	local EFFECT = {}
	function EFFECT:Init( data )
		local Ori = data:GetOrigin()
        sound.Play( "Sand.BulletImpact", Ori )
		local emitter = ParticleEmitter( Ori )
		if emitter:IsValid() then
			for i=1, 16 do
				local particle = emitter:Add( "particle/particle_noisesphere", Ori +VectorRand():GetNormalized()*8 )
				local Size = math.Rand( 12, 24 )
				particle:SetVelocity( VectorRand():GetNormalized()*16 +Vector( 0, 0, 16 ) )
				particle:SetLifeTime( 0 )
				particle:SetDieTime( math.Rand( 1, 2 ) )
				particle:SetStartAlpha( 64 )
				particle:SetEndAlpha( 0 )
				particle:SetStartSize( Size )
				particle:SetEndSize( Size )
				particle:SetAirResistance( 16 )
				particle:SetGravity( Vector( 0, 0, -16 ) )
                particle:SetRollDelta( math.Rand( -1, 1 ) )
				particle:SetRoll( math.Rand( 0, 360 ) )
				particle:SetColor( 255, 255, 192 )
				particle:SetCollide( true )
				particle:SetBounce( 0.1 )
				particle:SetLighting( false )
			end
            for i=1, math.random( 12, 16 ) do
                local particle = emitter:Add( "effects/fleck_cement"..math.random( 1, 2 ), Ori +VectorRand():GetNormalized()*8 )
                local Size = math.Rand( 1, 3 )
                if particle then
                    particle:SetVelocity( VectorRand():GetNormalized()*64 +Vector( 0, 0, 64 ) )
                    particle:SetLifeTime( 0 )
                    particle:SetDieTime( math.Rand( 1, 3 ) )
                    particle:SetStartAlpha( 255 )
                    particle:SetEndAlpha( 0 )
                    local Siz = math.Rand( 2, 4 )
                    particle:SetStartSize( Siz )
                    particle:SetEndSize( Siz )
                    particle:SetRoll( math.random( 0, 360 ) )
                    particle:SetRollDelta( math.Rand( -3, 3 ) )
                    particle:SetColor( 255, 255, 255 )
                    particle:SetGravity( Vector( 0, 0, -300 ) )
                    particle:SetColor( 255, 255, 192 )
                    particle:SetAirResistance( 32 )
                    particle:SetCollide( true )
                    particle:SetBounce( 0.5 )
                end
            end
			emitter:Finish()
		end
	end
	function EFFECT:Think() return false end
	function EFFECT:Render() end
	effects.Register( EFFECT, nam )
end
if CLIENT then local nam = "xdeshe_eatfruit"
	local EFFECT = {}
	function EFFECT:Init( data )
        local pos = data:GetOrigin() local sta = data:GetStart()
		self.Emitter = ParticleEmitter( pos )
		self:SetRenderBounds( -Vector( 16, 16, 16 ), Vector( 16, 16, 16 ) )
		for i=1, math.random( 8, 12 ) do
			local particle = self.Emitter:Add( "effects/splash4", pos )
			if particle then
				particle:SetVelocity( VectorRand():GetNormalized()*8 )
				particle:SetLifeTime( 0 )
				particle:SetDieTime( math.Rand( 0.5, 1 ) )
				particle:SetStartAlpha( 192 )
				particle:SetEndAlpha( 0 )
                local Siz = math.random( 4, 8 )
				particle:SetStartSize( Siz )
				particle:SetEndSize( 0 )
				particle:SetRoll( math.random( 0, 360 ) )
				particle:SetRollDelta( math.Rand( -1, 1 ) )
				particle:SetColor( sta.x, sta.y, sta.z )
				particle:SetGravity( Vector( 0, 0, -16 ) )
				particle:SetAirResistance( 32 )
			end
		end
		for i=1, math.random( 12, 16 ) do
			local particle = self.Emitter:Add( "effects/splash4", pos )
			if particle then
				particle:SetVelocity( VectorRand():GetNormalized()*math.random( 16, 24 ) )
				particle:SetLifeTime( 0 )
				particle:SetDieTime( math.Rand( 0.5, 1 ) )
				particle:SetStartAlpha( 192 )
				particle:SetEndAlpha( 0 )
                local Siz = math.random( 4, 8 )
                particle:SetStartSize( Siz )
                particle:SetEndSize( 0 )
                particle:SetStartLength( Siz )
                particle:SetEndLength( Siz )
				particle:SetColor( sta.x, sta.y, sta.z )
                particle:SetGravity( Vector( 0, 0, -16 ) )
				particle:SetAirResistance( 32 )
			end
		end
		for i=1, math.random( 4, 8 ) do
			local particle = self.Emitter:Add( "effects/fleck_cement"..math.random( 1, 2 ), pos )
			if particle then
				particle:SetVelocity( VectorRand():GetNormalized()*math.random( 32, 48 ) )
				particle:SetLifeTime( 0 )
				particle:SetDieTime( math.Rand( 1, 2 ) )
				particle:SetStartAlpha( 255 )
				particle:SetEndAlpha( 0 )
                local Siz = math.random( 2, 4 )
                particle:SetStartSize( Siz )
                particle:SetEndSize( 0 )
                particle:SetRoll( math.random( 0, 360 ) )
				particle:SetColor( sta.x, sta.y, sta.z )
                particle:SetGravity( Vector( 0, 0, -128 ) )
				particle:SetCollide( true )
				particle:SetBounce( math.Rand( 0.5, 1 ) )
				particle:SetAirResistance( 32 )
			end
		end
		self.Emitter:Finish()
	end
	function EFFECT:Think() return false end
	function EFFECT:Render() end
	effects.Register( EFFECT, nam )
end