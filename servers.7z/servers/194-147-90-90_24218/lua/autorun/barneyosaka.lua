-- "lua\\autorun\\barneyosaka.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
list.Set( "PlayerOptionsModel", "Barney (OSAKA)", "models/player/azumanga/Barney.mdl" )
player_manager.AddValidModel( "Barney (OSAKA)", "models/player/azumanga/Barney.mdl" )
player_manager.AddValidHands( "Barney (OSAKA)", "models/weapons/c_arms_barney.mdl", 0, "00000000" )