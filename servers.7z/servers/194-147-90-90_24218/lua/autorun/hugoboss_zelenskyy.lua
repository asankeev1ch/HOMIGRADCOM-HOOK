-- "lua\\autorun\\hugoboss_zelenskyy.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Zelensky with Hugo boss drip", 		"models/bombdonetsk/hugoboss_zelensky.mdl" )
list.Set( "PlayerOptionsModel",  "Zelensky with Hugo boss drip", 	"models/bombdonetsk/hugoboss_zelensky.mdl" )