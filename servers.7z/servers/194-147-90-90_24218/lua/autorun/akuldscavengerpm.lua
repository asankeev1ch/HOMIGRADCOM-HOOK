-- "lua\\autorun\\akuldscavengerpm.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
player_manager.AddValidModel( "Scavenger", "models/akuld/lcscavenger/scavenger_pm.mdl" )
list.Set( "PlayerOptionsModel", "Scavenger", "models/akuld/lcscavenger/scavenger_pm.mdl" )

player_manager.AddValidHands( "Scavenger", "models/akuld/lcscavenger/scavenger_arms.mdl", 0, "00000000" )