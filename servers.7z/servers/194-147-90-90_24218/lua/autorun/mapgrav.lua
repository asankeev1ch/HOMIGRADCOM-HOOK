-- "lua\\autorun\\mapgrav.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
CreateConVar( "grav_setmapgrav", "0", FCVAR_NONE )
CreateConVar( "grav_advsetmapgrav", "0", FCVAR_NONE )
CreateConVar( "grav_effectentstype", "0", FCVAR_NONE )

local gravmedistable = {
["prop_physics"]=true,
}

hook.Add( "PlayerInitialSpawn", "ismapzerograv", function( player )

	local gravamount = GetConVar( "grav_setmapgrav" ):GetInt()
	local advgravamount = GetConVar( "grav_advsetmapgrav" ):GetInt()
	local effectentstype = GetConVar( "grav_effectentstype" ):GetInt()

for k,v in pairs(ents.GetAll()) do
if gravmedistable[v:GetClass()] then

	local phys = v:GetPhysicsObject()

if ( IsValid( phys ) ) then	
if effectentstype == 2 or effectentstype == 0 then
if  gravamount == 0 or advgravamount == 0 then	
--do nothing
else
phys:EnableGravity( false )
				 
			   end
			end
	     end      
	  end
   end
end)

hook.Add( "PlayerSpawnedProp", "gravprops", function( player, mdl, ent )
if gravmedistable[ent:GetClass()] then

	local gravamount = GetConVar( "grav_setmapgrav" ):GetInt()
	local advgravamount = GetConVar( "grav_advsetmapgrav" ):GetInt()
	local effectentstype = GetConVar( "grav_effectentstype" ):GetInt()
	local phys = ent:GetPhysicsObject()

if ( IsValid( phys ) ) then	
if effectentstype == 2 or effectentstype == 0 then
if  gravamount == 0 or advgravamount == 0 then		
--do nothing
else
phys:EnableGravity( false )

		    end
         end
	  end
   end
end)
hook.Add( "PlayerSpawnedSENT", "gravsents", function( player, ent )
if gravmedistable[ent:GetClass()] then

	local gravamount = GetConVar( "grav_setmapgrav" ):GetInt()
	local advgravamount = GetConVar( "grav_advsetmapgrav" ):GetInt()
	local effectentstype = GetConVar( "grav_effectentstype" ):GetInt()
	local phys = ent:GetPhysicsObject()
	
if ( IsValid( phys ) ) then	
if effectentstype == 2 or effectentstype == 0 then	
if  gravamount == 0 or advgravamount == 0 then		
--do nothing
else
phys:EnableGravity( false )

		    end
         end
	  end
   end
end)

hook.Add( "PlayerSpawn", "gravplayers", function( player )

	local gravamount = GetConVar( "grav_setmapgrav" ):GetInt()
	local effectentstype = GetConVar( "grav_effectentstype" ):GetInt()
	local advgravamount = GetConVar( "grav_advsetmapgrav" ):GetInt()

if effectentstype == 2 then
player:SetGravity( 0 )
end
	
if effectentstype == 1 or effectentstype == 0 then	

if advgravamount ~= 0 and gravamount == 0 then 
player:SetGravity( advgravamount )
end

if gravamount == 0 and advgravamount == 0 then
player:SetGravity( 0 )
end

if gravamount ~= 0 and advgravamount == 0 then
if ( gravamount == 1 ) then
player:SetGravity( 0.01 )
end
if ( gravamount == 2 ) then
player:SetGravity( 0.02 )
end
if ( gravamount == 3 ) then
player:SetGravity( 0.03 )
end
if ( gravamount == 4 ) then
player:SetGravity( 0.04 )
end
if ( gravamount == 5 ) then
player:SetGravity( 0.05 )
end
if ( gravamount == 6 ) then
player:SetGravity( 0.06 )
end
if ( gravamount == 7 ) then
player:SetGravity( 0.07 )
end
if ( gravamount == 8 ) then
player:SetGravity( 0.09 )
end
if ( gravamount == 9 ) then
player:SetGravity( 0.09 )
end
if ( gravamount == 10 ) then
player:SetGravity( 0.10 )
       
         end
      end
   end
end)