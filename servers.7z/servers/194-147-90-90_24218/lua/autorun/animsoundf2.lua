-- "lua\\autorun\\animsoundf2.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

//wfreddy
sound.Add({
	name = 			"freddy.foot1",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"2footstep1.mp3"
						,"2footstep2.mp3"
						,"2footstep3.mp3"
						,"2footstep4.mp3"}
})

sound.Add({
	name = 			"freddy.foot2",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"2footstep1.mp3"
						,"2footstep2.mp3"
						,"2footstep3.mp3"
						,"2footstep4.mp3"}
})

sound.Add({
	name = 			"freddy.rfoot1",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"2footstep1.mp3"
						,"2footstep2.mp3"
						,"2footstep3.mp3"
						,"2footstep4.mp3"}
})

sound.Add({
	name = 			"freddy.rfoot2",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"2footstep1.mp3"
						,"2footstep2.mp3"
						,"2footstep3.mp3"
						,"2footstep4.mp3"}
})

sound.Add({
	name = 			"freddy.stand",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			"fnaf2/frefr.mp3"

})

sound.Add({
	name = 			"jjcrouch",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			"fnaf2/frefr.mp3"

})

sound.Add({
	name = 			"chica.scream",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/glitching scream.wav"}
})

sound.Add({
	name = 			"chica.glitch",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/glitching chica.wav"}
})
sound.Add({
	name = 			"foxy.scream",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/foxyscream.wav"}
})
sound.Add({
	name = 			"vent",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/2ventwalk1.mp3"
						,"fnaf2/2ventwalk2.mp3"
						,"fnaf2/2ventwalk3.mp3"
						,"fnaf2/2ventwalk4.mp3"
						,"fnaf2/2ventwalk5.mp3"						}
})
sound.Add({
	name = 			"glitching",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"ambient/energy/newspark10.wav"
						,"ambient/energy/newspark11.wav"
						,"ambient/energy/newspark08.wav"
						,"ambient/energy/newspark07.wav"
						,"ambient/energy/newspark05.wav"
						}
})

sound.Add({
	name = 			"endoscream",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/endoscream.wav"}
})

sound.Add({
	name = 			"freddyfall",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/freddyfall.wav"}
})

sound.Add({
	name = 			"freddyup",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/freddygetup.wav"}
})

sound.Add({
	name = 			"bonniefall",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/bonniefall.wav"}
})

sound.Add({
	name = 			"bonnieup",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/bonniegetup.wav"}
})

sound.Add({
	name = 			"chicafall",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/chicafall.wav"}
})

sound.Add({
	name = 			"chicaup",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/chicagetup.wav"}
})

sound.Add({
	name = 			"foxyfall",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/foxyfall.wav"}
})

sound.Add({
	name = 			"foxyup",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			{"fnaf2/foxygetup.wav"}
})

sound.Add({
	name = 			"wpuppetfoot",
	channel = 		CHAN_USER_BASE+10,
	volume = 		0.5,
	sound = 				{"physics/wood/wood_box_impact_soft1.wav"
						,"physics/wood/wood_box_impact_soft2.wav"}
})
